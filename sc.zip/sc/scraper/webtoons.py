"""
Scraper for webtoons.com versi Indonesia (www.webtoons.com/id + API mobile m.webtoons.com)

Endpoint/alur diambil dari extension Tachiyomi/Mihon "Webtoons" (sample/Webtoons.kt)
dan sudah dicek langsung ke situsnya:
  1. Cari judul      : GET {BASE}/id/search?keyword=<q>&page=<n>          -> HTML .webtoon_list li a
  2. Daftar populer  : GET {BASE}/id/ranking/trending                     -> HTML .webtoon_list li a
  3. Detail manga    : GET {url seri dari hasil pencarian}                -> HTML
  4. Daftar chapter  : GET {MOBILE}/api/v1/{webtoon|canvas}/{title_no}/episodes?pageSize=..
  5. Isi chapter     : GET {viewerLink}  -> HTML  div#_imageList > img[data-url]
  6. Gambar          : webtoon-phinf.pstatic.net

Catatan penting:
- GAWANG UTAMA: gambar di webtoon-phinf.pstatic.net membalas 403 kalau TANPA
  header Referer (sudah diuji: tanpa Referer -> 403 text/html, dengan Referer
  root webtoons.com -> 200 image/jpeg). Jadi _download_image_with_retry selalu
  mengirim Referer situsnya, seperti extension aslinya.
- GAMBAR PEMISAH: sebagian chapter menyisipkan gambar pemisah yang sangat kecil
  (terukur: PNG transparan 255 B, HTTP 200). Ukuran sekecil itu ditolak oleh
  pemeriksaan umum di base.py, jadi di sini balasan kecil diterima selama
  Content-Type-nya benar-benar gambar -- lihat _download_image_with_retry.
- KUALITAS GAMBAR: situs mengirim versi terkompres lewat parameter `?type=q90`
  (contoh terukur: 30.355 B vs 135.396 B untuk halaman yang sama). Extension
  membuang parameter itu hanya kalau pengguna menyalakan opsi "maximum quality";
  di sini selalu dibuang karena scraper ini memang mengambil versi terbaik
  (lihat _max_quality). Parameter `?type=opti` (banner peringatan usia) TIDAK
  dibuang, sama seperti extension.
- NOMOR CHAPTER: judul episode di situs tidak selalu memuat nomor bab yang rapi
  ("PROLOG", "EPISODE 1", "EP. 138 - ..."), jadi nomornya diturunkan dengan
  aturan yang sama seperti extension (lihat EPISODE_NO_RE dan _chapter_entries):
  nomor dibaca dari judul kalau ada, episode yang tidak bisa dibaca (prolog,
  mini/bonus) menempel 0.01 di belakang episode sebelumnya, dan kalau sebagian
  besar judul tidak memuat nomor sama sekali seluruh seri dinomori urut.
  Nomor inilah yang ditulis di judul ("Chapter 138 EP. 138 - ...") supaya nama
  berkas CBZ (chapter-138.cbz) seurutan dengan daftar chapter di situs.
- URUTAN: daftar chapter dikembalikan TERBARU -> TERLAMA seperti provider lain di
  repo ini; gambar dikembalikan urut sesuai posisinya di halaman viewer.
- Banner peringatan konten (gambar pertama `#_imageList`, mis. 6id_warning.png)
  IKUT diunduh karena memang bagian dari isi halaman -- persis seperti extension
  yang tidak menyaringnya.
- Motion-toon (webtoon bergerak yang gambarnya diambil dari JSON terpisah) TIDAK
  didukung; kalau halaman tidak punya `#_imageList` hasilnya kosong dan chapter
  itu dilaporkan gagal oleh base.py, bukan error separuh jalan.
- Batas serentak: halaman HTML webtoons.com dibatasi HTML_CONCURRENCY dan API
  mobile dibatasi API_CONCURRENCY (extension-nya memakai rateLimit(1) untuk
  m.webtoons.com). CDN gambar tidak dibatasi karena host-nya terpisah.
"""
import re
import time
import threading
from typing import Any, Dict, List, Optional
from urllib.parse import quote, urlsplit, urlunsplit

from bs4 import BeautifulSoup

from .base import BaseScraper


class WebtoonsScraper(BaseScraper):
    """Scraper for webtoons.com (Indonesia)"""

    BASE_URL = "https://www.webtoons.com"
    MOBILE_URL = "https://m.webtoons.com"
    LANG = "id"

    # 1 chapter = 1 halaman viewer (HTML-nya besar, ~250 KB) + download gambar
    # paralel. Worker chapter sengaja lebih kecil dari provider API lain karena
    # tiap chapter menarik halaman HTML penuh, bukan JSON kecil.
    MAX_WORKERS = 6
    INNER_DOWNLOAD_WORKERS = 4

    # Hasil listing (ranking/search) tidak menyertakan jumlah chapter, jadi
    # pencariannya cuma mengumpulkan halaman sampai judul yang persis diketik
    # user ketemu (atau halaman berikutnya sudah mengulang isi yang sama).
    SEARCH_LIMIT = 20
    SEARCH_MAX_PAGES = 3

    HTML_CONCURRENCY = 3
    API_CONCURRENCY = 2
    REQ_RETRIES = 3
    REQ_RETRY_DELAY = 1

    # title_no dipakai di semua URL seri/chapter; nama parameternya beda-beda
    # antar pola URL (`title_no=` di halaman web, `titleNo=` di pola URL lama).
    TITLE_NO_RE = re.compile(r'[?&]title_?no=(\d+)', re.IGNORECASE)

    # Nomor episode dari judul, hasil porting apa adanya dari extension
    # (grup 4 = nomor musim, grup 6 = penanda mini/bonus/special,
    #  grup 11 = nomor chapter, grup 12 = bagian desimalnya).
    EPISODE_NO_RE = re.compile(
        r'(?:(s(eason)?|saison|part|vol(ume)?)\s*\.?\s*(\d+).*?)?'
        r'(.*?(mini|bonus|special).*?)?'
        r'(e(p(isode)?)?|ch(apter)?)\s*\.?\s*(\d+(\.\d+)?)',
        re.IGNORECASE,
    )

    # Tanda status di halaman detail. Locale Indonesia memakai ikon
    # (.txt_ico_completed / .txt_ico_up) tanpa kata "END"; teks penanda dari
    # extension tetap dipakai sebagai cadangan untuk locale lain.
    COMPLETED_ICON = '.txt_ico_completed'
    ONGOING_ICON = '.txt_ico_up'
    COMPLETED_WORDS = ('END', 'COMPLETED', 'TERMIN', 'TAMAT', 'SELESAI')
    ONGOING_WORDS = ('UP', 'EVERY', 'NOUVEAU')

    # Gambar WAJIB pakai Referer (tanpa itu 403); Referer root situsnya sudah cukup.
    IMAGE_HEADERS = {
        'Referer': BASE_URL + '/',
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'Sec-Fetch-Dest': 'image',
    }

    def __init__(self, download_dir: str = "downloads"):
        super().__init__(download_dir)
        self._html_sem = threading.BoundedSemaphore(self.HTML_CONCURRENCY)
        self._api_sem = threading.BoundedSemaphore(self.API_CONCURRENCY)

    # ------------------------------------------------------------- sesi/HTTP
    def _create_session(self):
        """Sesi + cookie yang dipakai extension (`ageGatePass`, `locale`, `needGDPR`)."""
        session = super()._create_session()
        for nama, nilai in (('ageGatePass', 'true'),
                            ('locale', self.LANG),
                            ('needGDPR', 'false')):
            session.cookies.set(nama, nilai, domain='.webtoons.com')
        return session

    def _get_soup(self, url: str, params: Optional[Dict[str, Any]] = None) -> Optional[BeautifulSoup]:
        """GET halaman HTML -> BeautifulSoup, None kalau semua percobaan gagal."""
        for attempt in range(self.REQ_RETRIES):
            try:
                with self._html_sem:
                    resp = self.session.get(url, params=params, timeout=30)
                resp.raise_for_status()
                return BeautifulSoup(resp.text, 'html.parser')
            except Exception:
                if attempt < self.REQ_RETRIES - 1:
                    time.sleep(self.REQ_RETRY_DELAY * (attempt + 1))
        return None

    def _api_get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Optional[Any]:
        """GET JSON dari API mobile (m.webtoons.com), dengan batas serentak."""
        url = f"{self.MOBILE_URL}{path}"
        headers = {'Accept': 'application/json', 'Referer': f"{self.MOBILE_URL}/"}
        for attempt in range(self.REQ_RETRIES):
            try:
                with self._api_sem:
                    resp = self.session.get(url, params=params, timeout=30,
                                            headers=headers)
                resp.raise_for_status()
                return resp.json()
            except Exception:
                if attempt < self.REQ_RETRIES - 1:
                    time.sleep(self.REQ_RETRY_DELAY * (attempt + 1))
        return None

    # --------------------------------------------------------------- parsing
    @classmethod
    def title_no_from_url(cls, url: str) -> str:
        """Ambil title_no (nomor seri) dari URL apa pun yang memuatnya."""
        match = cls.TITLE_NO_RE.search(url or '')
        return match.group(1) if match else ''

    @classmethod
    def chapter_type_from_url(cls, url: str) -> str:
        """'canvas' atau 'webtoon' -- dipakai buat memilih endpoint API-nya.

        Pola URL lama memakai '/challenge/episodeList' untuk canvas, yang baru
        '/id/canvas/<slug>/list', jadi keduanya dicek (seperti extension).
        """
        path = [p for p in urlsplit(url or '').path.split('/') if p]
        if 'canvas' in path or 'challenge' in path:
            return 'canvas'
        return 'webtoon'

    @staticmethod
    def _max_quality(url: str) -> str:
        """Buang parameter kompresi `type=q90` biar dapat berkas aslinya."""
        pisah = urlsplit(url or '')
        if not pisah.query:
            return url
        bagian = [p for p in pisah.query.split('&') if p]
        sisa = [p for p in bagian if p.lower() != 'type=q90']
        if len(sisa) == len(bagian):
            return url
        return urlunsplit((pisah.scheme, pisah.netloc, pisah.path,
                           '&'.join(sisa), pisah.fragment))

    def _listing_to_result(self, anchor) -> Optional[Dict[str, Any]]:
        """Ubah 1 kartu listing (.webtoon_list li a) jadi hasil pencarian CLI."""
        href = (anchor.get('href') or '').strip()
        if not href:
            return None
        if href.startswith('/'):
            href = f"{self.BASE_URL}{href}"

        judul = anchor.select_one('.title')
        gambar = anchor.select_one('img')
        genre = anchor.select_one('.genre')
        # Tipe diambil dari URL-nya, bukan atribut data-webtoon-type: atribut itu
        # berisi "CHALLENGE" untuk judul canvas (bukan "CANVAS"), sedangkan yang
        # dipakai memilih endpoint API adalah 'canvas'/'webtoon' dari chapter_type_from_url.
        tipe = 'Canvas' if self.chapter_type_from_url(href) == 'canvas' else 'Webtoon'

        return {
            'title': (judul.get_text(strip=True) if judul
                      else (gambar.get('alt') if gambar else href)),
            'url': href,
            'title_no': anchor.get('data-title-no') or self.title_no_from_url(href),
            'type': tipe,
            # Kartu di halaman ranking memuat genre; kartu di halaman pencarian
            # hanya memuat penulis, jadi genre boleh kosong.
            'genre': genre.get_text(strip=True) if genre else '',
            'cover_url': self._upgrade_image_url(gambar.get('src') or '') if gambar else '',
            # Listing situs tidak memuat jumlah chapter/rating, jadi dibiarkan
            # kosong daripada menebak.
            'chapter_latest': '',
            'rating': '',
        }

    # ---------------------------------------------------------------- publik
    def search(self, query: str) -> List[Dict[str, Any]]:
        """Cari judul lewat halaman pencarian situs (`keyword`)."""
        q = (query or '').strip()
        if not q:
            return []

        q_norm = self._normalisasi_judul(q)
        hasil: List[Dict[str, Any]] = []
        dilihat = set()

        for page in range(1, self.SEARCH_MAX_PAGES + 1):
            soup = self._get_soup(f"{self.BASE_URL}/{self.LANG}/search",
                                  params={'keyword': q, 'page': page})
            if soup is None:
                break
            kartu = soup.select('.webtoon_list li a')
            if not kartu:
                break

            baru = 0
            for anchor in kartu:
                item = self._listing_to_result(anchor)
                if item and item['url'] not in dilihat:
                    dilihat.add(item['url'])
                    hasil.append(item)
                    baru += 1

            # Halaman berikutnya mengulang isi yang sama (situs mengirim
            # halaman 1 lagi kalau hasilnya sudah habis) -> berhenti.
            if baru == 0:
                break
            # Judul persis sudah ketemu -> halaman berikutnya tidak perlu.
            if any(self._normalisasi_judul(r['title']) == q_norm for r in hasil):
                break

        # Situs mengurut menurut relevansi/popularitas; judul yang persis
        # diketik user ditarik ke atas dulu (lihat BaseScraper._urut_hasil_pencarian).
        hasil = self._urut_hasil_pencarian(query, hasil)
        return hasil[:self.SEARCH_LIMIT]

    def get_popular(self, page: int = 1) -> List[Dict[str, Any]]:
        """Judul populer dari halaman ranking (hanya halaman pertama)."""
        if page != 1:
            return []
        soup = self._get_soup(f"{self.BASE_URL}/{self.LANG}/ranking/trending")
        if soup is None:
            return []
        hasil = [r for r in (self._listing_to_result(a)
                             for a in soup.select('.webtoon_list li a')) if r]
        return hasil[:self.SEARCH_LIMIT]

    def get_manga_detail(self, url: str) -> Optional[Dict[str, Any]]:
        """Detail manga + daftar chapter.

        Halaman detail menyediakan judul/genre/sinopsis/status, sedangkan daftar
        chapter-nya datang dari API mobile (host berbeda), seperti extension.
        """
        title_no = self.title_no_from_url(url)
        if not title_no:
            return None

        soup = self._get_soup(url)
        if soup is None:
            return None

        judul_el = soup.select_one('h1.subj, h3.subj')
        title = judul_el.get_text(strip=True) if judul_el else ''
        if not title:
            return None

        info_el = soup.select_one('.detail_header .info')
        genres = [g.get_text(strip=True) for g in (info_el.select('.genre') if info_el else [])]
        genres = [g for g in genres if g]
        author, artist = self._author_artist(info_el)

        aside = soup.select_one('#_asideDetail')
        sinopsis = ''
        status = ''
        if aside is not None:
            ringkas = aside.select_one('p.summary')
            sinopsis = ringkas.get_text(strip=True) if ringkas else ''
            status = self._status_from_aside(aside)

        og = soup.select_one('meta[property="og:image"]')
        cover_og = (og.get('content') or '').strip() if og else ''
        thmb = soup.select_one('.detail_header .thmb img')
        cover_thumb = self._upgrade_image_url(thmb.get('src') or '') if thmb else ''
        cover_url = cover_og or cover_thumb

        jenis = self.chapter_type_from_url(url)
        tipe = 'Canvas' if jenis == 'canvas' else 'Webtoon'
        chapters = self._chapter_entries(title_no, jenis)

        info = {
            'title': title,
            'alternative_title': '',
            'type': tipe,
            'author': author,
            'artist': artist,
            'status': status,
            'rating': '',
            'release_date': '',
            'total_chapters': len(chapters),
        }

        kandidat = []
        for kandidat_url in (cover_og, cover_thumb):
            if kandidat_url and kandidat_url not in kandidat:
                kandidat.append(kandidat_url)

        return {
            'title': title,
            'cover_url': cover_url,
            'cover_candidates': kandidat,
            'genres': genres,
            'synopsis': sinopsis,
            'info': info,
            'total_chapters': len(chapters),
            'source': 'webtoons.com',
            'source_url': url,
            'chapters': chapters,
        }

    @staticmethod
    def _author_artist(info_el) -> tuple:
        """(author, artist) dari .detail_header .info.

        Sebagian judul memakai `.author` terpisah untuk author dan artist,
        sebagian lagi (termasuk halaman /id) cuma satu `.author_area` berisi
        "nama1 , nama2". Tombol "Informasi Kreator" dibuang dulu supaya tidak
        ikut terbaca sebagai nama.
        """
        if info_el is None:
            return '', ''

        satu = info_el.select_one('.author:nth-of-type(1)')
        dua = info_el.select_one('.author:nth-of-type(2)')
        if satu is not None or dua is not None:
            author = satu.get_text(strip=True) if satu is not None else ''
            artist = (dua.get_text(strip=True) if dua is not None else '') or author
            return author, artist

        area = info_el.select_one('.author_area')
        if area is None:
            return '', ''
        for tombol in area.select('button'):
            tombol.decompose()
        bagian = [b.strip() for b in re.split(r'[,/]', area.get_text(' ', strip=True))
                  if b.strip()]
        author = bagian[0] if bagian else ''
        artist = bagian[1] if len(bagian) > 1 else author
        return author, artist

    def _status_from_aside(self, aside) -> str:
        """Status dari blok `p.day_info` (ikon lebih dulu, teks sebagai cadangan)."""
        hari = aside.select_one('p.day_info')
        if hari is None:
            return ''
        if hari.select_one(self.COMPLETED_ICON):
            return 'Completed'
        if hari.select_one(self.ONGOING_ICON):
            return 'Ongoing'
        teks = hari.get_text(' ', strip=True).upper()
        if any(kata in teks for kata in self.COMPLETED_WORDS):
            return 'Completed'
        if any(kata in teks for kata in self.ONGOING_WORDS):
            return 'Ongoing'
        return ''

    def _chapter_entries(self, title_no: str, jenis: str) -> List[Dict[str, Any]]:
        """Daftar chapter dari API mobile (urut terbaru -> terlama).

        Nomor chapter diturunkan seperti extension: baca nomor dari judul episode;
        prolog/mini/bonus menempel 0.01 di belakang episode sebelumnya; dan kalau
        sebagian besar judul tidak memuat nomor, seluruh seri dinomori urut.
        """
        params: Dict[str, Any] = {'pageSize': '99999'}
        if jenis == 'canvas':
            params['readingLanguageCode'] = self.LANG

        payload = self._api_get(f"/api/v1/{jenis}/{quote(title_no)}/episodes",
                                params=params)
        rows = ((payload or {}).get('result') or {}).get('episodeList') or []
        if not isinstance(rows, list) or not rows:
            return []

        entri: List[Dict[str, Any]] = []
        dikenal = 0
        aneh = 0
        for episode in rows:
            judul = (episode.get('episodeTitle') or '') if isinstance(episode, dict) else ''
            cocok = self.EPISODE_NO_RE.search(judul)
            # Episode mini/bonus/special sengaja tidak dibaca nomornya (grup 6
            # berisi penandanya), sama seperti extension.
            if cocok is not None and not (cocok.group(6) or ''):
                nomor: Optional[float] = float(cocok.group(11))
                musim = int(cocok.group(4)) if cocok.group(4) else 1
                dikenal += 1
            else:
                nomor = None
                musim = 1
                aneh += 1
            entri.append({'episode': episode, 'nomor': nomor, 'musim': musim})

        if aneh > dikenal:
            # Judulnya tidak bisa dibaca (mis. cuma "Prolog", "Chapter Spesial")
            # -> urut saja sesuai urutan situs.
            for urut, item in enumerate(entri, 1):
                item['nomor'] = float(urut)
        else:
            maksimum = 0.0
            musim_sekarang = 1
            offset = 0.0
            for i, item in enumerate(entri):
                if item['nomor'] is not None:
                    asli = item['nomor']
                    # Season baru yang nomornya balik ke bawah -> geser sejauh
                    # nomor tertinggi season sebelumnya.
                    if item['musim'] > musim_sekarang:
                        musim_sekarang = item['musim']
                        if asli <= maksimum:
                            offset = maksimum
                    item['nomor'] = offset + asli
                    maksimum = max(maksimum, item['nomor'])
                else:
                    sebelumnya = entri[i - 1] if i > 0 else None
                    item['nomor'] = (sebelumnya['nomor'] + 0.01
                                     if sebelumnya is not None else 0.0)

        chapters: List[Dict[str, Any]] = []
        dilihat = set()
        for item in entri:
            episode = item['episode']
            link = (episode.get('viewerLink') or '').strip()
            if not link or link in dilihat:
                continue
            dilihat.add(link)

            nomor = self._format_number(item['nomor'])
            judul_episode = (episode.get('episodeTitle') or '').strip()
            # Nomor ditaruh paling depan supaya nama berkas CBZ (yang dibaca dari
            # angka pertama di judul) selalu sama dengan nomor chapter-nya.
            judul = f"Chapter {nomor}"
            if judul_episode:
                judul = f"{judul} {judul_episode}"

            chapters.append({
                'title': judul,
                'url': link if link.startswith('http') else f"{self.BASE_URL}{link}",
                'number': nomor,
                'episode_no': episode.get('episodeNo'),
            })

        return list(reversed(chapters))

    @staticmethod
    def _format_number(nomor: Optional[float]) -> str:
        """Nomor chapter jadi teks: 4.0 -> '4', 138.01 -> '138.01'."""
        if nomor is None:
            return '0'
        teks = f"{round(float(nomor), 2):.2f}".rstrip('0').rstrip('.')
        return teks or '0'

    def get_chapter_images_ordered(self, url: str) -> List[Dict[str, Any]]:
        """Daftar gambar 1 chapter dari halaman viewer-nya.

        Urutannya persis posisi `img` di dalam `div#_imageList` (urutan baca yang
        ditentukan situsnya), dan parameternya sudah dinaikkan ke kualitas penuh.
        """
        soup = self._get_soup(url)
        if soup is None:
            return []

        urls: List[str] = []
        for gambar in soup.select('div#_imageList > img'):
            src = (gambar.get('data-url') or '').strip()
            if src.startswith('http'):
                urls.append(self._max_quality(src))

        return [{'order': i, 'url': src} for i, src in enumerate(urls, 1)]

    def get_chapter_images(self, url: str) -> List[str]:
        """Get all image URLs for a chapter (backward compatible)"""
        ordered = self.get_chapter_images_ordered(url)
        return [img['url'] for img in ordered]

    def _download_image_with_retry(self, url: str) -> Optional[bytes]:
        """Unduh gambar halaman.

        Dua hal khusus provider ini:
        1. Referer WAJIB dikirim: CDN-nya membalas 403 tanpa Referer (sudah diuji),
           jadi header di IMAGE_HEADERS bukan sekadar basa-basi.
        2. Ukuran kecil TIDAK otomatis dianggap gagal. Pemeriksaan `len(data) < 1000`
           di base.py dibuat untuk menangkap body error, tapi CDN Webtoons sendiri
           mengirim gambar pemisah yang sangat kecil (terukur: PNG transparan 255 B,
           HTTP 200 `image/png`) yang dipakai di antara halaman. Karena itu balasan
           kecil diterima kalau Content-Type-nya benar-benar gambar; balasan error
           (mis. 403 `text/html`) tetap ditolak, baik oleh status maupun tipe isinya.
        """
        for attempt in range(self.MAX_RETRIES):
            try:
                resp = self.session.get(url, timeout=30, headers=self.IMAGE_HEADERS)
                resp.raise_for_status()
                data = resp.content
                tipe = (resp.headers.get('Content-Type') or '').lower()
                if not data or (len(data) < 1000 and not tipe.startswith('image/')):
                    raise Exception("Image data too small")
                return data
            except Exception:
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY)
        return None

    def download_manga(self, manga_url: str, max_workers: int = None, progress=None,
                       chapters=None, target_dir=None) -> bool:
        """Unduh pakai mesin base.py (tanpa perlakuan khusus).

        `target_dir` diteruskan apa adanya: mode paralel sudah menentukan folder
        milik judul ini, jadi base tidak perlu menghitung ulang dari judul.
        """
        return super().download_manga(manga_url, max_workers=max_workers,
                                      progress=progress, chapters=chapters,
                                      target_dir=target_dir)

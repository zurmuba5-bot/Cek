#!/usr/bin/env python3
"""
CLI Interface for Comic Scraper
Interactive menu with search, selection, and progress display
"""
import os
import sys
import re
import time
from pathlib import Path
from typing import List, Dict, Any, Optional, Union

# Rich for beautiful CLI
try:
    from rich.console import Console, Group
    from rich.table import Table
    from rich.panel import Panel
    from rich.prompt import Prompt, IntPrompt
    from rich.text import Text
    from rich.markup import escape
    from rich import box
    HAS_RICH = True
except ImportError:
    HAS_RICH = False
    print("  rich belum terpasang, tampilan jadi polos")


# Palet warna (display saja)
BRAND = "bold bright_cyan"
ACCENT = "bold bright_magenta"
MUTED = "grey58"
FAINT = "grey42"
OK = "bold green"
WARN = "bold yellow"
ERR = "bold red"

# Kata kunci navigasi (interaksi, bukan logika scraping)
BACK_WORDS = {"b", "back", "kembali", "0"}
EXIT_WORDS = {"q", "quit", "exit", "keluar"}
YA_WORDS = {"y", "ya", "yes", "iya", "iyaa", "ok"}


class _Sentinel:
    """Penanda hasil prompt: Bedakan 'pakai ulang situs' dari 'keluar'."""

    def __init__(self, nama: str):
        self.nama = nama

    def __repr__(self) -> str:
        return f"<{self.nama}>"


# 'b' di prompt judul -> balik ke pilih situs
BACK = _Sentinel("ganti-situs")
# 'q' atau EOF/Ctrl+C -> keluar aplikasi
EXIT = _Sentinel("keluar")

Choice = Union[Dict[str, Any], _Sentinel, None]


class ComicCLI:
    """Interactive CLI for comic scraper"""
    
    def __init__(self):
        if HAS_RICH:
            self.console = Console(highlight=False)
        self.scraper = None
        self.source_name = ""
        # Manager unduh paralel (beberapa judul sekaligus). Dibuat saat pertama
        # dipakai lewat mode paralel; kalau None berarti belum pernah dipakai.
        self.batch = None
    
    def print(self, *args, **kwargs):
        if HAS_RICH:
            self.console.print(*args, **kwargs)
        else:
            print(*args)
    
    # ------------------------------------------------------------------
    # Potongan tampilan yang dipakai semua menu.
    # Aturannya satu: teks yang muncul ke user polos, tanpa kurung, tanda
    # sama dengan, dan simbol dekoratif. Opsi menu selalu berupa kartu
    # besar full-width supaya jelas tombolnya di mana.
    # ------------------------------------------------------------------
    def _aman(self, teks) -> str:
        """Loloskan teks dari situs/judul supaya kurung siku tidak jadi markup."""
        teks = str(teks)
        return escape(teks) if HAS_RICH else teks
    
    def _pesan(self, teks: str, gaya: str = MUTED, depan: str = "  "):
        """Satu baris status polos, tanpa ikon."""
        if HAS_RICH:
            self.console.print(f"{depan}[{gaya}]{self._aman(teks)}[/{gaya}]")
        else:
            print(f"{depan}{teks}")
    
    def _sub_judul(self, teks: str, gaya: str = MUTED):
        """Baris keterangan kecil di bawah sebuah judul."""
        if HAS_RICH:
            self.console.print(f"  [{gaya}]{self._aman(teks)}[/{gaya}]")
        else:
            print(f"  {teks}")
    
    def _menu_kartu(self, judul_menu: str, opsi: list, petunjuk: str = ""):
        """Menu sebagai kartu-kartu besar.

        `opsi` = daftar (nomor, judul, keterangan, gaya_warna).
        """
        if not HAS_RICH:
            print()
            print(judul_menu)
            print()
            for nomor, judul, keterangan, _gaya in opsi:
                print(f"  {nomor}")
                print(f"    {judul}")
                if keterangan:
                    print(f"    {keterangan}")
                print()
            if petunjuk:
                print(f"  {petunjuk}")
                print()
            return
        
        self.console.print()
        self.console.print(f"  [bold white]{self._aman(judul_menu)}[/bold white]")
        self.console.print()
        
        for nomor, judul, keterangan, gaya in opsi:
            kolom = Table.grid(padding=(0, 3))
            kolom.add_column(style=gaya, justify="right", no_wrap=True, width=3)
            kolom.add_column(overflow="fold")
            if keterangan:
                kolom.add_row(nomor, Text.assemble((f"{judul}\n", "bold white"),
                                                   (keterangan, MUTED)))
            else:
                kolom.add_row(nomor, Text(judul, style="bold white"))
            self.console.print(Panel(kolom, box=box.ROUNDED, border_style="grey37",
                                     expand=True, padding=(0, 2)))
            self.console.print()
        
        if petunjuk:
            self.console.print(f"  [{FAINT}]{self._aman(petunjuk)}[/{FAINT}]")
            self.console.print()
    
    # ------------------------------------------------------------------
    # Pembungkus pertanyaan (display saja): rich prompt kalau ada,
    # input() biasa kalau rich tidak terpasang. Default-nya sama seperti
    # sebelumnya jadi alur jawaban tidak berubah.
    # ------------------------------------------------------------------
    def _ask(self, label: str, default: Optional[str] = None) -> Optional[str]:
        if HAS_RICH:
            try:
                return Prompt.ask(f"[{BRAND}]{self._aman(label)}[/{BRAND}]",
                                  default=default, console=self.console)
            except (EOFError, KeyboardInterrupt):
                return default
        try:
            return input(f"{label}: ")
        except (EOFError, KeyboardInterrupt):
            return default
    
    def _ask_int(self, label: str, default: int) -> int:
        if HAS_RICH:
            try:
                return IntPrompt.ask(f"[{BRAND}]{self._aman(label)}[/{BRAND}]",
                                     default=default, console=self.console)
            except (EOFError, KeyboardInterrupt):
                return default
        try:
            jawab = input(f"{label}, ENTER untuk {default}: ").strip()
            return int(jawab) if jawab else default
        except (EOFError, KeyboardInterrupt, ValueError):
            return default
    
    def _confirm(self, label: str, default: bool = True) -> bool:
        """Ya atau tidak, ditulis pakai kata.ENTER memakai bawaan."""
        bawaan = "ya" if default else "tidak"
        if HAS_RICH:
            self.console.print(f"  [bold white]{self._aman(label)}[/bold white]")
            self.console.print(f"  [{FAINT}]ENTER untuk {bawaan}, atau ketik tidak untuk membatalkan[/{FAINT}]")
        else:
            print(f"  {label}")
            print(f"  ENTER untuk {bawaan}, atau ketik tidak untuk membatalkan")
        
        jawab = self._ask("jawab", default=bawaan) or bawaan
        return jawab.strip().lower() in YA_WORDS
    
    def show_banner(self):
        if not HAS_RICH:
            print()
            print("  K O M I K   S C R A P E R   versi 2")
            print("  Unduh manga dari situs Indonesia")
            print("  komiku.org   komikindo.ch   softkomik.co   voratoon.com   shinigami.asia   webtoons.com")
            print()
            return
        
        judul = Text("  ")
        judul.append("K O M I K", style=BRAND)
        judul.append("     ", style=FAINT)
        judul.append("S C R A P E R", style=ACCENT)
        
        isi = Group(
            Text(""),
            judul,
            Text("  Unduh manga dari situs Indonesia", style="grey70"),
            Text("  komiku.org      komikindo.ch      softkomik.co      voratoon.com      shinigami.asia      webtoons.com", style=MUTED),
            Text(""),
        )
        self.console.print(Panel(isi, box=box.ROUNDED, border_style="bright_cyan",
                                 padding=(1, 2), expand=True))
    
    def select_source(self, top_level: bool = True) -> tuple:
        """Let user select the manga source.

        top_level=True  -> dipanggil sebagai menu pembuka, 'b' berarti keluar.
        top_level=False -> dipanggil dari dalam sesi, 'b' berarti kembali.
        """
        petunjuk = "ketik angka untuk memilih, p untuk mode paralel, atau b untuk keluar" if top_level \
            else "ketik angka untuk memilih, atau b untuk kembali"
        
        opsi = [
            ("1", "K O M I K U   O R G", "tanpa Cloudflare, paling cepat", BRAND),
            ("2", "K O M I K I N D O   C H", "Cloudflare aktif, kadang perlu diulang", "bold yellow"),
            ("3", "S O F T K O M I K   C O", "perlu token sesi, kadang perlu login", ACCENT),
            ("4", "V O R A T O O N   C O M", "API publik, tanpa Cloudflare", "bold bright_green"),
            ("5", "S H I N I G A M I   A S I A", "API publik, tanpa Cloudflare", "bold bright_green"),
            ("6", "W E B T O O N S   C O M", "versi Indonesia, halaman HTML", "bold bright_magenta"),
        ]
        if top_level:
            opsi.append(("p", "M O D E   P A R A L E L",
                         "unduh beberapa judul sekaligus, maks 5, satu papan",
                         "bold bright_yellow"))
        self._menu_kartu("Pilih sumber manga", opsi, petunjuk)
        
        try:
            if HAS_RICH:
                pilihan = Prompt.ask(f"[{BRAND}]nomor[/{BRAND}]",
                                     default="1", console=self.console,
                                     choices=None).strip() or "1"
            else:
                pilihan = input("nomor: ").strip() or "1"
        except EOFError:
            return None, None
        
        choice = pilihan
        
        if choice.lower() in BACK_WORDS or choice.lower() in EXIT_WORDS:
            return None, None  # keluar / kembali
        
        if choice.lower() == 'p':
            return 'paralel', None
        
        if choice == '1':
            from .komiku import KomikuScraper
            self.source_name = "komiku.org"
            return 'komiku', KomikuScraper()
        elif choice == '3':
            from .softkomik import SoftkomikScraper
            self.source_name = "softkomik.co"
            return 'softkomik', SoftkomikScraper()
        elif choice == '4':
            from .voratoon import VoraToonScraper
            self.source_name = "voratoon.com"
            return 'voratoon', VoraToonScraper()
        elif choice == '5':
            from .shinigami import ShinigamiScraper
            self.source_name = "shinigami.asia"
            return 'shinigami', ShinigamiScraper()
        elif choice == '6':
            from .webtoons import WebtoonsScraper
            self.source_name = "webtoons.com"
            return 'webtoons', WebtoonsScraper()
        else:
            from .komikindo import KomikindoScraper
            self.source_name = "komikindo.ch"
            return 'komikindo', KomikindoScraper()
    
    def search_manga(self, scraper) -> Choice:
        """Search for manga and let user select.

        Return: dict manga terpilih, BACK (ganti situs), EXIT (keluar),
        atau None (tidak ada hasil / pilihan tidak valid).
        """
        if HAS_RICH:
            self.console.print(f"  [{FAINT}]b  ganti situs[/{FAINT}]     "
                               f"[{FAINT}]q  keluar[/{FAINT}]")
            self.console.print()
        else:
            print("  b  ganti situs     q  keluar")
            print()

        try:
            query = self._ask("Masukkan judul manga")
        except EOFError:
            return EXIT
        
        if query is None:
            return EXIT  # EOF / Ctrl+C

        query = query.strip()
        rendah = query.lower()

        if rendah in BACK_WORDS:
            return BACK
        if rendah in EXIT_WORDS:
            return EXIT

        if not query:
            self._pesan("judul tidak boleh kosong", ERR)
            return None
        
        if HAS_RICH:
            self.console.print(f"\n  [{MUTED}]mencari[/{MUTED}]  [bold white]{self._aman(query)}[/bold white]")
        else:
            print(f"\n  mencari  {query}")
        
        results = scraper.search(query)
        
        if not results:
            self._pesan("tidak ada hasil untuk judul itu", ERR)
            return None
        
        # Show results
        if HAS_RICH:
            table = Table.grid(padding=(0, 3))
            table.add_column(style=BRAND, justify="right", no_wrap=True, width=3)
            table.add_column()
            
            for i, result in enumerate(results[:10], 1):
                info_parts = []
                if result.get('type'):
                    info_parts.append(str(result['type']))
                if result.get('chapter_latest'):
                    info_parts.append(f"chapter {result['chapter_latest']}")
                if result.get('rating'):
                    info_parts.append(f"bintang {result['rating']}")
                info = "     ".join(info_parts) if info_parts else ""
                if info:
                    table.add_row(str(i), Text.assemble(
                        (f"{result['title']}\n", "bold white"), (info, MUTED)))
                else:
                    table.add_row(str(i), Text(str(result['title']), style="bold white"))
            
            self.console.print()
            self.console.print(f"  [bold white]Hasil pencarian[/bold white]")
            self.console.print()
            self.console.print(table)
            self.console.print()
            self.console.print(f"  [{FAINT}]menampilkan {min(10, len(results))} dari "
                               f"{len(results)} hasil[/{FAINT}]")
            self.console.print()
        else:
            print()
            print("  Hasil pencarian")
            print()
            for i, result in enumerate(results[:10], 1):
                print(f"  {i}   {result['title']}")
        
        # Select
        if len(results) == 1:
            if HAS_RICH:
                self.console.print(f"\n  [{MUTED}]dipakai otomatis[/{MUTED}]  "
                                   f"[bold white]{self._aman(results[0]['title'])}[/bold white]")
            else:
                print(f"\n  dipakai otomatis  {results[0]['title']}")
            return results[0]
        
        choice = self._ask_int("nomor manga", 1)
        
        if choice < 1 or choice > len(results):
            self._pesan("nomor itu di luar daftar", ERR)
            return None
        
        return results[choice - 1]
    
    def show_manga_detail(self, detail: Dict[str, Any]):
        """Show manga details"""
        if not detail:
            return
        
        info = detail.get('info') or {}
        
        if HAS_RICH:
            grid = Table.grid(padding=(0, 3))
            grid.add_column(style=MUTED, justify="right", no_wrap=True)
            grid.add_column(style="white", overflow="fold")
            if info.get('type'):
                grid.add_row("Tipe", self._aman(info['type']))
            if info.get('author'):
                grid.add_row("Author", self._aman(info['author']))
            if info.get('status'):
                grid.add_row("Status", self._aman(info['status']))
            if detail.get('genres'):
                genres = "     ".join(self._aman(g) for g in detail['genres'])
                grid.add_row("Genre", f"[grey70]{genres}[/grey70]")
            if detail.get('chapters'):
                grid.add_row("Chapter", f"[{OK}]{len(detail['chapters'])}[/{OK}] tersedia")
            
            self.console.print()
            self.console.print(Panel(grid,
                                     title=f"[bold white]{self._aman(detail['title'])}[/bold white]",
                                     title_align="left",
                                     box=box.ROUNDED, border_style="bright_cyan",
                                     padding=(1, 3), expand=True))
        else:
            print(f"\n  {detail['title']}")
            if detail.get('info'):
                for k, v in detail['info'].items():
                    print(f"  {k}: {v}")
    
    def select_chapters(self, chapters: List[Dict]):
        """Let user select which chapters to download.

        Return: list chapter terpilih, atau BACK kalau user minta ganti situs.
        """
        total = len(chapters)
        
        self._menu_kartu(f"Pilih chapter    {total} chapter tersedia", [
            ("1", "Semua chapter", f"unduh {total} chapter", BRAND),
            ("2", "Chapter tertentu", "contoh 1 sampai 10, atau 1, 5, 10 sampai 15", BRAND),
            ("3", "Chapter terakhir saja", "contoh 10, buat 10 chapter terakhir", BRAND),
        ], "ketik nomor, atau b untuk ganti situs")
        
        pilihan = self._ask("nomor", default="1") or "1"
        
        while True:
            rendah = pilihan.strip().lower()
            if rendah in BACK_WORDS:
                return BACK
            try:
                choice = int(pilihan.strip())
            except ValueError:
                choice = None
            if choice in (1, 2, 3):
                break
            self._pesan("nomor itu tidak ada di daftar, pilih 1 sampai 3", WARN)
            pilihan = self._ask("nomor", default="1") or "1"
        
        if choice == 1:
            return chapters
        
        if choice == 3:
            n = self._ask_int("berapa chapter terakhir", 10)
            return chapters[-n:]
        
        # Custom range
        range_str = self._ask("masukkan nomor chapter", default="1-10") or "1-10"
        
        selected = self._parse_chapter_range(range_str, chapters)
        return selected
    
    def _parse_chapter_range(self, range_str: str, chapters: List[Dict]) -> List[Dict]:
        """Parse chapter range string like '1-10' or '1,5,10-15'"""
        selected = []
        selected_urls = set()
        
        for part in range_str.split(','):
            part = part.strip()
            if not part:
                continue
            
            if '-' in part:
                try:
                    start_str, end_str = part.split('-', 1)
                    start_str = start_str.strip()
                    end_str = end_str.strip()
                    
                    # Handle open-ended ranges like "50-"
                    if not end_str:
                        end_num = 999999
                    else:
                        end_num = float(end_str)
                    
                    if not start_str:
                        start_num = 0
                    else:
                        start_num = float(start_str)
                    
                    for ch in chapters:
                        ch_num = self._extract_chapter_number(ch['title'])
                        if ch_num is not None and start_num <= ch_num <= end_num:
                            if ch['url'] not in selected_urls:
                                selected.append(ch)
                                selected_urls.add(ch['url'])
                except ValueError:
                    pass
            else:
                # Single chapter
                try:
                    target_num = float(part)
                    for ch in chapters:
                        ch_num = self._extract_chapter_number(ch['title'])
                        if ch_num is not None and abs(ch_num - target_num) < 0.01:
                            if ch['url'] not in selected_urls:
                                selected.append(ch)
                                selected_urls.add(ch['url'])
                except ValueError:
                    pass
        
        return selected
    
    def _extract_chapter_number(self, title: str) -> Optional[float]:
        """Extract chapter number from title"""
        # Match patterns like "Chapter 1", "Ch. 1", "Chapter 1.5", etc
        match = re.search(r'(?:chapter|ch\.?)\s*([\d.]+)', title, re.IGNORECASE)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                pass
        
        # Try to find any number
        match = re.search(r'([\d.]+)', title)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                pass
        
        return None
    
    def download_with_progress(self, scraper, manga_url: str, chapters: List[Dict],
                               max_workers: int = None):
        """Download chapters with live progress display"""
        from .base import ProgressTracker

        total = len(chapters)
        if total == 0:
            self._pesan("tidak ada chapter untuk diunduh", WARN)
            return
        
        # Pakai default per situs (komiku 10, komikindo 5)
        max_workers = max_workers or getattr(scraper, 'MAX_WORKERS', 10)
        
        if HAS_RICH:
            rincian = Table.grid(padding=(0, 3))
            rincian.add_column(style=MUTED, justify="right", no_wrap=True)
            rincian.add_column(style="white", overflow="fold")
            rincian.add_row("Judul", self._aman(manga_url))
            rincian.add_row("Chapter", f"[bold white]{total}[/bold white]")
            rincian.add_row("Worker", f"[bold white]{max_workers}[/bold white] paralel")
            rincian.add_row("Format", f"AVIF {getattr(scraper, 'AVIF_CODEC', 'svt')}   "
                                      f"kecepatan {getattr(scraper, 'AVIF_SPEED', 5)}   "
                                      f"crf {getattr(scraper, 'AVIF_CRF', 43)}   "
                                      f"lebar {getattr(scraper, 'DEFAULT_WIDTH', 500)} piksel")
            rincian.add_row("Gabung", f"{getattr(scraper, 'MERGE_TARGET_COUNT', 10)} gambar per strip, "
                                      f"hasilnya satu berkas CBZ")
            self.console.print()
            self.console.print(Panel(rincian, title="[bold green]Mulai mengunduh[/bold green]",
                                     title_align="left", box=box.ROUNDED,
                                     border_style="green", padding=(1, 3), expand=True))
            self.console.print()
        else:
            self.print(f"\n  Mulai mengunduh {total} chapter dengan {max_workers} worker")
            self.print(f"  Format  AVIF {getattr(scraper, 'AVIF_CODEC', 'svt')}  "
                       f"kecepatan {getattr(scraper, 'AVIF_SPEED', 5)}  "
                       f"crf {getattr(scraper, 'AVIF_CRF', 43)}  "
                       f"lebar {getattr(scraper, 'DEFAULT_WIDTH', 500)} piksel")
            self.print(f"  Gabung   {getattr(scraper, 'MERGE_TARGET_COUNT', 10)} gambar per strip, "
                       f"hasilnya satu berkas CBZ\n")

        
        # Create progress tracker
        progress = ProgressTracker(total)
        
        # Start download (kirim chapter pilihan user, bukan fetch ulang semua).
        # Ringkasan akhir sudah dicetak sendiri di dalam download_manga.
        scraper.download_manga(manga_url, max_workers=max_workers, progress=progress,
                               chapters=chapters)
    
    def _menu_setelah_unduh(self) -> str:
        """Menu yang muncul tepat setelah unduhan selesai.

        Return: 'judul' (lanjut ke prompt judul), 'impor', 'ganti-situs', 'keluar'.
        """
        self._menu_kartu("Unduhan selesai", [
            ("1", "Masukkan judul lain",
             "unduh judul berikutnya dari situs yang sama", BRAND),
            ("2", "Impor",
             "zip semua unduhan, rilis ke github, lalu kosongkan folder", ACCENT),
        ], "ketik nomor, atau b untuk ganti situs, q untuk keluar")

        jawab = (self._ask("nomor", default="1") or "1").strip().lower()
        if jawab in BACK_WORDS:
            return 'ganti-situs'
        if jawab in EXIT_WORDS:
            return 'keluar'
        if jawab == '2':
            return 'impor'
        return 'judul'

    def _jalankan_impor(self, scraper) -> None:
        """Zip semua unduhan, rilis ke GitHub (versi naik otomatis), lalu
        kosongkan folder unduhan kalau berhasil.

        Dijalankan SINKRON -- selesai dulu baru balik ke prompt judul, jadi
        tidak mungkin bertabrakan dengan unduhan. Selama proses ada animasi
        spinner yang teksnya ikut langkah impor (mengemas, mengunggah, ...).
        """
        from .impor import impor_downloads, ImporError, ada_isi

        folder = getattr(scraper, 'download_dir', 'downloads')
        if not ada_isi(folder):
            self._pesan("tidak ada unduhan untuk diimpor", WARN)
            return

        status = None

        def lapor(pesan: str):
            # Teks spinner diganti tiap langkah; tanpa rich, dicetak biasa.
            if status is not None:
                status.update(f"[bold cyan]{self._aman(pesan)}[/bold cyan]")
            else:
                self._pesan(pesan)

        hasil = None
        galat = None
        try:
            if HAS_RICH:
                with self.console.status("[bold cyan]menyiapkan impor[/bold cyan]",
                                         spinner="dots12") as status:
                    hasil = impor_downloads(folder, lapor=lapor,
                                            konfirmasi=lambda p: True)
            else:
                hasil = impor_downloads(folder, lapor=lapor,
                                        konfirmasi=lambda p: True)
        except ImporError as e:
            galat = str(e)
        except Exception as e:
            galat = f"{type(e).__name__}: {e}"

        if galat:
            self._pesan(f"impor gagal  {galat}", ERR)
        elif hasil:
            self._pesan("impor selesai", OK)
        else:
            self._pesan("impor tidak dijalankan", WARN)
        self.print()

    # ------------------------------------------------------------------
    # Mode paralel: beberapa judul sekaligus, satu papan ringkas
    # ------------------------------------------------------------------
    def _papan_batch(self, batch):
        """Cetak papan ringkas satu kali (snapshot sebelum prompt)."""
        if HAS_RICH:
            self.console.print()
            self.console.print(batch.papan())
            self.console.print()
        else:
            print()
            print(batch.papan())
            print()

    def _tambah_judul_batch(self, batch) -> None:
        """Pilih situs + judul + chapter, lalu masukkan ke antrean paralel.

        Unduhan yang sedang berjalan tetap jalan di belakang; fungsi ini cuma
        menyiapkan judul baru sampai siap dimasukkan ke antrean.
        """
        name, scraper = self.select_source(top_level=False)
        if name in (None, 'paralel') or scraper is None:
            return

        selected = self.search_manga(scraper)
        if selected is EXIT or selected is BACK or not selected:
            return

        if HAS_RICH:
            self.console.print(f"\n  [{MUTED}]membuka detail[/{MUTED}]  "
                               f"[bold white]{self._aman(selected['title'])}[/bold white]")
        else:
            print(f"\n  membuka detail  {selected['title']}")
        detail = scraper.get_manga_detail(selected['url'])
        if not detail:
            self._pesan("gagal membuka detail manga", ERR)
            return
        self.show_manga_detail(detail)

        chapters = self.select_chapters(detail['chapters'])
        if chapters is BACK or not chapters:
            self._pesan("tidak ada chapter yang dipilih", WARN)
            return

        if not self._confirm(f"tambahkan {detail['title']} ({len(chapters)} chapter) "
                             f"ke unduhan paralel", default=True):
            self._pesan("batal menambah judul", MUTED)
            return

        job = batch.tambah(scraper, selected['url'], chapters, detail['title'])
        if job is None:
            # Judul yang foldernya masih dipakai job lain ditolak supaya dua
            # unduhan tidak menulis folder (dan CBZ) yang sama berbarengan.
            self._pesan(batch.alasan_terakhir or 'judul ini tidak bisa ditambahkan', WARN)
            return
        self._pesan(f"ditambahkan: {job.id}  {detail['title']}   "
                    f"{len(chapters)} chapter", OK)

    def _mode_paralel(self) -> bool:
        """Unduh beberapa judul sekaligus (maks 5) dalam satu papan ringkas.

        Return True kalau user minta keluar aplikasi.
        """
        from .batch import BatchManager
        if self.batch is None:
            self.batch = BatchManager(max_judul=5)
        batch = self.batch
        batch.mulai()
        keluar_app = False
        try:
            while True:
                self._papan_batch(batch)
                self._menu_kartu("Mode unduh paralel", [
                    ("1", "Tambah judul",
                     f"pilih situs, cari judul, pilih chapter   "
                     f"({batch.aktif()} aktif / maks {batch.max_judul})", BRAND),
                    ("2", "Lihat progres",
                     "tampilkan papan sampai semua unduhan selesai", ACCENT),
                    ("3", "Selesai",
                     "kembali ke menu utama (yang masih jalan ditunggu dulu)", BRAND),
                ], "ketik nomor, atau b untuk kembali")

                jawab = (self._ask("nomor", default="1") or "1").strip().lower()
                if jawab in EXIT_WORDS:
                    keluar_app = True
                    break
                if jawab in BACK_WORDS:
                    break
                if jawab == '2':
                    batch.pantau()
                    continue
                if jawab == '3':
                    break

                if batch.aktif() >= batch.max_judul:
                    self._pesan(
                        f"sudah {batch.aktif()} judul aktif (maks {batch.max_judul}); "
                        f"pilih 2 untuk lihat progres, atau tunggu salah satu selesai", WARN)
                    continue
                self._tambah_judul_batch(batch)
        finally:
            # Unduhan yang masih jalan ditunggu supaya CBZ tidak setengah jadi.
            if not batch.semua_selesai():
                self._pesan("menunggu unduhan yang masih berjalan selesai", MUTED)
                batch.pantau()
            batch.tutup()
        return keluar_app

    def run(self):
        """Main CLI loop.

        Loop luar: pilih situs.
        Loop dalam (self._run_site): judul -> unduh -> judul baru, langsung
        minta judul berikutnya setelah download selesai. Tombol 'b' di prompt
        judul yang membawa user balik ke loop luar (pilih situs).
        """
        self.show_banner()
        
        loop_count = 0
        max_loops = 3  # Jaga-jaga kalau input EOF di pilihan situs
        
        while True:
            if loop_count >= max_loops:
                self._pesan("input habis, keluar", MUTED, depan="\n  ")
                break
            loop_count += 1
            
            # Pilih situs (menu pembuka: 'b' = keluar)
            source_name, scraper = self.select_source(top_level=True)
            
            if source_name == 'paralel':
                if self._mode_paralel():
                    break
                continue
            
            if source_name is None or scraper is None:
                break
            
            self.scraper = scraper
            
            # Sesi di satu situs: judul demi judul sampai user tekan b atau q
            if self._run_site(scraper):
                break
        
        self._pesan("sampai jumpa", MUTED, depan="\n  ")
    
    def _run_site(self, scraper) -> bool:
        """Loop judul di dalam satu situs yang sudah dipilih.

        Return True kalau user minta keluar (q), False kalau mau balik ke
        pilih situs (b / gagal / batal).
        """
        if HAS_RICH:
            self.console.print(f"  [{MUTED}]situs aktif[/{MUTED}]  "
                               f"[bold white]{self.source_name}[/bold white]")
        else:
            print(f"\n  situs aktif  {self.source_name}")
        self.print()
        
        while True:
            # 1. Minta judul (satu-satunya pintu keluar dari sesi ini)
            selected = self.search_manga(scraper)
            
            if selected is EXIT:
                return True
            if selected is BACK:
                self._pesan("ganti ke situs lain", MUTED)
                return False
            if not selected:
                # Tidak ada hasil / pilihan invalid: tanya ulang di situs yang sama
                confirm = (self._ask("coba judul lain di situs yang sama",
                                     default="ya") or "ya").strip().lower()
                if confirm in BACK_WORDS:
                    return False
                if confirm in EXIT_WORDS:
                    return True
                continue
            
            # 2. Detail manga
            if HAS_RICH:
                self.console.print(f"\n  [{MUTED}]membuka detail[/{MUTED}]  "
                                   f"[bold white]{self._aman(selected['title'])}[/bold white]")
            else:
                print(f"\n  membuka detail  {selected['title']}")
            detail = scraper.get_manga_detail(selected['url'])
            
            if not detail:
                self._pesan("gagal membuka detail manga", ERR)
                continue
            
            self.show_manga_detail(detail)
            
            # 3. Pilih chapter
            chapters = self.select_chapters(detail['chapters'])
            
            if chapters is BACK:
                self._pesan("ganti ke situs lain", MUTED)
                return False
            if not chapters:
                self._pesan("tidak ada chapter yang dipilih", WARN)
                continue
            
            # 4. Konfirmasi
            if HAS_RICH:
                self.console.print()
                self.console.print(f"  [{MUTED}]akan diunduh[/{MUTED}]  "
                                   f"[bold white]{len(chapters)}[/bold white] "
                                   f"[{MUTED}]chapter dari {self._aman(detail['title'])}[/{MUTED}]")
            
            if not self._confirm("lanjutkan download", default=True):
                self._pesan("batal, kembali ke prompt judul", MUTED)
                continue
            
            # 5. Download (ringkasan akhirnya sudah dicetak ProgressTracker.summary)
            self.download_with_progress(scraper, selected['url'], chapters)

            # 6. Setelah unduhan selesai: tawarkan judul lain atau impor.
            #    Apa pun pilihannya, kendali balik ke prompt judul situs ini.
            aksi = self._menu_setelah_unduh()

            if aksi == 'keluar':
                return True
            if aksi == 'ganti-situs':
                self._pesan("ganti ke situs lain", MUTED)
                return False
            if aksi == 'impor':
                self._jalankan_impor(scraper)

            # 'judul' -> loop lagi -> prompt judul di situs yang sama
            self.print()


def main():
    """Entry point"""
    cli = ComicCLI()
    cli.run()


if __name__ == '__main__':
    main()

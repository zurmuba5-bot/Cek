"""
UNDUH PARALEL BEBERAPA JUDUL (maks 5) dengan SATU PAPAN RINGKAS.

Kenapa ada modul ini: alur lama mengunduh satu judul sampai selesai baru bisa
milih judul lagi. Di sini tiap judul jadi satu pekerjaan (job) yang jalan di
thread sendiri, jadi kamu bisa menambah judul lain selagi yang sebelumnya masih
mengunduh.

Yang dijaga modul ini:
- Tiap judul punya identitas & folder sendiri (Job.id + Job.folder). Folder
  ditentukan sekali saat judul ditambahkan dan diserahkan ke base apa adanya,
  jadi tidak dihitung ulang dari judul di tengah jalan. Satu folder hanya boleh
  dipakai satu job: judul yang foldernya sudah dipakai job lain ditolak
  (lihat `tambah()`), dan sebagai jaring pengaman terakhir folder itu dikunci
  selama job menulis (`kunci_folder`). Hasilnya gambar/CBZ satu judul tidak
  akan pernah masuk ke folder atau CBZ judul lain.
- Maksimum beberapa judul aktif sekaligus (MAX_JUDUL, bawaan 5).
- Batas encode AVIF tetap satu untuk seluruh proses (semaphore convert di
  base.get_convert_semaphore). Tanpa itu, 5 judul = 5x encode serentak dan CPU
  justru makin lambat.
- Tampilan: satu papan (bukan banyak panel). Tiap judul satu baris: judul,
  bar, persen, jumlah chapter selesai/gagal/lewat, dan tahap yang sedang jalan.
- Keluaran teks dari base.py tidak dibiarkan tabrakan: selama mode batch,
  `base.UI` dimatikan (supaya print-nya polos) dan `sys.stdout` diganti router
  yang mengarahkan tulisan tiap thread ke penampung judulnya masing-masing.
  Di papan, log itu dipakai sebagai keterangan baris.

Modul ini tidak mengubah cara unduhan satuannya: ia memanggil
`BaseScraper.download_manga` yang sama seperti alur biasa.
"""
import io
import os
import sys
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import base as base_module
from .base import ProgressTracker

try:
    from rich.console import Console, Group
    from rich.live import Live
    from rich.text import Text
    RICH = True
except ImportError:                      # tanpa rich tetap jalan, tampilan polos
    RICH = False
    Live = None


# Tahap -> label singkat yang ditampilkan di papan (display saja).
_TAHAP_LABEL = {
    'antri': 'antri', 'buka': 'buka', 'unduh': 'unduh',
    'gabung': 'gabung', 'simpan': 'simpan',
    'selesai': 'selesai', 'gagal': 'gagal', 'lewat': 'lewat',
}


# ---------------------------------------------------------------------------
# KUNCI PER FOLDER JUDUL (berlaku untuk seluruh proses).
# Satu folder hanya boleh disentuh SATU job pada satu waktu. Ini jaring pengaman
# terakhir: kalau sampai ada dua job yang menunjuk folder yang sama (mis. judul
# beda tapi nama foldernya kebetulan sama), yang kedua menunggu -- bukan ikut
# menulis CBZ/cover/info.json yang sama berbarengan. Tanpa ini, dua penulis di
# path yang sama bikin CBZ rusak atau chapter-nya saling menimpa.
# ---------------------------------------------------------------------------
_kunci_folder: Dict[str, threading.RLock] = {}
_kunci_folder_guard = threading.Lock()


def kunci_path(folder: Any) -> str:
    """Kunci pembanding folder, menyesuaikan cara OS membandingkan nama berkas.

    Di Linux 'Solo_Leveling' dan 'solo_leveling' memang dua folder berbeda, jadi
    dibiarkan berbeda. Di Windows/macOS keduanya folder YANG SAMA (nama berkas di
    sana tidak beda huruf besar/kecil) -- kalau tidak disamakan, dua job bisa
    lolos dari pemeriksaan bentrok lalu menulis satu folder bersamaan.
    """
    teks = os.path.normcase(str(folder))
    if sys.platform == 'darwin':
        teks = teks.casefold()      # normcase tidak menurunkan huruf di macOS
    return teks


def kunci_folder(kunci: str) -> threading.RLock:
    """Ambil kunci (dibagi seluruh proses) untuk satu folder judul."""
    with _kunci_folder_guard:
        kunci_obj = _kunci_folder.get(kunci)
        if kunci_obj is None:
            kunci_obj = threading.RLock()
            _kunci_folder[kunci] = kunci_obj
        return kunci_obj


class _Router(io.TextIOBase):
    """Pengganti `sys.stdout`: tulisan tiap thread diarahkan ke penampungnya.

    Thread yang tidak terdaftar (mis. thread CLI sendiri) tetap ditulis ke
    stdout asli, jadi tampilan menu tidak ikut tertelan.
    """

    def __init__(self, asli):
        self.asli = asli
        self.peta: Dict[int, Any] = {}
        self.kunci = threading.Lock()

    def daftar(self, ident: int, sink) -> None:
        with self.kunci:
            self.peta[ident] = sink

    def lepas(self, ident: int) -> None:
        with self.kunci:
            self.peta.pop(ident, None)

    def write(self, teks: str) -> int:
        with self.kunci:
            sink = self.peta.get(threading.get_ident())
        if sink is None:
            try:
                return self.asli.write(teks)
            except Exception:
                return len(teks)
        try:
            sink(teks)
        except Exception:
            pass
        return len(teks)

    def flush(self) -> None:
        try:
            self.asli.flush()
        except Exception:
            pass

    @property
    def encoding(self):
        return getattr(self.asli, 'encoding', 'utf-8')

    def isatty(self) -> bool:
        # Harus cermin stdout asli: kalau terminal, papan rich boleh hidup.
        try:
            return bool(self.asli.isatty())
        except Exception:
            return False


class Job:
    """Satu judul yang diunduh: scraper + daftar chapter + tracker-nya."""

    def __init__(self, job_id: str, judul: str, scraper, manga_url: str,
                 chapters: List[Dict], folder: Path, maks_log: int = 40):
        self.id = job_id            # identitas job di papan/log (J1, J2, ...)
        self.judul = judul
        self.scraper = scraper
        self.manga_url = manga_url
        self.chapters = chapters
        # Folder tujuan job ini, ditentukan SEKALI saat ditambahkan dan dipakai
        # apa adanya sampai selesai. Judul yang foldernya sama ditolak di
        # BatchManager.tambah(), jadi satu folder = satu job.
        self.folder = folder
        self.kunci = kunci_folder(kunci_path(folder))
        self._log = deque(maxlen=maks_log)
        self._sisa = ''
        self._kunci = threading.Lock()
        self.progress = ProgressTracker(len(chapters), batch=True,
                                        log_sink=self.tulis)
        self.status = 'antri'          # antri | mulai | jalan | selesai | gagal
        self.error = ''
        self.mulai: Optional[float] = None
        self.selesai: Optional[float] = None
        self.thread: Optional[threading.Thread] = None

    # ---- penampung log ----
    def tulis(self, teks: str) -> None:
        """Terima potongan teks (dari router / log_sink), simpan per baris."""
        with self._kunci:
            self._sisa += teks
            while '\n' in self._sisa:
                baris, self._sisa = self._sisa.split('\n', 1)
                baris = baris.strip('\r').strip()
                if baris:
                    self._log.append(baris)
            if len(self._sisa) > 5000:     # pengaman kalau tidak ada newline
                self._sisa = self._sisa[-1000:]

    def log(self, n: int = 1) -> List[str]:
        with self._kunci:
            data = list(self._log)
        return data[-n:] if n else data

    def baris_log_baru(self) -> Optional[str]:
        """Keterangan singkat: baris log terakhir yang belum kosong."""
        with self._kunci:
            data = list(self._log)
        return data[-1] if data else None

    # ---- eksekusi ----
    def jalankan(self) -> None:
        self.status = 'jalan'
        self.mulai = time.time()
        try:
            # Kunci folder selama job ini menulis (lihat kunci_folder). Target
            # folder dikirim eksplisit supaya base tidak menghitung ulang dari
            # judul -- kalau judul dari API berubah sedikit, isinya tetap masuk
            # ke folder milik job ini, bukan folder judul lain.
            with self.kunci:
                hasil = self.scraper.download_manga(
                    self.manga_url, progress=self.progress,
                    chapters=self.chapters, target_dir=self.folder)
            if hasil is False:
                self.status = 'gagal'
                self.error = 'detail judul tidak terbaca, tidak ada yang diunduh'
            else:
                self.status = 'selesai'
        except Exception as exc:            # jangan sampai mematikan manager
            self.status = 'gagal'
            self.error = f"{type(exc).__name__}: {exc}"
        finally:
            self.tulis('\n')
            self.selesai = time.time()

    # ---- ringkasan ----
    @property
    def pct(self) -> float:
        total = self.progress.total or 1
        done = self.progress.completed + self.progress.failed + self.progress.skipped
        return min(100.0, done / total * 100) if self.progress.total else 0.0

    @property
    def selesai_total(self) -> bool:
        return self.status in ('selesai', 'gagal')

    def durasi(self) -> float:
        akhir = self.selesai or time.time()
        return max(0.0, akhir - (self.mulai or akhir))

    def tahap_sekarang(self) -> str:
        """Tahap yang sedang jalan (dari chapter yang paling lama aktif)."""
        p = self.progress
        with p._lock:
            if not p.in_progress:
                return ''
            c = sorted(p.in_progress, key=lambda k: p.in_progress[k]['start'])[0]
            return p._state.get(c, {}).get('tahap', '')


class BatchManager:
    """Kelola beberapa Job sekaligus + papan ringkasnya."""

    MAX_JUDUL = 5
    REFRESH_PER_SECOND = 8

    def __init__(self, max_judul: Optional[int] = None, console=None):
        self.max_judul = max(1, max_judul or self.MAX_JUDUL)
        self.jobs: List[Job] = []
        self._kunci = threading.Lock()
        self._folder: Dict[str, Job] = {}   # folder tujuan -> job pemakainya
        self._urut = 0                      # nomor job berikutnya (J1, J2, ...)
        self.alasan_terakhir = ''           # pesan kenapa tambah() ditolak
        self._router: Optional[_Router] = None
        self._ui_asli = None
        self.console = console or (Console(highlight=False, soft_wrap=True)
                                   if RICH else None)

    # ---------------------------------------------------------------- stdout
    def mulai(self) -> None:
        """Nyalakan mode batch: matikan UI rich base + pasang router stdout."""
        if self._router is not None:
            return
        self._ui_asli = base_module.UI
        base_module.UI = False          # print base.py jadi polos -> bisa ditangkap
        self._router = _Router(sys.stdout)
        sys.stdout = self._router

    def tutup(self) -> None:
        """Balikkan stdout & UI ke keadaan semula."""
        if self._router is None:
            return
        try:
            sys.stdout = self._router.asli
        except Exception:
            pass
        if self._ui_asli is not None:
            base_module.UI = self._ui_asli
        self._router = None

    # ---------------------------------------------------------------- job
    def aktif(self) -> int:
        with self._kunci:
            return sum(1 for j in self.jobs if j.status in ('mulai', 'jalan'))

    def jumlah(self) -> int:
        with self._kunci:
            return len(self.jobs)

    def semua_selesai(self) -> bool:
        with self._kunci:
            return all(j.selesai_total for j in self.jobs) if self.jobs else True

    @staticmethod
    def folder_judul(scraper, judul: str) -> Path:
        """Folder tujuan satu judul -- DIHITUNG SAMA seperti base.download_manga."""
        return Path(scraper.download_dir) / scraper._sanitize_filename(judul)

    def tambah(self, scraper, manga_url: str, chapters: List[Dict],
               judul: str) -> Optional[Job]:
        """Tambah satu judul ke antrean; langsung jalan kalau slot masih ada.

        Return None (dan isi `self.alasan_terakhir`) kalau folder judul ini
        masih dipakai job lain yang belum selesai. Dua job yang menulis folder
        yang sama akan saling menimpa CBZ-nya: hasilnya CBZ rusak atau chapter
        tercampur dari dua sumber -- jadi lebih baik ditolak, bukan dijalankan.
        """
        folder = self.folder_judul(scraper, judul)
        kunci = kunci_path(folder)
        with self._kunci:
            pemakai = self._folder.get(kunci)
            if pemakai is not None and not pemakai.selesai_total:
                # Judul & nama folder dipotong di pesan: judul panjang bisa bikin
                # baris peringatan di terminal jadi beberapa baris penuh.
                nama = judul if len(judul) <= 50 else judul[:49] + "…"
                nama_folder = folder.name
                if len(nama_folder) > 30:
                    nama_folder = nama_folder[:29] + "…"
                self.alasan_terakhir = (
                    f"{nama} sudah jalan sebagai {pemakai.id} "
                    f"({pemakai.status}), folder tujuannya sama ({nama_folder}) "
                    f"-- tunggu selesai atau pilih judul lain")
                return None
            self._urut += 1
            job = Job(f"J{self._urut}", judul, scraper, manga_url, chapters, folder)
            self.jobs.append(job)
            self._folder[kunci] = job
        self._coba_jalan()
        return job

    def _lepas_folder(self, job: Job) -> None:
        """Bebaskan folder job yang sudah beres (biar bisa diunduh ulang nanti)."""
        with self._kunci:
            kunci = kunci_path(job.folder)
            if self._folder.get(kunci) is job:
                self._folder.pop(kunci, None)

    def _coba_jalan(self) -> None:
        """Jalankan job yang mengantre selama jumlah aktif < max_judul."""
        with self._kunci:
            aktif = sum(1 for j in self.jobs if j.status in ('mulai', 'jalan'))
            siap = [j for j in self.jobs if j.status == 'antri']
            mulai = []
            for j in siap:
                if aktif >= self.max_judul:
                    break
                j.status = 'mulai'      # tanda sudah diserahkan ke thread
                mulai.append(j)
                aktif += 1

        gagal_start = False
        for job in mulai:
            t = threading.Thread(target=self._bungkus, args=(job,),
                                 name=f"batch-{job.judul[:14]}", daemon=True)
            job.thread = t
            try:
                t.start()
            except Exception as exc:
                # Jangan biarkan job nyangkut di status 'mulai': kalau tidak,
                # aktif() tidak pernah turun dan papan menunggu tanpa akhir.
                job.status = 'gagal'
                job.error = f"thread gagal dibuat  {type(exc).__name__}: {exc}"
                job.selesai = time.time()
                self._lepas_folder(job)
                gagal_start = True
        if gagal_start:
            self._coba_jalan()          # slot kosong -> coba job antre berikutnya

    def _bungkus(self, job: Job) -> None:
        ident = threading.get_ident()
        if self._router is not None:
            self._router.daftar(ident, job.tulis)
        try:
            job.jalankan()
        finally:
            if self._router is not None:
                self._router.lepas(ident)
            self._lepas_folder(job)
            self._coba_jalan()          # slot kosong -> jalankan antrean berikutnya

    def tunggu(self, timeout: Optional[float] = None) -> bool:
        """Tunggu sampai semua job selesai (tanpa papan)."""
        batas = None if timeout is None else time.time() + timeout
        while not self.semua_selesai():
            if batas is not None and time.time() >= batas:
                return False
            time.sleep(0.2)
        return True

    # ---------------------------------------------------------------- papan
    @staticmethod
    def _bar_bagi(pct: float, lebar: int = 14):
        """Bagi bar jadi (isi, kosong) supaya bisa diwarnai terpisah."""
        isi = int(lebar * max(0.0, min(1.0, pct / 100.0)))
        return "━" * isi, "━" * (lebar - isi)

    @classmethod
    def _bar(cls, pct: float, lebar: int = 14) -> str:
        """Bar versi teks polos (isi & kosong pakai karakter beda)."""
        isi, kosong = cls._bar_bagi(pct, lebar)
        return "█" * len(isi) + "░" * len(kosong)

    def _warna_status(self, status: str) -> str:
        return {'antri': 'grey42', 'mulai': 'bright_cyan', 'jalan': 'bright_cyan',
                'selesai': 'green', 'gagal': 'red'}.get(status, 'grey70')

    def papan(self):
        """Render papan (rich Group kalau ada rich, else string biasa)."""
        with self._kunci:
            jobs = list(self.jobs)
        aktif = sum(1 for j in jobs if j.status in ('mulai', 'jalan'))
        kepala = f"Unduh paralel   {aktif} aktif dari maks {self.max_judul}"
        if not RICH:
            baris = [kepala]
            for j in jobs:
                baris.append(self._baris_polos(j))
            return "\n".join(baris)

        isi = [Text(kepala, style="bold white")]
        if not jobs:
            isi.append(Text("  belum ada judul ditambahkan", style="grey42"))
        for j in jobs:
            isi.append(self._baris_rich(j))
        return Group(*isi)

    def _baris_polos(self, job: Job) -> str:
        p = job.progress
        done = p.completed + p.failed + p.skipped
        tahap = job.tahap_sekarang() or _TAHAP_LABEL.get(job.status, job.status)
        return (f"  {job.id:>3s} {job.judul[:32]:32s} {self._bar(job.pct)} {job.pct:3.0f}%  "
                f"{done}/{p.total} chapter  gagal {p.failed}  lewat {p.skipped}  {tahap}")

    def _baris_rich(self, job: Job) -> Text:
        p = job.progress
        done = p.completed + p.failed + p.skipped
        warna = self._warna_status(job.status)
        b = Text()
        b.append("  ")
        b.append(f"{job.id:>3s}", style="bold grey70")
        b.append("  ")
        judul = job.judul if len(job.judul) <= 30 else job.judul[:29] + "…"
        b.append(f"{judul:30s}", style="bold white")
        b.append("  ")
        isi_bar, kosong_bar = self._bar_bagi(job.pct)
        b.append(isi_bar, style="bold spring_green2")
        b.append(kosong_bar, style="grey27")
        b.append(f" {job.pct:3.0f}%", style="bold white")
        b.append(f"   {done}/{p.total}", style="grey70")
        b.append("   gagal ", style="grey50")
        b.append(str(p.failed), style="red" if p.failed else "grey50")
        b.append("   lewat ", style="grey50")
        b.append(str(p.skipped), style="yellow" if p.skipped else "grey50")
        b.append("   ")
        tahap = job.tahap_sekarang() or _TAHAP_LABEL.get(job.status, job.status)
        b.append(tahap, style=warna)
        if job.status == 'selesai':
            b.append(f"   {job.durasi():.0f} detik", style="grey58")
        elif job.status == 'gagal':
            b.append(f"   {job.error[:40]}", style="red")
        else:
            keterangan = job.baris_log_baru()
            if keterangan:
                b.append(f"   {keterangan[:48]}", style="grey58")
        return b

    def snapshot(self):
        """Papan sekali cetak (buat ditampilkan sebelum prompt)."""
        return self.papan()

    def pantau(self) -> None:
        """Tampilkan papan hidup sampai semua job selesai."""
        if not RICH or self.console is None or not self.console.is_terminal:
            self.tunggu()
            keluaran = self.papan()
            if self.console is not None:
                self.console.print(keluaran)
            else:
                print(keluaran)
            return
        with Live(self.papan(), console=self.console,
                  refresh_per_second=self.REFRESH_PER_SECOND) as live:
            while not self.semua_selesai():
                live.update(self.papan(), refresh=True)
                time.sleep(0.12)
            live.update(self.papan(), refresh=True)

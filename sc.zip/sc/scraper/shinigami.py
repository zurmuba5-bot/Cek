"""
Scraper for shinigami.asia (API publik api.shngm.io + gambar di assets.shngm.id)

Endpoint/alur diambil dari extension Tachiyomi/Mihon "Shinigami" (sample/shinigami.kt)
dan sudah dicek langsung ke API-nya:
  1. Cari judul      : GET {API}/v1/manga/list?page=..&page_size=..&q=<q>
  2. Daftar populer  : GET {API}/v1/manga/list?...&sort=popularity
  3. Detail manga    : GET {API}/v1/manga/detail/{manga_id}
  4. Daftar chapter  : GET {API}/v1/chapter/{manga_id}/list?page_size=3000
  5. Isi chapter     : GET {API}/v1/chapter/detail/{chapter_id}
                       -> data.base_url + data.chapter.path + data.chapter.data[]
  6. Gambar          : URL absolut di assets.shngm.id (sudah urut sesuai array)

Catatan penting:
- Chapter diidentifikasi `chapter_id` (UUID), bukan nomor. Nomor bab
  (`chapter_number`) bisa desimal (mis. 717.5), jadi judul dibentuk
  "Chapter <nomor>" dan nomor desimal tetap dibiarkan apa adanya.
- URUTAN GAMBAR: API mengirim array `chapter.data` dalam urutan halaman baca
  (mis. 00-xxx.jpg, 01-xxx.jpg, ... 98-xxx.jpg, lalu halaman credit di akhir).
  Jadi urutannya eksplisit dari sumber -- tidak ditebak dari nama file, apalagi
  karena di akhir ada nama yang bukan angka murni ("998DE-...", "9999-...").
- Extension aslinya membatasi 3 permintaan serentak ke API-nya (`rateLimit(3)`).
  Batas itu dijaga lewat semaphore untuk panggilan API; gambar di host terpisah
  (assets.shngm.id) tidak dibatasi (dibuktikan: tanpa header khusus pun balas
  file asli).
- Halaman detail chapter di API mengembalikan kunci `data.chapter.data`. Kunci
  versi lama (`page_list.chapter_page.pages`) tetap didukung sebagai cadangan
  supaya tidak gampang rusak kalau API-nya berubah.
"""
import re
import time
import threading
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote

from .base import BaseScraper


class ShinigamiScraper(BaseScraper):
    """Scraper for shinigami.asia"""

    BASE_URL = "https://shinigami.asia"
    API_URL = "https://api.shngm.io"

    # Sama seperti voratoon: 1 chapter = 1 permintaan API + download gambar
    # paralel. Worker chapter dinaikkan ke 8; API tetap dibatasi 3 serentak
    # (API_CONCURRENCY) supaya banyak worker tidak menghujani api.shngm.io.
    MAX_WORKERS = 8
    INNER_DOWNLOAD_WORKERS = 4
    SEARCH_LIMIT = 20

    API_CONCURRENCY = 3
    API_RETRIES = 3
    API_RETRY_DELAY = 1

    # manga_id / chapter_id berbentuk UUID.
    SERIES_ID_RE = re.compile(r'/series/([^/?#]+)')
    UUID_RE = re.compile(
        r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-'
        r'[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')

    # status di API: 1 ongoing, 2 completed, 3 hiatus
    STATUS_MAP = {1: 'Ongoing', 2: 'Completed', 3: 'Hiatus'}

    IMAGE_HEADERS = {
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'DNT': '1',
        'sec-fetch-dest': 'empty',
        'Sec-GPC': '1',
    }

    def __init__(self, download_dir: str = "downloads"):
        super().__init__(download_dir)
        self._api_sem = threading.BoundedSemaphore(self.API_CONCURRENCY)

    # ---------------------------------------------------------------- API
    def _api_get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Optional[Any]:
        """GET JSON dari API, dengan batas serentak + percobaan ulang."""
        url = path if path.startswith('http') else f"{self.API_URL}{path}"
        headers = {
            'Accept': 'application/json',
            'DNT': '1',
            'Sec-GPC': '1',
        }
        for attempt in range(self.API_RETRIES):
            try:
                with self._api_sem:
                    resp = self.session.get(url, params=params, timeout=30,
                                            headers=headers)
                resp.raise_for_status()
                return resp.json()
            except Exception:
                if attempt < self.API_RETRIES - 1:
                    time.sleep(self.API_RETRY_DELAY * (attempt + 1))
        return None

    @staticmethod
    def _rows(payload: Optional[Any]) -> List[Dict[str, Any]]:
        """Ambil list `data` dari balasan API ({retcode, message, meta, data})."""
        if not isinstance(payload, dict):
            return []
        rows = payload.get('data')
        return rows if isinstance(rows, list) else []

    @staticmethod
    def _names(items: Any) -> str:
        """Gabung taxonomy [{name: ...}] jadi 'A, B'."""
        if not isinstance(items, list):
            return ''
        return ', '.join(n.get('name', '') for n in items if n.get('name'))

    @staticmethod
    def _chapter_label(number: Any) -> str:
        """Nomor bab jadi label: 918 -> '918', 717.5 -> '717.5', 4.0 -> '4'."""
        try:
            if float(number).is_integer():
                return str(int(float(number)))
        except (TypeError, ValueError):
            pass
        return str(number)

    @classmethod
    def _row_to_result(cls, row: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Ubah 1 baris list manga jadi hasil pencarian untuk CLI."""
        manga_id = (row.get('manga_id') or '').strip()
        if not manga_id:
            return None
        latest = row.get('latest_chapter_number')
        taxonomy = row.get('taxonomy') or {}
        return {
            'title': row.get('title') or manga_id,
            'url': f"{cls.BASE_URL}/series/{manga_id}",
            'slug': manga_id,
            'manga_id': manga_id,
            'type': cls._names(taxonomy.get('Format')),
            'cover_url': row.get('cover_portrait_url') or row.get('cover_image_url') or '',
            'chapter_latest': f"Chapter {cls._chapter_label(latest)}"
                              if latest not in (None, '') else '',
            'rating': row.get('user_rate') if row.get('user_rate') not in (None, '') else '',
        }

    # ---------------------------------------------------------------- publik
    def search(self, query: str) -> List[Dict[str, Any]]:
        """Cari judul lewat /v1/manga/list (parameter `q`)."""
        q = (query or '').strip()
        params = {'page': 1, 'page_size': self.SEARCH_LIMIT}
        if q:
            params['q'] = q

        payload = self._api_get('/v1/manga/list', params=params)
        results = []
        for row in self._rows(payload):
            item = self._row_to_result(row)
            if item:
                results.append(item)
        
        # API mengurut menurut popularitas/relevansi internal; judul yang persis
        # diketik user ditarik ke atas dulu, baru dipotong ke SEARCH_LIMIT
        # (lihat BaseScraper._urut_hasil_pencarian).
        results = self._urut_hasil_pencarian(query, results)
        return results[:self.SEARCH_LIMIT]

    def get_popular(self, page: int = 1) -> List[Dict[str, Any]]:
        """Judul populer (dipakai sebagai cadangan)."""
        payload = self._api_get('/v1/manga/list',
                                params={'page': page, 'page_size': self.SEARCH_LIMIT,
                                        'sort': 'popularity'})
        return [r for r in (self._row_to_result(row)
                            for row in self._rows(payload)) if r]

    def manga_id_from_url(self, url: str) -> str:
        """Ambil manga_id dari URL seri. Terima URL web maupun API."""
        match = self.SERIES_ID_RE.search(url or '')
        if match:
            return match.group(1).strip()
        match = self.UUID_RE.search(url or '')
        return match.group(0) if match else ''

    def chapter_id_from_url(self, url: str) -> str:
        """Ambil chapter_id (UUID) dari URL chapter."""
        match = self.UUID_RE.search(url or '')
        return match.group(0) if match else ''

    def get_manga_detail(self, url: str) -> Optional[Dict[str, Any]]:
        """Detail manga + daftar chapter dari API."""
        manga_id = self.manga_id_from_url(url)
        if not manga_id:
            return None

        payload = self._api_get(f"/v1/manga/detail/{quote(manga_id)}")
        data = (payload or {}).get('data')
        if not isinstance(data, dict) or not data:
            return None

        title = data.get('title') or manga_id
        taxonomy = data.get('taxonomy') or {}
        cover_url = data.get('cover_portrait_url') or data.get('cover_image_url') or ''
        genres = [n.get('name', '') for n in (taxonomy.get('Genre') or [])
                  if n.get('name')]

        chapters = self._chapter_entries(manga_id)

        info = {
            'title': title,
            'alternative_title': data.get('alternative_title') or '',
            'type': self._names(taxonomy.get('Format')),
            'author': self._names(taxonomy.get('Author')),
            'artist': self._names(taxonomy.get('Artist')),
            'status': self.STATUS_MAP.get(data.get('status'), ''),
            'rating': data.get('user_rate') if data.get('user_rate') not in (None, '') else '',
            'release_date': data.get('release_year') or '',
            'total_chapters': len(chapters),
        }

        return {
            'title': title,
            'cover_url': cover_url,
            'cover_candidates': [cover_url] if cover_url else [],
            'genres': genres,
            'synopsis': (data.get('description') or '').strip(),
            'info': info,
            'total_chapters': len(chapters),
            'source': 'shinigami.asia',
            'source_url': f"{self.BASE_URL}/series/{manga_id}",
            'chapters': chapters,
        }

    def _chapter_entries(self, manga_id: str) -> List[Dict[str, Any]]:
        """Daftar chapter (urut terbaru -> terlama, seperti API).

        Dibuat unik per `chapter_id` supaya tidak ada chapter dobel yang
        diunduh berulang ke CBZ yang sama.
        """
        payload = self._api_get(f"/v1/chapter/{quote(manga_id)}/list",
                                params={'page_size': 3000})
        rows = self._rows(payload)

        chapters = []
        dilihat = set()
        for row in rows:
            chapter_id = (row.get('chapter_id') or '').strip()
            if not chapter_id or chapter_id in dilihat:
                continue
            dilihat.add(chapter_id)
            number = self._chapter_label(row.get('chapter_number'))
            extra = (row.get('chapter_title') or '').strip()
            title = f"Chapter {number}"
            if extra:
                title = f"{title} {extra}"
            chapters.append({
                'title': title,
                'url': f"{self.API_URL}/v1/chapter/detail/{chapter_id}",
                'chapter_id': chapter_id,
                'number': number,
            })
        return chapters

    @staticmethod
    def _join_image_url(base: str, path: str, name: str) -> str:
        """Satukan base_url + path + nama file jadi URL gambar utuh."""
        base = (base or '').rstrip('/')
        path = (path or '')
        if path and not path.startswith('/'):
            path = '/' + path
        return f"{base}{path}{name}"

    def _page_names(self, data: Dict[str, Any]) -> Tuple[str, str, List[str]]:
        """Ambil (base_url, path, daftar nama gambar) dari detail chapter.

        Format sekarang: data.base_url + data.chapter.{path,data}.
        Cadangan format lama: data.page_list.{baseUrl,chapterPage.{path,pages}}.
        """
        base = data.get('base_url') or data.get('base_url_low') or ''
        chapter = data.get('chapter')
        if isinstance(chapter, dict):
            names = chapter.get('data') or []
            if names:
                return base, chapter.get('path') or '', names

        page_list = data.get('page_list') or {}
        chapter_page = page_list.get('chapter_page') or {}
        names = chapter_page.get('pages') or []
        base = base or page_list.get('base_url') or page_list.get('baseUrl') or ''
        return base, chapter_page.get('path') or '', names

    def get_chapter_images_ordered(self, url: str) -> List[Dict[str, Any]]:
        """Daftar gambar 1 chapter (API mengirim array urut sesuai halaman)."""
        chapter_id = self.chapter_id_from_url(url)
        if not chapter_id:
            return []

        payload = self._api_get(f"/v1/chapter/detail/{quote(chapter_id)}")
        data = (payload or {}).get('data')
        if not isinstance(data, dict):
            return []

        base, path, names = self._page_names(data)
        if not base or not names:
            return []

        return [
            {'order': i, 'url': self._join_image_url(base, path, name)}
            for i, name in enumerate(names, 1)
            if isinstance(name, str) and name.strip()
        ]

    def get_chapter_images(self, url: str) -> List[str]:
        """Get all image URLs for a chapter (backward compatible)"""
        ordered = self.get_chapter_images_ordered(url)
        return [img['url'] for img in ordered]

    def _download_image_with_retry(self, url: str) -> Optional[bytes]:
        """Unduh gambar halaman (assets.shngm.id) dengan header seperti extension."""
        for attempt in range(self.MAX_RETRIES):
            try:
                resp = self.session.get(url, timeout=30, headers=self.IMAGE_HEADERS)
                resp.raise_for_status()
                data = resp.content
                if len(data) < 1000:      # kemungkinan balasan error, bukan gambar
                    raise Exception("Image data too small")
                return data
            except Exception:
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY)
        return None

    def download_manga(self, manga_url: str, max_workers: int = None, progress=None,
                       chapters=None, target_dir=None) -> bool:
        """Unduh pakai mesin base.py (tanpa perlakuan khusus).

        `target_dir` diteruskan apa adanya: mode paralel sudah menentukan folder
        milik judul ini, jadi base tidak perlu menghitung ulang dari judul.
        """
        return super().download_manga(manga_url, max_workers=max_workers,
                                      progress=progress, chapters=chapters,
                                      target_dir=target_dir)

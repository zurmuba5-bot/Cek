"""
Base scraper with 10 parallel workers + Progress UI + Validation
"""
import os
import re
import json
import time
import io
import zipfile

# Senyapkan log SVT-AV1 (banner versi + info/warn dicetak ke stderr tiap encode,
# bikin progress UI penuh). HARUS diset sebelum pillow_avif diimpor: nilainya
# dibaca sekali saja saat pertama kali encoder dipakai, jadi mengubahnya setelah
# encode pertama tidak berpengaruh. Level: 0 senyap total, 1 = error saja (dipakai),
# 2 = warning, 3+ = info lengkap. Mau lihat log penuh? `SVT_LOG=3 python3 main.py`.
os.environ.setdefault("SVT_LOG", "1")

import requests
import pillow_avif
from urllib.parse import urlsplit
from PIL import Image
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock, Event, BoundedSemaphore


# komikindo (WordPress) nyimpen thumbnail sebagai "namafile-223x319.jpg".
# Buang suffix ukuran itu buat nembak file aslinya (kualitas penuh).
WP_THUMB_SIZE_RE = re.compile(
    r'-\d{2,4}x\d{2,4}(?=\.(?:jpe?g|png|webp|gif|avif|bmp)(?:$|\?))', re.IGNORECASE)
SIZE_PARAM_NAMES = {'w', 'h', 'resize', 'width', 'height', 'q', 'quality'}


# ---------------------------------------------------------------------------
# BATAS convert AVIF untuk SELURUH proses (bukan per scraper).
# Dulu semaphore ini dibuat per-instance, jadi kalau beberapa judul diunduh
# berbarengan tiap judul punya batasnya sendiri -> encode AVIF (CPU-bound) bisa
# jalan berkali-kali lebih banyak dari jumlah core dan saling memperlambat.
# Semaphore bersama di sini menjaga batas CPU tetap satu berapa pun jumlah
# judul yang jalan bareng.
# ---------------------------------------------------------------------------
_convert_sem_global: Optional[BoundedSemaphore] = None
_convert_sem_guard = Lock()


def get_convert_semaphore(limit: int) -> BoundedSemaphore:
    """Semaphore convert bersama seluruh proses; dibuat sekali oleh scraper
    pertama dengan `limit` (CONVERT_CONCURRENCY)-nya."""
    global _convert_sem_global
    with _convert_sem_guard:
        if _convert_sem_global is None:
            _convert_sem_global = BoundedSemaphore(max(1, limit))
        return _convert_sem_global


# ---------------------------------------------------------------------------
# TAMPILAN (display saja) -- tidak ada logika unduhan di blok ini.
# Semua angka tetap dihitung seperti semula di ProgressTracker; kode di bawah
# cuma mengatur bagaimana hasilnya digambar ke layar.
# ---------------------------------------------------------------------------
try:
    from rich.console import Console
    from rich.text import Text
    from rich.console import Group
    from rich.panel import Panel
    from rich.table import Table
    from rich.cells import cell_len
    from rich.control import Control
    from rich.live import Live
    from rich.segment import ControlType
    from rich import box as rich_box
    UI = True
except ImportError:              # rich opsional: tanpa itu tampilannya polos
    UI = False
    Live = None

    def cell_len(teks: str) -> int:
        """Cadangan kalau rich tidak terpasang."""
        return len(teks)

ui_console = Console(highlight=False, soft_wrap=True) if UI else None


def ui_step(nomor: str, judul: str):
    """Judul langkah (1 dari 4, 2 dari 4, ...) -- display saja."""
    if UI:
        ui_console.print(f"\n  [bold bright_cyan]langkah {nomor}[/bold bright_cyan]   "
                         f"[bold white]{judul}[/bold white]")
    else:
        print(f"\n  langkah {nomor}   {judul}")


class ProgressTracker:
    """Track and display download progress"""

    _BAR_WIDTH = 26              # lebar bar progres (display)
    _BAR_CHAPTER = 16            # lebar bar per chapter di papan proses (display)

    # Tahap tiap chapter, dibaca dari pesan update_chapter() di _process_chapter
    # (display saja, bukan logic): (pola, tahap, jumlah, satuan).
    _POLA_TAHAP = (
        (re.compile(r'^Fetching image list'), 'buka', None, None),
        (re.compile(r'^Found (\d+) images'), 'unduh', 0, 'gambar'),
        (re.compile(r'^Downloaded (\d+)/(\d+)'), 'unduh', None, 'gambar'),
        (re.compile(r'^Merging \d+ -> (\d+) images'), 'gabung', 0, 'strip'),
        (re.compile(r'^Merged (\d+)/(\d+)'), 'gabung', None, 'strip'),
        (re.compile(r'^Packing CBZ'), 'simpan', None, None),
    )
    # Warna tiap tahap di papan proses (display).
    _GAYA_TAHAP = {
        'antri': 'grey42', 'buka': 'grey70', 'unduh': 'bright_cyan',
        'gabung': 'bright_magenta', 'simpan': 'bright_yellow',
        'selesai': 'bold green', 'gagal': 'bold red', 'lewat': 'yellow',
    }

    def __init__(self, total_chapters: int, batch: bool = False, log_sink=None):
        self.total = total_chapters
        self.completed = 0
        self.failed = 0
        self.skipped = 0
        self.in_progress = {}
        self._lock = Lock()
        self.start_time = time.time()
        self.results = []  # Track all results
        # Chapter yang CBZ-nya bolong: (judul chapter, [nomor halaman gagal]).
        self._halaman_gagal: List[Tuple[str, List[Any]]] = []
        # --- mode batch (beberapa judul diunduh berbarengan) ---
        # batch=True -> papan/Live per judul dimatikan; koordinator di luar yang
        # menggambar semuanya. log_sink mengarahkan baris log kenampung judul
        # masing-masing supaya tidak tabrakan dengan judul lain.
        self.batch = batch
        self.log_sink = log_sink
        # --- state khusus tampilan (tidak dipakai logika unduhan) ---
        self._activity = ""
        self._painted = 0        # lebar baris status yang sedang menempel di layar
        self._state = {}         # judul chapter -> tahap yang sedang berjalan
        self._jejak = []         # judul chapter yang baru selesai (jejak hijau)
        self._judul_manga = ""   # judul manga buat kepala papan
        self._live_obj = None    # papan proses multi baris (rich Live)

    # ------------------------------------------------------------------
    # Papan proses per chapter (display). Isinya cuma rekap tahap dari
    # update_chapter/complete_chapter/fail_chapter/skip_chapter.
    # ------------------------------------------------------------------
    @staticmethod
    def _state_baru():
        return {'tahap': 'antri', 'done': 0, 'total': 0, 'catatan': ''}

    def set_daftar_chapter(self, judul_list, judul_manga: str = ""):
        """Beri tahu papan proses chapter apa saja yang akan jalan (display)."""
        with self._lock:
            self._state = {str(j): self._state_baru() for j in judul_list}
            self._jejak = []
            self._judul_manga = judul_manga

    def _tahap(self, chapter: str):
        return self._state.setdefault(chapter, self._state_baru())

    def _tahap_dari_pesan(self, pesan: str):
        """Terjemahkan pesan update_chapter() jadi (tahap, selesai, total, satuan).

        Dipanggil dari thread worker, jadi tidak boleh melempar error sama sekali;
        kalau polanya tidak cocok, tahap tidak berubah dan pesan dipakai sebagai rincian.
        """
        try:
            for pola, tahap, tetap, satuan in self._POLA_TAHAP:
                cocok = pola.match(pesan)
                if not cocok:
                    continue
                if pola.groups == 0:
                    return tahap, 0, 0, None
                if tetap is not None:
                    return tahap, tetap, int(cocok.group(1)), satuan
                return tahap, int(cocok.group(1)), int(cocok.group(2)), satuan
        except Exception:
            pass
        return None, None, None, None

    def _tandai_selesai(self, chapter: str, tahap: str, catatan: str = ""):
        s = self._tahap(chapter)
        s['tahap'] = tahap
        s['done'] = 1
        s['total'] = 1
        s['catatan'] = catatan
        if tahap != 'antri':
            self._jejak.append(chapter)
            del self._jejak[:-12]

    def _segarkan(self):
        """Gambar ulang papan proses kalau sedang hidup (display).

        Kegagalan gambar tidak boleh menghentikan chapter yang sedang diunduh,
        jadi errornya ditelan di sini."""
        if self._live_obj is not None:
            try:
                self._live_obj.update(self._papan(), refresh=True)
            except Exception:
                pass

    def mulai_papan(self):
        """Nyalakan papan proses multi baris. Di non-terminal dibiarin mati,
        outputnya tetap log satu baris per kejadian seperti biasa."""
        if self.batch or not self._live or self._live_obj is not None:
            return
        try:
            self._live_obj = Live(self._papan(), console=ui_console, refresh_per_second=8)
            self._live_obj.start()
        except Exception:
            self._live_obj = None

    def selesai_papan(self):
        """Matikan papan proses; hasil akhirnya dibiarkan kelihatan di layar."""
        live, self._live_obj = self._live_obj, None
        if self.batch or live is None:
            return
        try:
            live.update(self._papan(), refresh=True)
        except Exception:
            pass
        try:
            live.stop()
        except Exception:
            pass
    
    def start_chapter(self, chapter: str, worker_id: int = 0):
        with self._lock:
            self.in_progress[chapter] = {
                'start': time.time(),
                'worker': worker_id
            }
            self._activity = ""
            s = self._tahap(chapter)
            s['tahap'] = 'buka'
            s['done'] = 0
            s['total'] = 0
            s['catatan'] = ""
            if self._live_obj is not None:
                self._segarkan()
            else:
                self._paint()
    
    def update_chapter(self, chapter: str, message: str):
        with self._lock:
            if chapter in self.in_progress:
                self._activity = f"{chapter}   {message}"
                tahap, done, total, satuan = self._tahap_dari_pesan(message)
                s = self._tahap(chapter)
                if tahap:
                    s['tahap'] = tahap
                    s['done'] = done
                    s['total'] = total
                    s['catatan'] = f"{done} dari {total} {satuan}" if total else ""
                else:
                    s['catatan'] = message
                if self._live_obj is not None:
                    self._segarkan()
                else:
                    self._paint()
    
    @staticmethod
    def _ringkas_halaman(nomor: List[Any], batas: int = 8) -> str:
        """Nomor halaman jadi teks ringkas: '12, 47, 71, dan 4 lagi'."""
        daftar = ', '.join(str(n) for n in nomor[:batas])
        sisa = len(nomor) - batas
        return f"{daftar}, dan {sisa} lagi" if sisa > 0 else daftar

    def complete_chapter(self, chapter: str, size_kb: float, images: int = 0,
                         gagal: Optional[List[Any]] = None):
        """Chapter selesai. `gagal` = nomor halaman yang gambarnya gagal diunduh.

        Halaman yang gagal diunduh memang tidak ada di CBZ-nya (lihat
        _process_chapter), dan dulu itu lewat tanpa kabar sama sekali selama
        masih di bawah 20% -- chapter kelihatan "selesai" padahal bolong, yang
        dibaca jadi seperti urutan yang lompat. Sekarang dilaporkan di baris
        chapter ini dan diulang lagi di ringkasan akhir.
        """
        halaman_gagal = sorted(gagal or [])
        with self._lock:
            self.completed += 1
            worker = self.in_progress.get(chapter, {}).get('worker', 0)
            elapsed = 0
            if chapter in self.in_progress:
                elapsed = time.time() - self.in_progress[chapter]['start']
                del self.in_progress[chapter]
            
            self.results.append({
                'chapter': chapter,
                'status': 'success',
                'size_kb': size_kb,
                'images': images,
                'time': elapsed,
                'gagal_halaman': halaman_gagal,
            })
            if halaman_gagal:
                self._halaman_gagal.append((chapter, halaman_gagal))
            ukuran = f"{size_kb / 1024:.1f} MB" if size_kb >= 1024 else f"{size_kb:.0f} KB"
            rincian = f"      {ukuran}"
            if images:
                rincian += f"      {images} halaman"
            rincian += f"      {elapsed:.1f} detik"
            # Papan proses: baris hijau untuk chapter yang baru kelar.
            catatan = f"{ukuran}   {images} halaman   {elapsed:.1f} detik" if images \
                else f"{ukuran}   {elapsed:.1f} detik"
            if halaman_gagal:
                catatan = (f"{catatan}   {len(halaman_gagal)} halaman gagal")
            self._tandai_selesai(chapter, 'selesai', catatan)
            if self._live_obj is not None:
                self._segarkan()
            else:
                self._log(self._mk(("  ", ""), (self._pad(chapter, 30), "bold white"),
                                   (rincian, "grey62")))
                if halaman_gagal:
                    self._log(self._mk(("  ", ""), (self._pad('', 30), ""),
                                       (f"      {len(halaman_gagal)} halaman gagal "
                                        f"diunduh (nomor {self._ringkas_halaman(halaman_gagal)})",
                                        "yellow")))
    
    def fail_chapter(self, chapter: str, reason: str):
        with self._lock:
            self.failed += 1
            worker = self.in_progress.get(chapter, {}).get('worker', 0)
            if chapter in self.in_progress:
                del self.in_progress[chapter]
            
            self.results.append({
                'chapter': chapter,
                'status': 'failed',
                'reason': reason
            })
            self._tandai_selesai(chapter, 'gagal', reason)
            if self._live_obj is not None:
                self._segarkan()
            else:
                self._log(self._mk(("  ", ""), (self._pad(chapter, 30), "white"),
                                   (f"      gagal, {reason}", "red")))
    
    def skip_chapter(self, chapter: str):
        with self._lock:
            self.skipped += 1
            self.results.append({
                'chapter': chapter,
                'status': 'skipped'
            })
            self._tandai_selesai(chapter, 'lewat', "sudah ada, dilewati")
            if self._live_obj is not None:
                self._segarkan()
            else:
                self._log(self._mk(("  ", ""), (self._pad(chapter, 30), "grey62"),
                                   (f"      sudah ada, dilewati", "grey50")))
    
    # ------------------------------------------------------------------
    # Penggambaran status (display). Nilai-nilainya sudah dihitung di atas.
    # ------------------------------------------------------------------
    @property
    def _live(self) -> bool:
        """Bar bergerak cuma kalau outputnya terminal (bukan pipe/redirect)."""
        return bool(UI and ui_console is not None and ui_console.is_terminal)

    def _mk(self, *parts):
        """Susun satu baris: Text berwarna kalau rich ada, teks biasa kalau tidak."""
        if UI:
            baris = Text()
            for teks, gaya in parts:
                baris.append(teks, style=gaya)
            return baris
        return "".join(teks for teks, _ in parts)

    def _pad(self, teks: str, lebar: int) -> str:
        """Samakan lebar kolom teks biar log rapi sejajar (display)."""
        return f"{teks}{' ' * max(0, lebar - cell_len(teks))}"

    def _erase(self):
        """Hapus baris status yang menempel supaya log tidak tabrakan."""
        if self.batch or not self._painted:
            return
        if UI:
            ui_console.control(Control(ControlType.CARRIAGE_RETURN))
            ui_console.control(Control((ControlType.ERASE_IN_LINE, 2)))
        else:
            print(f"\r{' ' * self._painted}\r", end="", flush=True)
        self._painted = 0

    def _status_parts(self, lebar: Optional[int] = None):
        """Potongan teks + warna penyusun baris status.

        `lebar` = lebar layar. Di layar sempit labelnya dipendekkan dan bar
        tetap dapat ruang; kalau activity muat, bar boleh menyusut dikit.
        Kalau activity tidak muat, dia disembunyikan -- daripada tampil
        sepotong judul chapter."""
        done = self.completed + self.failed + self.skipped
        total = self.total if self.total > 0 else 1
        pct = min(100.0, (done / total * 100) if self.total > 0 else 0.0)
        elapsed = int(time.time() - self.start_time)
        aktif = len(self.in_progress)

        # Layar sempit: label pendek, bar dapat ruang lebih banyak.
        rapi = not lebar or lebar < 96
        gap = "  " if rapi else "     "
        satuan = "%" if rapi else " persen"
        maks_bar = 32 if rapi else 36
        
        # Panjang semua teks selain bar, dihitung dari string biar akurat.
        ekor = (f"   {pct:.0f}{satuan}"
                f"{gap}selesai {self.completed}"
                f"{gap}gagal {self.failed}"
                f"{gap}lewat {self.skipped}"
                f"{gap}sisa {max(0, self.total - done)}"
                f"{gap}{elapsed // 60}:{elapsed % 60:02d}")
        lebar_bar = (lebar - 2 - len(ekor)) if lebar else self._BAR_WIDTH
        lebar_bar = max(12, min(maks_bar, lebar_bar))
        
        # Activity diprioritaskan lebih dulu; bar yang mengalah kalau layar mepet.
        # Kalau papan proses hidup, tiap chapter sudah punya barisnya sendiri jadi
        # activity tidak perlu muncul lagi di bar status.
        aktivitas = []
        if self._activity and aktif and self._live_obj is None:
            if not lebar:
                aktivitas = [(f"{gap}sedang ", "grey50"), (f"{aktif}", "bright_cyan"),
                             (f"  {self._activity[:40]}", "grey70")]
            elif lebar_bar > 14:
                sisa = lebar - 2 - len(ekor) - lebar_bar
                teks = self._activity
                if len(teks) + 14 > sisa:
                    teks = teks[:max(0, sisa - 17)] + "..."
                if len(teks) >= 8:
                    lebar_bar = max(18, lebar_bar - (len(teks) + 14))
                    aktivitas = [(f"{gap}sedang ", "grey50"), (f"{aktif}", "bright_cyan"),
                                 (f"  {teks}", "grey70")]
        
        filled = int(lebar_bar * min(done, self.total) / total)
        parts = [
            ("  ", ""),
            ("━" * filled, "bold spring_green2"),
            ("━" * (lebar_bar - filled), "grey37"),
            (f"   {pct:.0f}{satuan}", "bold white"),
            (f"{gap}selesai ", "grey50"), (f"{self.completed}", "green"),
            (f"{gap}gagal ", "grey50"), (f"{self.failed}", "red" if self.failed else "grey50"),
            (f"{gap}lewat ", "grey50"), (f"{self.skipped}", "yellow" if self.skipped else "grey50"),
            (f"{gap}sisa ", "grey50"), (f"{max(0, self.total - done)}", "white"),
            (f"{gap}", ""),
            (f"{elapsed // 60}:{elapsed % 60:02d}", "grey50"),
        ]
        return parts + aktivitas

    # ------------------------------------------------------------------
    # Papan proses: baris hijau per chapter yang selesai + tahap yang jalan.
    # ------------------------------------------------------------------
    def _jumlah_baris(self) -> int:
        """Berapa chapter yang boleh kelihatan sekaligus (ikut tinggi layar)."""
        if not UI or ui_console is None:
            return 0
        tinggi = ui_console.size.height or 25
        return max(3, min(10, tinggi - 14))

    def _baris_chapter(self, chapter: str, lebar: int) -> Optional[Text]:
        """Satu baris papan: nama chapter, bar hijau, tahap, dan rincian."""
        s = self._state.get(chapter, self._state_baru())
        tahap = s['tahap']
        gaya = self._GAYA_TAHAP.get(tahap, 'grey70')
        jalan = tahap in ('buka', 'unduh', 'gabung', 'simpan')
        
        # Lebar kolom: bar dan kolom rincian dikorbankan di layar sempit.
        if lebar >= 82:
            lebar_nama, lebar_bar = 24, self._BAR_CHAPTER
        elif lebar >= 68:
            lebar_nama, lebar_bar = 20, 10
        else:
            lebar_nama, lebar_bar = 16, 0
        lebar_rinci = max(8, lebar - lebar_nama - lebar_bar - 13)
        
        nama = chapter if cell_len(chapter) <= lebar_nama \
            else chapter[:lebar_nama - 1] + "…"
        nama = self._pad(nama, lebar_nama)
        
        baris = Text()
        baris.append("  ")
        baris.append(nama, style="white" if jalan else gaya)
        if lebar_bar:
            baris.append("  ")
            if tahap == 'selesai':
                baris.append("━" * lebar_bar, style="bold green")
            elif tahap == 'gagal':
                baris.append("━" * lebar_bar, style="red")
            elif tahap == 'lewat':
                baris.append("━" * lebar_bar, style="yellow")
            elif tahap == 'antri':
                baris.append("━" * lebar_bar, style="grey23")
            else:
                total = s['total'] or 1
                isi = int(lebar_bar * min(1.0, max(0.0, s['done'] / total)))
                baris.append("━" * isi, style="bold spring_green2")
                baris.append("━" * (lebar_bar - isi), style="grey27")
        baris.append("  ")
        baris.append(self._pad(tahap, 7), style=gaya)
        rincian = s['catatan']
        if cell_len(rincian) > lebar_rinci:
            rincian = rincian[:lebar_rinci - 1] + "…"
        if rincian:
            baris.append("  ")
            baris.append(rincian, style="red" if tahap == 'gagal' else "grey58")
        return baris

    def _baris_papan(self, lebar: int, maks: int):
        """Jejak hijau chapter yang baru selesai, lalu chapter yang sedang jalan."""
        if maks <= 0:
            return []
        baris = []
        paging = max(2, maks // 2)
        for chapter in self._jejak[-paging:]:
            baris.append(self._baris_chapter(chapter, lebar))
        antre = sorted(self.in_progress, key=lambda c: self.in_progress[c]['start'])
        for chapter in antre[:max(1, maks - len(baris))]:
            baris.append(self._baris_chapter(chapter, lebar))
        if not baris:
            return [self._mk(("  ", ""), ("menunggu chapter berikutnya", "grey42"))]
        return baris[:maks]

    def _papan(self):
        """Render papan proses: judul manga, bar status besar, baris per chapter."""
        if not UI or ui_console is None:
            return Text("")
        lebar = max(40, ui_console.size.width - 1)
        bagian = []
        if self._judul_manga:
            judul = self._judul_manga
            if cell_len(judul) > lebar - 4:
                judul = judul[:lebar - 5] + "…"
            bagian.append(self._mk(("  ", ""), (judul, "bold white")))
        kepala = Text()
        for potongan, gaya in self._status_parts(lebar):
            kepala.append(potongan, style=gaya)
        if cell_len(kepala.plain) > lebar:
            kepala.truncate(lebar, overflow="ellipsis")
        bagian.append(kepala)
        baris = self._baris_papan(lebar, self._jumlah_baris())
        if baris:
            bagian.append(Text(""))
            bagian.extend(baris)
        return Group(*bagian)

    def _paint(self):
        """Gambar ulang baris status di baris yang sama (mode terminal)."""
        if self.batch:
            return      # koordinator batch yang menggambar; jangan sentuh layar
        if not UI:
            teks = "".join(potongan for potongan, _ in self._status_parts())
            pad = max(0, self._painted - len(teks))
            self._painted = len(teks)
            print(f"\r{teks}{' ' * (pad + 1)}", end="", flush=True)
            return

        if not self._live:
            return

        lebar = max(30, ui_console.size.width - 1)
        baris = Text()
        for potongan, gaya in self._status_parts(lebar):
            baris.append(potongan, style=gaya)

        if cell_len(baris.plain) > lebar:
            baris.truncate(lebar, overflow="ellipsis")

        # Kembali ke awal baris + bersihkan sisa baris lama, baru gambar ulang.
        ui_console.control(Control(ControlType.CARRIAGE_RETURN))
        ui_console.control(Control((ControlType.ERASE_IN_LINE, 2)))
        ui_console.print(baris, end="")
        self._painted = cell_len(baris.plain)

    def _log(self, baris):
        """Cetak satu baris log di atas bar status, lalu gambar bar lagi."""
        if self.batch:
            # Kirim ke penampung judul ini (bukan layar) supaya tidak bentrok
            # dengan judul lain yang jalan berbarengan.
            if self.log_sink is not None:
                try:
                    teks = baris.plain if hasattr(baris, 'plain') else str(baris)
                    if not teks.endswith('\n'):
                        teks += '\n'      # sink menerima per-baris, bukan per-print
                    self.log_sink(teks)
                except Exception:
                    pass
            return
        self._erase()
        if UI:
            ui_console.print(baris)
        else:
            print(baris, flush=True)
        self._paint()

    def _print_status(self, message: str = ""):
        """Tetap ada buat kompatibilitas; pesan (kalau ada) jadi baris log."""
        if message:
            self._log(message)
        else:
            self._paint()
    
    def summary(self):
        elapsed = time.time() - self.start_time
        total_size = sum(r.get('size_kb', 0) for r in self.results if r['status'] == 'success')
        total_images = sum(r.get('images', 0) for r in self.results if r['status'] == 'success')
        gagal = [r for r in self.results if r.get('status') == 'failed']
        ukuran = f"{total_size / 1024:.1f} MB" if total_size >= 1024 else f"{total_size:.0f} KB"
        menit, detik = divmod(int(elapsed), 60)
        
        self.selesai_papan()   # papan proses dimatikan, baris akhirnya dibiarkan terlihat
        self._erase()   # bar status terakhir tidak ikut tertinggal di layar
        
        done = self.completed + self.failed + self.skipped
        total = self.total if self.total > 0 else 1
        lebar_bar = self._BAR_WIDTH
        
        if not UI:
            print()
            print(f"  unduhan selesai  {self.completed} dari {self.total} chapter berhasil, "
                  f"{self.failed} gagal, {self.skipped} dilewati")
            print(f"  waktu {int(elapsed)} detik   ukuran {ukuran}   {total_images} halaman")
            if self.results:
                print()
            for r in gagal[:10]:
                print(f"  gagal  {r.get('chapter', '?')}  {r.get('reason', '-')}")
            for chapter, nomor in self._halaman_gagal[:10]:
                print(f"  halaman gagal  {chapter}  {len(nomor)} halaman "
                      f"(nomor {self._ringkas_halaman(nomor)})  -- halaman itu "
                      f"tidak ada di berkas CBZ-nya")
            if len(self._halaman_gagal) > 10:
                print(f"  dan {len(self._halaman_gagal) - 10} chapter lain juga ada "
                      f"halaman yang gagal")
            print()
            return
        
        filled = int(lebar_bar * min(done, self.total) / total)
        baris_bar = Text()
        baris_bar.append("━" * filled, style="bold green")
        baris_bar.append("━" * (lebar_bar - filled), style="grey30")
        baris_bar.append(f"   {done} dari {self.total} chapter", style="grey70")

        rincian = Table.grid(padding=(0, 3))
        rincian.add_column(style="grey58", justify="right", no_wrap=True)
        rincian.add_column(style="bold white", overflow="fold")
        rincian.add_row("Berhasil", f"{self.completed} dari {self.total} chapter")
        rincian.add_row("Gagal", f"[red]{self.failed}[/red]" if self.failed else "[grey42]0[/grey42]")
        rincian.add_row("Dilewati", f"[yellow]{self.skipped}[/yellow]" if self.skipped else "[grey42]0[/grey42]")
        rincian.add_row("Waktu", f"{menit} menit {detik} detik" if menit else f"{detik} detik")
        rincian.add_row("Ukuran", ukuran)
        rincian.add_row("Halaman", f"{total_images} gambar")

        isi = Group(baris_bar, Text(""), rincian)
        ui_console.print()
        ui_console.print(Panel(isi, title="[bold]Unduhan selesai[/bold]",
                               border_style="yellow" if self.failed else "green",
                               box=rich_box.ROUNDED, expand=False, padding=(1, 3)))
        if gagal:
            ui_console.print("  [bold red]Chapter yang gagal[/bold red]")
            for r in gagal[:10]:
                ui_console.print(f"    [white]{r.get('chapter', '?')}[/white]"
                                 f"   [grey58]{r.get('reason', '-')}[/grey58]")
            if len(gagal) > 10:
                ui_console.print(f"    [grey42]dan {len(gagal) - 10} chapter lainnya[/grey42]")
        if self._halaman_gagal:
            # Chapter-nya jadi, tapi ada halaman yang tidak masuk CBZ. Ini yang
            # bikin bacaan kelihatan lompat, jadi disebut jelas di sini.
            ui_console.print("  [bold yellow]Chapter dengan halaman gagal[/bold yellow]")
            for chapter, nomor in self._halaman_gagal[:10]:
                ui_console.print(f"    [white]{chapter}[/white]"
                                 f"   [grey58]{len(nomor)} halaman (nomor "
                                 f"{self._ringkas_halaman(nomor)})[/grey58]")
            if len(self._halaman_gagal) > 10:
                ui_console.print(f"    [grey42]dan {len(self._halaman_gagal) - 10} "
                                 f"chapter lainnya[/grey42]")
            ui_console.print("    [grey58]halaman itu tidak ada di berkas CBZ-nya, "
                            "CBZ-nya tetap bisa dibuka[/grey58]")
        ui_console.print()


class BaseScraper(ABC):
    """Base class with 10 parallel workers + validation"""
    
    BASE_URL = ""
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    }
    
    DEFAULT_WIDTH = 500
    # --- Encoder AVIF: satu setelan saja (preset kualitas dihapus) ---
    # SVT-AV1 lewat pillow-avif-plugin, speed 5, tune 1 (PSNR = default SVT), crf 43.
    # Diukur di strip merge 4 halaman (500x5645): 49.668 B / SSIM 0.9774, ~10% lebih
    # kecil dari jalur libaom lama pada kualitas setara.
    AVIF_CODEC = 'svt'
    AVIF_SPEED = 5
    AVIF_TUNE = 1
    AVIF_CRF = 43
    # Nilai quality libavif: cuma cadangan; yang menentukan hasil = AVIF_CRF di atas
    # (crf menimpa quality di jalur libavif).
    DEFAULT_QUALITY = 40
    # Hasil encode selalu divalidasi; kalau tidak valid diulang sampai batas ini supaya
    # tidak ada AVIF kosong/terpotong yang masuk CBZ.
    AVIF_ENCODE_ATTEMPTS = 5
    AVIF_RETRY_DELAY = 0.5
    # Batas keras SVT-AV1: tinggi sumber maksimal 8704 px ("Source Height must be
    # less than or equal to 8704"). Strip hasil merge bisa jauh lebih tinggi, jadi
    # gambar setinggi itu langsung di-encode libaom -- tanpa mencoba SVT yang cuma
    # menghasilkan error berulang.
    AVIF_MAX_HEIGHT = 8704
    MERGE_TARGET_COUNT = 10    # 1 chapter di-merge jadi maksimal 10 gambar (<=1 = nonaktif)
    # Margin aman tinggi strip saat membagi grup merge (lihat split_into_merge_groups_by_height).
    MERGE_HEIGHT_MARGIN = 16
    MAX_STRIP_HEIGHT = 60000   # batas aman tinggi strip AVIF (libavif mentok di 65536)
    MAX_WORKERS = 10
    CONVERT_CONCURRENCY = 2   # CPU 2 core -> maks 2 convert AVIF jalan bareng
    INNER_DOWNLOAD_WORKERS = 3  # download gambar paralel di dalam 1 chapter
    MAX_RETRIES = 3
    RETRY_DELAY = 1
    
    def __init__(self, download_dir: str = "downloads"):
        self.download_dir = Path(download_dir)
        self.download_dir.mkdir(parents=True, exist_ok=True)
        self.session = self._create_session()
        # Semaphore batas convert AVIF (CPU-bound), DIBAGI seluruh proses supaya
        # beberapa judul yang diunduh bareng tidak melipatgandakan encode.
        self._convert_sem = get_convert_semaphore(self.CONVERT_CONCURRENCY)
    
    def _create_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update(self.HEADERS)
        return session
    
    def _get_page(self, url: str) -> Optional[str]:
        for attempt in range(self.MAX_RETRIES):
            try:
                resp = self.session.get(url, timeout=60)
                resp.raise_for_status()
                return resp.text
            except Exception as e:
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY * (attempt + 1))
                else:
                    return None
    
    def _download_image_with_retry(self, url: str) -> Optional[bytes]:
        """Download image with retry"""
        for attempt in range(self.MAX_RETRIES):
            try:
                resp = self.session.get(url, timeout=30)
                resp.raise_for_status()
                data = resp.content
                # Validate image data
                if len(data) < 1000:  # Too small, likely error
                    raise Exception("Image data too small")
                return data
            except Exception as e:
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY)
        return None
    
    def _sanitize_filename(self, name: str) -> str:
        name = re.sub(r'[<>:"/\\|?*]', '', name)
        return name.strip().replace(' ', '_')[:200]
    
    # ------------------------------------------------------------------
    # URUTAN HASIL PENCARIAN (dipakai semua provider)
    # ------------------------------------------------------------------
    # Situs-situs ini mengurutkan hasil pencariannya menurut POPULARITAS, bukan
    # kedekatan judul. Akibatnya judul yang PERSIS diketik user bisa terlempar ke
    # belakang dan kalah dari judul lain yang cuma kebetulan mengandung katanya
    # (mis. cari "Solo Leveling" -> "Solo Leveling: Ragnarok" nongol dulu padahal
    # itu judul yang beda). Helper ini mengurut ULANG hasil yang sudah didapat
    # tanpa membuang/mengubah satu pun isinya:
    #   0  judul persis sama dengan query (huruf besar/kecil, tanda baca, dan
    #      spasi dinormalisasi dulu)
    #   1  judul diawali query        ("Magic Emperor" untuk query "magic emperor")
    #   2  judul diakhiri query
    #   3  semua kata query ada di judul (urutan bebas)
    #   4  query muncul di dalam judul sebagai potongan kata
    #   5  sisanya -- tetap ditampilkan, cuma ditaruh paling belakang
    # Dalam satu tingkat, urutan asli dari situs (popularitas) TIDAK diubah:
    # pengurutan Python stabil, jadi hasil yang sama-sama cocok tetap seurutan
    # seperti yang dikirim situsnya.

    @staticmethod
    def _normalisasi_judul(teks: str) -> str:
        """Rapikan judul/query buat dibandingkan: huruf kecil, tanda baca jadi
        spasi, spasi berlebih dibuang. Huruf non-ASCII (é, ’, dan sejenisnya)
        tetap dipertahankan supaya tidak terpotong jadi kata lain."""
        teks = (teks or '').lower()
        teks = re.sub(r'[^\w]+', ' ', teks, flags=re.UNICODE)
        return ' '.join(teks.split())

    @classmethod
    def _urut_hasil_pencarian(cls, query: str,
                              results: List[Dict[str, Any]],
                              title_key: str = 'title') -> List[Dict[str, Any]]:
        """Urutkan hasil pencarian: judul yang paling cocok dengan query di atas.

        Hasil yang tidak cocok sama sekali tidak dibuang (cuma digeser ke
        belakang) supaya daya tangkap pencarian situs tetap utuh.
        """
        if not results:
            return results
        q = cls._normalisasi_judul(query)
        if not q:
            return results
        token_q = q.split()

        def tingkat(item: Dict[str, Any]) -> int:
            judul = cls._normalisasi_judul(str(item.get(title_key) or ''))
            if not judul:
                return 5
            if judul == q:
                return 0
            if judul.startswith(q + ' '):
                return 1
            if judul.endswith(' ' + q):
                return 2
            kata = set(judul.split())
            if all(t in kata for t in token_q):
                return 3
            if q in judul:
                return 4
            return 5

        return sorted(results, key=tingkat)
    
    def _upgrade_image_url(self, url: str) -> str:
        """Naikin resolusi URL gambar:
        - buang suffix ukuran WordPress (-223x319) -> balik ke file asli
        - samain skema URL relatif/protocol-relative (//cdn -> https://cdn)
        """
        if not url:
            return ''
        url = url.strip()
        if url.startswith('//'):
            url = 'https:' + url
        elif url.startswith('/'):
            url = f"{self.BASE_URL}{url}"
        return WP_THUMB_SIZE_RE.sub('', url)
    
    @staticmethod
    def _strip_size_param(url: str) -> str:
        """Buang parameter ukuran (?w=500, ?resize=300,180, ?q=...) biar file asli."""
        if not url or '?' not in url:
            return url or ''
        base, _, query = url.partition('?')
        keep = [kv for kv in query.split('&')
                if kv and kv.split('=')[0].lower() not in SIZE_PARAM_NAMES]
        return base + ('?' + '&'.join(keep) if keep else '')
    
    @staticmethod
    def _dedupe_urls(urls: List[str]) -> List[str]:
        """Buang URL kosong & duplikat, urutan dipertahankan."""
        out = []
        for u in urls:
            u = (u or '').strip()
            if u and u not in out:
                out.append(u)
        return out
    
    def _is_placeholder_url(self, url: str) -> bool:
        """Deteksi gambar placeholder/lazy (bukan cover beneran)."""
        u = (url or '').lower()
        if not u or u.startswith('data:'):
            return True
        return 'lazy.jpg' in u or 'placeholder' in u or '/blank.' in u or u.endswith('spacer.gif')
    
    def _cover_candidates_from_img(self, img) -> List[str]:
        """Kumpulin kandidat URL cover dari 1 tag <img>, kualitas tinggi dulu.
        Lazy-load attr (data-lazy-src/data-src) biasanya file asli, `src` sering
        thumbnail kecil. Tiap kandidat juga dimasukin versi 'diupgrade' (tanpa
        suffix ukuran WordPress) di depan.
        """
        raw = []
        if img is not None:
            for attr in ('data-lazy-src', 'data-src', 'data-original', 'src'):
                val = img.get(attr)
                if val:
                    raw.append(val)
            srcset = img.get('srcset') or img.get('data-srcset')
            if srcset:
                raw.append(self._largest_from_srcset(srcset))
        
        out = []
        for u in raw:
            for candidate in (self._upgrade_image_url(u), u):
                candidate = (candidate or '').strip()
                if candidate and candidate not in out and not self._is_placeholder_url(candidate):
                    out.append(candidate)
        return out
    
    def _largest_from_srcset(self, srcset: str) -> str:
        """Ambil URL paling gede dari atribut srcset (pakai descriptor w/x)."""
        best, best_score = '', -1
        for part in (srcset or '').split(','):
            bits = part.strip().split()
            if not bits:
                continue
            score = 0
            if len(bits) > 1:
                try:
                    if bits[1].endswith('w'):
                        score = int(bits[1][:-1])
                    elif bits[1].endswith('x'):
                        score = int(float(bits[1][:-1]) * 100000)
                except ValueError:
                    score = 0
            if score > best_score:
                best, best_score = bits[0], score
        return best
    
    def _detect_image_ext(self, data: bytes, content_type: str = '') -> str:
        """Detect image extension from magic bytes (fallback: Content-Type)."""
        if data[:8] == b'\x89PNG\r\n\x1a\n':
            return '.png'
        if data[:3] == b'\xff\xd8\xff':
            return '.jpg'
        if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
            return '.webp'
        if data[:6] in (b'GIF87a', b'GIF89a'):
            return '.gif'
        if data[:2] == b'BM':
            return '.bmp'
        # Fallback ke Content-Type
        if 'png' in content_type:
            return '.png'
        if 'webp' in content_type:
            return '.webp'
        if 'gif' in content_type:
            return '.gif'
        return '.jpg'
    
    def _save_info_json(self, info: Dict[str, Any], save_path: Path) -> None:
        """Simpan info.json secara atomik (tulis sementara -> tukar nama).
        
        Tujuannya sama seperti _pack_to_cbz: tidak ada info.json separuh jadi
        kalau unduhan dihentikan di tengah, dan berkasnya tidak pernah kosong
        sesaat (yang bikin impor/download lain salah baca).
        """
        tmp_path = save_path.with_name(save_path.name + '.tmp')
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(info, f, ensure_ascii=False, indent=2)
            os.replace(tmp_path, save_path)
        finally:
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass
    
    def _prepare_image(self, image: Image.Image) -> Image.Image:
        """Flatten transparansi + resize ke lebar target (w500). Tanpa crop."""
        # Handle transparent images
        if image.mode in ('RGBA', 'LA', 'P'):
            background = Image.new('RGB', image.size, (255, 255, 255))
            if image.mode == 'P':
                image = image.convert('RGBA')
            background.paste(image, mask=image.split()[-1] if len(image.split()) > 3 else None)
            image = background
        elif image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Resize if too wide (aspect ratio dijaga, tinggi ngikut)
        if image.width > self.DEFAULT_WIDTH:
            ratio = self.DEFAULT_WIDTH / image.width
            new_height = max(1, int(image.height * ratio))
            image = image.resize((self.DEFAULT_WIDTH, new_height), Image.LANCZOS)
        return image
    
    def _avif_is_valid(self, data: bytes, source: Image.Image) -> bool:
        """Cek AVIF hasil encode benar-benar utuh & sesuai gambar sumber.
        
        Menangkap output kosong / terpotong / berubah ukuran -- inilah penyebab
        dulu ada AVIF buram di CBZ (encode gagal tapi hasilnya tetap dipakai).
        """
        if not data or len(data) < 100:
            return False
        try:
            with Image.open(io.BytesIO(data)) as check:
                if check.size != source.size:
                    return False
                small = check.convert('L').resize((32, 32))
        except Exception:
            return False
        
        vals = small.tobytes()
        mean = sum(vals) / len(vals)
        var = sum((v - mean) ** 2 for v in vals) / len(vals)
        
        src_small = source.convert('L').resize((32, 32))
        src_vals = src_small.tobytes()
        src_mean = sum(src_vals) / len(src_vals)
        src_var = sum((v - src_mean) ** 2 for v in src_vals) / len(src_vals)
        
        if src_var > 4 and var < 1:
            return False        # sumber ada isinya tapi hasil nyaris rata -> gambar hilang
        return abs(mean - src_mean) <= 25
    
    def _encode_avif_libaom(self, image: Image.Image) -> Optional[bytes]:
        """Jalur libaom (encoder lama). Dipakai untuk gambar yang tidak bisa lewat SVT
        (tinggi > AVIF_MAX_HEIGHT) atau kalau SVT gagal di semua percobaan."""
        try:
            buffer = io.BytesIO()
            image.save(buffer, "AVIF", codec='aom', quality=self.DEFAULT_QUALITY,
                       speed=self.AVIF_SPEED)
            result = buffer.getvalue()
            if self._avif_is_valid(result, image):
                return result
        except Exception:
            pass
        return None
    
    def _encode_avif(self, image: Image.Image) -> Optional[bytes]:
        """Encode PIL image -> AVIF (SVT tune 1, crf 43).
        
        Hasilnya divalidasi; kalau tidak valid (gagal/kosong/terpotong) encode
        DIULANG sampai AVIF_ENCODE_ATTEMPTS kali. Strip yang lebih tinggi dari batas
        SVT (AVIF_MAX_HEIGHT) atau yang tetap gagal setelah diulang, di-encode pakai
        libaom supaya halaman tidak pernah hilang kosong.
        """
        if image.height > self.AVIF_MAX_HEIGHT:
            return self._encode_avif_libaom(image)
        
        for attempt in range(self.AVIF_ENCODE_ATTEMPTS):
            try:
                buffer = io.BytesIO()
                image.save(buffer, "AVIF", codec=self.AVIF_CODEC,
                           quality=self.DEFAULT_QUALITY, speed=self.AVIF_SPEED,
                           advanced=[("tune", self.AVIF_TUNE), ("crf", self.AVIF_CRF)])
                result = buffer.getvalue()
                if self._avif_is_valid(result, image):
                    return result
            except Exception:
                pass
            if attempt < self.AVIF_ENCODE_ATTEMPTS - 1:
                time.sleep(self.AVIF_RETRY_DELAY)
        
        return self._encode_avif_libaom(image)
    
    def _convert_to_avif(self, image_data: bytes) -> Optional[bytes]:
        """Convert 1 gambar ke AVIF with validation"""
        try:
            image = self._prepare_image(Image.open(io.BytesIO(image_data)))
            return self._encode_avif(image)
        except Exception:
            return None
    
    def _merge_group_to_avif(self, images_data: List[bytes]) -> Optional[bytes]:
        """
        Gabung beberapa gambar jadi 1 strip VERTIKAL (halaman berurutan ditumpuk
        atas -> bawah, sesuai urutan baca), lalu encode AVIF.
        
        Ini MERGE, bukan crop: semua pixel dipertahankan. Lebar disamakan ke
        DEFAULT_WIDTH (aspect ratio dijaga), jadi tinggi strip = total tinggi semua
        halaman di grup. Return None kalau gagal (mis. strip kepanjangan buat AVIF)
        supaya caller bisa fallback per-gambar.
        """
        if not images_data:
            return None
        
        prepared = []
        for data in images_data:
            try:
                prepared.append(self._prepare_image(Image.open(io.BytesIO(data))))
            except Exception:
                continue
        
        if not prepared:
            return None
        if len(prepared) == 1:
            return self._encode_avif(prepared[0])
        
        width = max(im.width for im in prepared)
        height = sum(im.height for im in prepared)
        if height > self.MAX_STRIP_HEIGHT:
            return None
        
        strip = Image.new('RGB', (width, height), (255, 255, 255))
        y = 0
        for im in prepared:
            strip.paste(im, ((width - im.width) // 2, y))  # center, bukan crop
            y += im.height
        
        return self._encode_avif(strip)
    
    @staticmethod
    def split_into_merge_groups(images: List[Any], target: int = 10) -> List[List[Any]]:
        """
        Bagi sederet gambar (urut baca) jadi grup-grup yang nanti di-merge.
        
        Aturan (nggak ada gambar yang dipotong / dibuang / dobel):
        - total >= target  -> hasil PERSIS `target` grup, selisih jumlah antar grup
          maksimal 1 biar rata (contoh total=11, target=10 -> [2,1,1,1,1,1,1,1,1,1];
          total=19 -> [2,2,2,2,2,2,2,2,2,1]; total=90 -> 9 gambar/grup).
        - total < target   -> nggak mungkin 10 grup tanpa nambah gambar atau ngosongin
          slot, jadi tetap `total` grup (1 gambar/grup). Jumlah file < 10 itu wajar
          buat chapter pendek; yang penting isinya utuh.
        - target <= 1      -> merge dimatikan, tiap gambar jadi grup sendiri.
        """
        total = len(images)
        if total == 0:
            return []
        if target <= 1:
            return [[im] for im in images]
        
        target = min(target, total)
        base, extra = divmod(total, target)
        
        groups, idx = [], 0
        for i in range(target):
            size = base + (1 if i < extra else 0)
            groups.append(images[idx:idx + size])
            idx += size
        return groups
    
    def _prepared_height(self, image_data: bytes) -> int:
        """Tinggi gambar SETELAH _prepare_image (w500), dihitung dari header saja.
        
        Dipakai buat tahu tinggi strip sebelum merge. Kalau data nggak kebaca, balikin 0
        supaya gambar tetap ikut ke grup (tidak ada yang dibuang).
        """
        try:
            with Image.open(io.BytesIO(image_data)) as im:
                w, h = im.size
        except Exception:
            return 0
        if w > self.DEFAULT_WIDTH:
            return max(1, int(h * (self.DEFAULT_WIDTH / w)))
        return h
    
    def split_into_merge_groups_by_height(self, images_data: List[bytes],
                                          target: int = 10,
                                          max_height: Optional[int] = None) -> List[List[bytes]]:
        """
        Bagi gambar (urut baca) jadi grup merge dengan batas JUMLAH **dan TINGGI**.
        
        Kenapa perlu: SVT-AV1 menolak sumber yang lebih tinggi dari AVIF_MAX_HEIGHT
        (8704 px). Strip hasil merge bisa lewat batas itu, jadi grupnya dibatasi tinggi
        supaya strip tetap bisa di-encode SVT -- bukan dengan memotong gambar.
        
        Cara kerja (kalau `max_height` kosong -> persis `split_into_merge_groups`):
        1. Coba bagi RATA jadi min(total, target) grup (aturan lama: 1 chapter jadi
           maksimal `target` file, selisih jumlah gambar antar grup maksimal 1).
        2. Kalau SEMUA grup sudah muat (<= max_height), pakai hasil itu -- hasilnya sama
           seperti sebelum fitur batas tinggi ada.
        3. Kalau ada yang kelewat tinggi, packing ulang SELURUH daftar secara greedy
           berurutan: gambar dimasukkan selama masih muat, kalau penuh grup baru dibuka.
           Ini PEMECAHAN GRUP, bukan pemotongan gambar: pixel tetap utuh, cuma jumlah
           file outputnya bertambah (dan dibuat sesedikit mungkin).
        - gambar yang SENDIRIAN sudah lebih tinggi dari max_height tetap jadi grup
          sendiri secara utuh (nanti otomatis di-encode libaom oleh _encode_avif),
          bukan dipotong atau di-resize.
        - urutan gambar dijaga persis seperti input.
        """
        even = self.split_into_merge_groups(images_data, target)
        if not max_height or not images_data:
            return even
        if all(self._group_height(g) <= max_height for g in even):
            return even
        return self._split_group_by_height(images_data, max_height)
    
    def _group_height(self, group: List[bytes]) -> int:
        """Total tinggi strip kalau grup ini di-merge (dihitung setelah resize w500)."""
        return sum(self._prepared_height(data) for data in group)
    
    def _split_group_by_height(self, group: List[bytes],
                               max_height: Optional[int]) -> List[List[bytes]]:
        """
        Bagi satu daftar gambar (urut baca) jadi grup-grup berurutan yang total
        tingginya <= max_height.
        
        Greedy: gambar dimasukkan selama masih muat; kalau penuh, grup baru dibuka.
        Tinggi dihitung dari tinggi gambar SETELAH _prepare_image (w500) supaya pas
        dengan strip yang benar-benar di-encode. Nggak ada gambar yang dipotong.
        """
        if not max_height:
            return [group] if group else []
        
        subs: List[List[bytes]] = []
        current: List[bytes] = []
        current_h = 0
        for data in group:
            h = self._prepared_height(data)
            if current and current_h + h > max_height:
                subs.append(current)
                current, current_h = [], 0
            current.append(data)
            current_h += h
        if current:
            subs.append(current)
        return subs
    
    def _pack_to_cbz(self, images: List[Tuple[str, bytes]], cbz_path: Path) -> bool:
        """Bungkus jadi CBZ secara ATOMIK.
        
        Dulu berkas akhir dibuka langsung dengan mode 'w'. Kalau penulisan
        kena hentikan/dua penulis di path yang sama, yang tertinggal adalah
        CBZ separuh jadi di nama akhir. Sekarang isinya ditulis ke berkas
        sementara di folder yang sama, divalidasi, baru ditukar ke nama akhir
        (`os.replace` = tukar nama, bukan salin) -- jadi nama akhir hanya
        pernah berisi CBZ yang sudah utuh.
        """
        tmp_path = cbz_path.with_name(cbz_path.name + '.tmp')
        try:
            with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for filename, image_data in images:
                    zf.writestr(filename, image_data)
            
            # Validate CBZ (yang sementara -> nama akhir baru ditukar kalau utuh)
            if not self._validate_cbz(tmp_path):
                return False
            os.replace(tmp_path, cbz_path)
            return True
        except Exception:
            return False
        finally:
            try:
                tmp_path.unlink(missing_ok=True)   # sisa kalau gagal/nilainya ditolak
            except OSError:
                pass
    
    def _validate_cbz(self, cbz_path: Path) -> bool:
        """Validate CBZ file"""
        try:
            with zipfile.ZipFile(cbz_path, 'r') as zf:
                if len(zf.namelist()) == 0:
                    return False
                for name in zf.namelist():
                    data = zf.read(name)
                    if len(data) < 100:
                        return False
                return True
        except Exception:
            return False
    
    @abstractmethod
    def search(self, query: str) -> List[Dict[str, Any]]:
        pass
    
    @abstractmethod
    def get_manga_detail(self, url: str) -> Optional[Dict[str, Any]]:
        pass
    
    @abstractmethod
    def get_chapter_images_ordered(self, url: str) -> List[Dict[str, Any]]:
        pass
    
    # Nomor chapter di judul. Biasanya angka biasa ("Chapter 149"), tapi situs
    # bisa mengirim nomor bersuffix: softkomik menamai ulang sebagian chapter
    # sebagai "Chapter 149.side-1", "Chapter 107.e", "Chapter 40.end-s1".
    NOMOR_JUDUL_RE = re.compile(r'[\d.]+')

    @staticmethod
    def _rapikan_angka(nomor: str) -> str:
        """Buang nol di depan angka chapter: '0010' -> '10', '0001' -> '1'.

        Sebagian situs menulis nomor chapter/pagenya dengan nol tambahan yang
        tidak konsisten ('0010', '0001'), ada juga yang mencampurnya dengan
        bentuk normal ('010', '1'). Kalau dibiarkan, satu chapter yang sama bisa
        punya dua nama berkas yang beda (chapter-0010.cbz vs chapter-010.cbz) --
        terbaca sebagai chapter dobel -- dan nama yang lebih panjang ikut salah
        urut saat disortir ('0010' < '009', jadi chapter 10 nyelip sebelum 9).
        Angka desimal ('179.5') cuma bagian depannya yang dirapikan.
        """
        if '.' in nomor:
            kepala, _, ekor = nomor.partition('.')
            if kepala.isdigit():
                kepala = str(int(kepala))
            return f"{kepala}.{ekor}" if ekor else kepala
        return str(int(nomor)) if nomor.isdigit() else nomor

    @classmethod
    def _nomor_cbz(cls, judul_chapter: str) -> str:
        """Nomor chapter yang dipakai di nama berkas CBZ.

        Nomor angka biasa TIDAK diubah bentuknya (chapter-005.cbz,
        chapter-179.5.cbz) supaya CBZ yang sudah keunduh tetap dikenali dan
        tidak diunduh ulang. Yang dirapikan:
          - nomor bersuffix dari situs: pola lama cuma mengambil angka + titik,
            jadi "Chapter 149.side-1" jadi "149." dan berkasnya bernama
            "chapter-149..cbz" -- titik dobel, dan di pembaca manga terbaca
            sebagai chapter 149 lagi (nomor yang sama kelihatan dua kali,
            urutannya jadi lompat). Sekarang suffix-nya jadi bagian nama:
            "chapter-149-side-1.cbz", "chapter-107-e.cbz", "chapter-040-end-s1.cbz".
          - nol di depan yang tidak konsisten dari situs: "Chapter 0010" dan
            "Chapter 0001" jadi chapter-010.cbz / chapter-001.cbz, bukan
            chapter-0010.cbz / chapter-0001.cbz (lihat _rapikan_angka).
        """
        teks = judul_chapter or ''
        cocok = cls.NOMOR_JUDUL_RE.search(teks)
        if not cocok:
            return '000'        # judul tanpa angka -> chapter-000.cbz (seperti sebelumnya)
        nomor = cocok.group()
        if not nomor.endswith('.'):
            # termasuk chapter desimal (179.5); nol di depan dirapikan dulu
            return cls._rapikan_angka(nomor).zfill(3)
        # Nomor situs bersuffix -> suffix dibawa ke nama biar tidak bertabrakan
        # dengan nomor aslinya (149 vs 149.side-1).
        sisa = re.sub(r'[^0-9A-Za-z]+', '-', teks[cocok.end():]).strip('-').lower()
        kepala = cls._rapikan_angka(nomor.rstrip('.')).zfill(3)
        return f"{kepala}-{sisa}" if sisa else kepala

    def _nama_cbz(self, judul_chapter: str) -> str:
        """Nama berkas CBZ satu chapter (nomor diambil dari judul chapter)."""
        return f"chapter-{self._nomor_cbz(judul_chapter)}.cbz"
    
    def _rencana_cbz(self, chapters: List[Dict[str, Any]],
                     manga_folder: Path) -> Tuple[List[Tuple[Dict[str, Any], Path]], List[str], List[str]]:
        """Pasangkan tiap chapter dengan berkas CBZ miliknya, namanya dijamin unik.
        
        Nomor yang dipakai tetap nomor dari judul chapter (chapter-005.cbz, sama
        seperti sebelumnya). Yang ditambal di sini: kalau DUA chapter di satu daftar
        bernomor sama (mis. "Chapter 5" dan "Chapter 5 (v2)"), dulu dua-duanya
        menulis chapter-005.cbz yang sama -- yang belakangan menimpa isi yang sudah
        jadi, dan yang satunya cuma terhitung "lewat" karena CBZ-nya dianggap sudah
        ada. Hasilnya satu chapter hilang tanpa keliatan. Sekarang chapter kedua
        disimpan sebagai chapter-005_2.cbz (masih berurutan pas dibaca, karena "_"
        ada setelah "." pada nama berkas).
        
        Return: (daftar (chapter, path_cbz), daftar nomor yang dobel buat
        dilaporkan, daftar nama "bukan angka biasa" dari situs buat dilaporkan).
        """
        terpakai: Dict[str, int] = {}
        dobel: List[str] = []
        aneh: List[str] = []
        rencana: List[Tuple[Dict[str, Any], Path]] = []
        for chapter in chapters:
            judul = chapter.get('title', '')
            dasar = self._nama_cbz(judul)[:-len('.cbz')]
            # Nomor bersuffix dari situs (mis. "149.side-1" -> chapter-149-side-1.cbz)
            # dicatat sekali, biar user tahu kenapa nama berkasnya begitu.
            nomor = self._nomor_cbz(judul)
            if '-' in nomor and f"{judul} -> {dasar}.cbz" not in aneh:
                aneh.append(f"{judul} -> {dasar}.cbz")
            urut = terpakai.get(dasar, 0) + 1
            terpakai[dasar] = urut
            if urut == 1:
                rencana.append((chapter, manga_folder / f"{dasar}.cbz"))
            else:
                rencana.append((chapter, manga_folder / f"{dasar}_{urut}.cbz"))
                if urut == 2:
                    dobel.append(dasar)
        return rencana, dobel, aneh
    
    def _process_chapter(self, chapter: Dict[str, Any], manga_folder: Path, 
                         progress: ProgressTracker, worker_id: int = 0,
                         cbz_path: Optional[Path] = None) -> bool:
        """Process single chapter with validation"""
        chapter_title = chapter['title']
        chapter_url = chapter['url']
        
        # Check if CBZ exists and is valid
        # (path-nya biasanya sudah ditentukan download_manga lewat _rencana_cbz,
        #  yang menghitung nama unik; hitung sendiri cuma kalau dipanggil manual.)
        if cbz_path is None:
            cbz_path = manga_folder / self._nama_cbz(chapter_title)
        if cbz_path.exists() and self._validate_cbz(cbz_path):
            progress.skip_chapter(chapter_title)
            return True
        
        # Remove invalid CBZ
        if cbz_path.exists():
            cbz_path.unlink(missing_ok=True)
        
        progress.start_chapter(chapter_title, worker_id)
        
        # Get images
        progress.update_chapter(chapter_title, "Fetching image list...")
        ordered_images = self.get_chapter_images_ordered(chapter_url)
        if not ordered_images:
            progress.fail_chapter(chapter_title, "No images found")
            return False
        
        progress.update_chapter(chapter_title, f"Found {len(ordered_images)} images")
        
        # 1) DOWNLOAD SEMUA gambar dulu (paralel, network-bound) -> simpan per order.
        #    Convert nanti setelah merge, biar 1 strip = 1x encode AVIF.
        downloaded = {}
        failed_images = 0
        gagal_halaman = []        # nomor halaman (order) yang gagal diunduh
        results_lock = Lock()
        total = len(ordered_images)
        
        def _catat_gagal(order):
            """Hitung + catat halaman yang gagal (dipakai dua jalur di bawah)."""
            nonlocal failed_images
            with results_lock:
                failed_images += 1
                gagal_halaman.append(order)
        
        def _work(img):
            try:
                img_data = self._download_image_with_retry(img['url'])
                if not img_data:
                    _catat_gagal(img['order'])
                    return
                with results_lock:
                    downloaded[img['order']] = img_data
            except Exception:
                _catat_gagal(img['order'])
        
        with ThreadPoolExecutor(max_workers=self.INNER_DOWNLOAD_WORKERS) as executor:
            futures = [executor.submit(_work, img) for img in ordered_images]
            for i, future in enumerate(as_completed(futures), 1):
                future.result()
                progress.update_chapter(chapter_title, f"Downloaded {i}/{total}...")
        
        # Urutkan sesuai order asli (posisi gambar di HTML) -> urutan baca dijamin sama
        ordered_data = [downloaded[k] for k in sorted(downloaded)]
        
        # Validate: must have at least 80% of images
        required = int(len(ordered_images) * 0.8)
        if len(ordered_data) < required:
            progress.fail_chapter(chapter_title, f"Too many failed images ({failed_images}/{len(ordered_images)})")
            return False
        
        # 2) MERGE: bagi jadi grup berurutan, tiap grup ditumpuk vertikal jadi 1 strip.
        #    Grup dibatasi jumlah gambar (MERGE_TARGET_COUNT) DAN total tinggi
        #    (AVIF_MAX_HEIGHT - margin) supaya strip tetap muat di-encode SVT-AV1.
        #    Nggak ada pixel yang dipotong: gambar cuma ditumpuk, bukan di-crop/resize.
        groups = self.split_into_merge_groups_by_height(
            ordered_data, self.MERGE_TARGET_COUNT,
            self.AVIF_MAX_HEIGHT - self.MERGE_HEIGHT_MARGIN)
        progress.update_chapter(chapter_title, f"Merging {len(ordered_data)} -> {len(groups)} images...")
        
        merged = {}
        
        def _merge(idx, group):
            try:
                with self._convert_sem:
                    avif_data = self._merge_group_to_avif(group)
                if avif_data:
                    with results_lock:
                        merged[idx] = [(f"{idx:03d}.avif", avif_data)]
                    return
            except Exception:
                pass
            # Fallback: strip gagal di-encode (mis. kepanjangan buat libavif) ->
            # jangan buang halaman, simpan per gambar. Urutan tetap (idx-01, idx-02, ...).
            fallback = []
            for j, img_data in enumerate(group, 1):
                with self._convert_sem:
                    avif_data = self._convert_to_avif(img_data)
                if avif_data:
                    fallback.append((f"{idx:03d}-{j:02d}.avif", avif_data))
            if fallback:
                with results_lock:
                    merged[idx] = fallback
        
        # Merge + encode = CPU-bound -> batasi sesuai core, jangan spawn semua grup
        with ThreadPoolExecutor(max_workers=self.CONVERT_CONCURRENCY) as executor:
            futures = [executor.submit(_merge, idx, group) for idx, group in enumerate(groups, 1)]
            for i, future in enumerate(as_completed(futures), 1):
                future.result()
                progress.update_chapter(chapter_title, f"Merged {i}/{len(groups)}...")
        
        # Hasil diurutkan per grup -> nama 001..010, urutan baca tetap
        cbz_images = []
        for idx in sorted(merged):
            cbz_images.extend(merged[idx])
        if not cbz_images:
            progress.fail_chapter(chapter_title, "Merge failed")
            return False
        
        # Pack to CBZ
        progress.update_chapter(chapter_title, "Packing CBZ...")
        if self._pack_to_cbz(cbz_images, cbz_path):
            size_kb = cbz_path.stat().st_size / 1024
            progress.complete_chapter(chapter_title, size_kb, len(cbz_images),
                                      gagal=gagal_halaman)
            return True
        else:
            progress.fail_chapter(chapter_title, "CBZ creation failed")
            return False
    
    def download_manga(self, manga_url: str, max_workers: int = None, 
                       progress: ProgressTracker = None,
                       chapters: Optional[List[Dict[str, Any]]] = None,
                       target_dir: Optional[Path] = None) -> bool:
        """
        Download manga with progress UI.
        `chapters` opsional: kalau dikasih (dari pilihan user), cuma itu yang di-download.
        Kalau kosong, semua chapter di-download.
        `target_dir` opsional: folder tujuan yang sudah ditentukan pemanggil (dipakai
        mode paralel supaya tiap judul punya folder miliknya sendiri, tidak dihitung
        ulang dari judul). Kalau kosong, folder dihitung dari judul seperti biasa.
        """
        max_workers = max_workers or self.MAX_WORKERS
        
        if UI:
            ui_console.print()
            ui_console.print(Text.assemble(
                ("  Batch downloader   ", "bold white"),
                (f"{max_workers} worker paralel", "bright_cyan"),
                (f"   AVIF {self.AVIF_CODEC}  kecepatan {self.AVIF_SPEED}  "
                 f"crf {self.AVIF_CRF}", "grey62"),
            ))
        else:
            print()
            print(f"  Batch downloader   {max_workers} worker paralel   "
                  f"AVIF {self.AVIF_CODEC}  kecepatan {self.AVIF_SPEED}  crf {self.AVIF_CRF}")
            print()
        
        # Get manga detail
        ui_step("1 dari 4", "mengambil detail manga")
        detail = self.get_manga_detail(manga_url)
        if not detail:
            print("  gagal mengambil detail manga")
            return False
        
        title = detail['title']
        if chapters:
            # User pilih chapter tertentu -> pakai itu (di-reverse biar mulai dari chapter lama)
            chapters = list(reversed(chapters))
        else:
            chapters = list(reversed(detail['chapters']))
        info = detail['info']
        cover_url = detail.get('cover_url', '')
        
        if UI:
            ui_console.print(Text.assemble(
                (title, "bold white"),
                (f"    {len(chapters)} chapter", "grey70"),
            ))
            ui_console.print()
        else:
            print(f"  {title}")
            print(f"  {len(chapters)} chapter   {max_workers} worker")
            print()
        
        # Create folder
        manga_folder = Path(target_dir) if target_dir is not None \
            else self.download_dir / self._sanitize_filename(title)
        manga_folder.mkdir(parents=True, exist_ok=True)
        
        # Save cover (ORIGINAL format, no conversion) — SELALU ambil kandidat
        # dengan RESOLUSI PALING BESAR (=gambar ori), bukan asal pertama yang
        # kebetulan mirip thumbnail. Kandidat di-download & dibandingkan semua,
        # yang terbesar pixel-nya yang disimpan.
        ui_step("2 dari 4", "menyimpan cover")
        cover_candidates = self._dedupe_urls(list(detail.get('cover_candidates') or []) + [cover_url])
        cover_candidates = [u for u in cover_candidates if not self._is_placeholder_url(u)]
        
        if not cover_candidates:
            print("  tidak ada alamat cover")
        else:
            best = None  # (pixels, ext, bytes, "WxH")
            skip_hosts = set()   # host yang gagal konek -> jangan dicoba lagi
            done_paths = set()   # (group, path) yang sudah dievaluasi -> hindari coba mirror dobel
            
            for i, cand in enumerate(cover_candidates, 1):
                try:
                    split = urlsplit(cand)
                    host = split.netloc.lower()
                    # group = host tanpa TLD: normalize foo.komiku.to & foo.komiku.org
                    # jadi mirror yang sama (biar file dobel nggak di-download 2x / nggak
                    # nunggu timeout buat mirror mati).
                    group = host.rsplit('.', 1)[0] if host.count('.') >= 2 else host
                    if group in skip_hosts:
                        continue
                    path_key = (group, split.path)
                    if path_key in done_paths:
                        continue
                except Exception:
                    continue
                
                try:
                    resp = self.session.get(cand, timeout=30)
                    if resp.status_code != 200 or len(resp.content) <= 100:
                        continue
                    # Pastiin beneran gambar & bukan 1x1 / placeholder
                    probe = Image.open(io.BytesIO(resp.content))
                    if probe.width < 100 or probe.height < 100:
                        print(f"  kandidat {i} kekecilan {probe.width}x{probe.height}, coba berikutnya")
                        continue
                    done_paths.add(path_key)
                    ext = self._detect_image_ext(resp.content, resp.headers.get('Content-Type', ''))
                    pixels = probe.width * probe.height
                    if best is None or pixels > best[0]:
                        best = (pixels, ext, resp.content, f"{probe.width}x{probe.height}")
                        print(f"  kandidat {i} dipakai  {probe.width}x{probe.height}  {len(resp.content)} byte")
                except (requests.exceptions.ConnectTimeout,
                        requests.exceptions.ReadTimeout,
                        requests.exceptions.ConnectionError,
                        requests.exceptions.Timeout):
                    # Host mati / koneksi gagal -> skip semua kandidat di host itu,
                    # jangan sampai nunggu timeout 30s berulang-ulang.
                    skip_hosts.add(group)
                    print(f"  kandidat {i} gagal konek ke {host}, host ini dilewati")
                except Exception as e:
                    print(f"  kandidat {i} gagal  {e}")
            
            if best:
                # Cover ditulis atomik: tulis berkas sementara, baru tukar nama.
                # Urutannya sengaja "tulis dulu, hapus yang lama belakangan" --
                # kalau dibalik (hapus lalu tulis), cover bisa hilang di tengah
                # jalan kalau prosesnya berhenti tepat setelah menghapus.
                cover_path = manga_folder / f"cover{best[1]}"
                cover_tmp = manga_folder / f"cover{best[1]}.tmp"
                try:
                    with open(cover_tmp, 'wb') as f:
                        f.write(best[2])
                    os.replace(cover_tmp, cover_path)
                finally:
                    try:
                        cover_tmp.unlink(missing_ok=True)
                    except OSError:
                        pass
                # Bersihin cover lama (kalau formatnya beda, jangan nyisa 2 file)
                for old in manga_folder.glob("cover.*"):
                    if old != cover_path:
                        old.unlink(missing_ok=True)
                print(f"  cover disimpan  cover{best[1]}  {best[3]}  {len(best[2])} byte")
                saved = True
            else:
                print("  cover gagal diunduh")
        
        # Save info.json (LENGKAP & konsisten untuk komiku + komikindo)
        ui_step("3 dari 4", "menyimpan info json")
        info_path = manga_folder / "info.json"
        merged_info = {
            'title': info.get('title') or detail.get('title') or title,
            'genres': info.get('genres', detail.get('genres', [])),
            'synopsis': info.get('synopsis', detail.get('synopsis', '')),
            'author': info.get('author', ''),
            'type': info.get('type', ''),
            'status': info.get('status', ''),
            'total_chapters': info.get('total_chapters', detail.get('total_chapters', len(chapters))),
        }
        # Field opsional biar tetap kaya (kalau ada di scraper-nya)
        for key in ('alternative_title', 'artist'):
            val = info.get(key) or detail.get(key)
            if val:
                merged_info[key] = val
        self._save_info_json(merged_info, info_path)
        print("  info json tersimpan")
        
        # Download chapters
        ui_step("4 dari 4", f"mengunduh {len(chapters)} chapter")
        
        # Nama berkas tiap chapter ditentukan di sini (bukan di dalam tiap worker),
        # supaya daftarnya bisa dipastikan tidak ada yang bertabrakan (lihat
        # _rencana_cbz) dan pekerjaan paralel tidak berebut nama yang sama.
        rencana, dobel, nama_aneh = self._rencana_cbz(chapters, manga_folder)
        if dobel:
            pesan = (f"nomor chapter dobel  {', '.join(dobel)}  "
                     f"-- chapter berikutnya disimpan dengan akhiran _2, _3, "
                     f"supaya isinya tidak saling menimpa")
            if UI:
                ui_console.print(f"  [yellow]{pesan}[/yellow]")
            else:
                print(f"  {pesan}")
        if nama_aneh:
            # Nomor bersuffix dari situs (mis. softkomik "Chapter 149.side-1"):
            # suffix-nya ikut ke nama berkas, jadi chapter itu tidak lagi terbaca
            # sebagai chapter 149 yang sama di pembaca manga.
            contoh = '   '.join(nama_aneh[:4])
            pesan = (f"nomor chapter dari situs bukan angka biasa  {contoh}"
                     f"{'   dan lain-lain' if len(nama_aneh) > 4 else ''}  "
                     f"-- suffix-nya dibawa ke nama berkas supaya tidak bertabrakan "
                     f"dengan chapter yang nomornya sama")
            if UI:
                ui_console.print(f"  [yellow]{pesan}[/yellow]")
            else:
                print(f"  {pesan}")
        
        if not progress:
            progress = ProgressTracker(len(chapters))
        
        # Papan proses: sebutkan chapter yang akan jalan lalu nyalakan tampilannya.
        progress.set_daftar_chapter([c['title'] for c in chapters], title)
        progress.mulai_papan()
        try:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {}
                for i, (chapter, cbz_path) in enumerate(rencana):
                    future = executor.submit(
                        self._process_chapter, chapter, manga_folder, progress,
                        i % max_workers, cbz_path
                    )
                    futures[future] = chapter
                
                for future in as_completed(futures):
                    try:
                        future.result()
                    except Exception as e:
                        pass
        finally:
            progress.selesai_papan()
        
        progress.summary()
        
        # List CBZ files
        cbz_files = list(manga_folder.glob("*.cbz"))
        print(f"\n  tersimpan di  {manga_folder}")
        print(f"  berkas CBZ  {len(cbz_files)}")
        
        return True

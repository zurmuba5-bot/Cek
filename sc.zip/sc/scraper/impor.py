"""
Impor hasil unduhan ke GitHub Release.

Modul ini TERPISAH dari alur unduh -- `cli.py` cuma memanggilnya saat user
mengetik `impor` di prompt judul. Jadi tidak ada logika unduh yang diubah.

Alurnya:
  1. hitung versi berikutnya (baca tag rilis GitHub + memory versi lokal)
  2. zip seluruh isi folder unduhan
  3. gh release create <versi> komik-impor.zip#komik-<versi>.zip
  4. KALAU SUKSES saja: hapus zip dan kosongkan folder unduhan

Kenapa aman:
  - Hapus hanya terjadi setelah `gh release create` balas sukses (exit 0).
    Kalau gagal di langkah apa pun, folder unduhan dibiarkan utuh.
  - Versi diambil dari gabungan tag GitHub DAN memory lokal, jadi tidak
    mungkin dobel walau memory-nya hilang. Kalau tag tetap bentrok (ada yang
    rilis bareng), versinya dinaikkan lagi otomatis lalu dicoba ulang.
  - Modul ini dipanggil secara sinkron dari CLI (bukan pengawas/cron), jadi
    tidak ada proses unduh yang jalan barengan -- tidak ada race.

Jalankan manual:
    python3 -m scraper.impor --dry-run     # cuma lihat rencananya
    python3 -m scraper.impor               # benar-benar rilis
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# Akar proyek = folder di atas paket `scraper/`.
PROYEK = Path(__file__).resolve().parent.parent
VERSI_FILE = PROYEK / ".rilis-versi.json"

# Batas aman ukuran satu aset GitHub (~2 GB). Di atas ini rilis bakal ditolak,
# jadi lebih baik berhenti dengan pesan jelas daripada gagal di tengah upload.
BATAS_ASET = 2 * 1024 ** 3

# Tag versi yang dikenali: v1.0.0 / 1.0.0 / v1.2 / v3
POLA_VERSI = re.compile(r'^v?(\d+)(?:\.(\d+))?(?:\.(\d+))?$')

# Nama file zip sementara (di akar proyek, BUKAN di dalam folder unduhan, biar
# tidak ikut ke-zip sendiri). Dibuat tetap supaya saat tag bentrok kami cukup
# ganti nama aset, tanpa perlu zip ulang.
ZIP_LOKAL = PROYEK / "komik-impor.zip"

# Berapa kali menaikkan versi kalau tag ternyata sudah dipakai.
MAKS_COBA_VERSI = 3


class ImporError(Exception):
    """Kegagalan yang sudah jelas sebabnya (ditampilkan ke user apa adanya)."""


# --------------------------------------------------------------------------- util
def format_ukuran(byte: float) -> str:
    satuan = ['B', 'KB', 'MB', 'GB', 'TB']
    n = float(byte)
    for s in satuan:
        if n < 1024 or s == satuan[-1]:
            return f"{n:.1f} {s}" if s != 'B' else f"{int(n)} B"
        n /= 1024
    return f"{n:.1f} TB"


def ada_isi(folder) -> bool:
    """Apakah folder unduhan punya minimal 1 berkas (bukan cuma folder kosong)."""
    p = Path(folder)
    if not p.is_dir():
        return False
    try:
        for x in p.rglob('*'):
            if x.is_file():
                return True
    except OSError:
        return False
    return False


def _entri(folder) -> List[Path]:
    p = Path(folder)
    if not p.is_dir():
        return []
    return sorted(p.iterdir(), key=lambda x: x.name)


def _ukuran_folder(folder) -> int:
    total = 0
    p = Path(folder)
    for x in p.rglob('*'):
        try:
            if x.is_file():
                total += x.stat().st_size
        except OSError:
            pass
    return total


# --------------------------------------------------------------------------- gh
def _gh(args: List[str], cwd: Path = PROYEK, timeout: int = 1800) -> subprocess.CompletedProcess:
    return subprocess.run(["gh", *args], cwd=str(cwd), capture_output=True,
                          text=True, timeout=timeout)


def _gh_ada() -> bool:
    try:
        return _gh(["--version"], timeout=30).returncode == 0
    except (FileNotFoundError, subprocess.SubprocessError):
        return False


def _repo(cwd: Path = PROYEK) -> Optional[str]:
    """slug owner/nama repo dari folder proyek; None kalau tidak jelas."""
    hasil = _gh(["repo", "view", "--json", "nameWithOwner", "--jq", ".nameWithOwner"], cwd=cwd)
    if hasil.returncode != 0:
        return None
    return (hasil.stdout or '').strip() or None


def _daftar_tag(cwd: Path = PROYEK) -> Optional[List[str]]:
    """Semua tag rilis. None = gagal membaca (mis. gh tidak login/offline)."""
    hasil = _gh(["release", "list", "--limit", "1000", "--json", "tagName",
                 "--jq", ".[].tagName"], cwd=cwd, timeout=120)
    if hasil.returncode != 0:
        return None
    return [t.strip() for t in (hasil.stdout or '').splitlines() if t.strip()]


# --------------------------------------------------------------------------- versi
def _parse_versi(tag: str) -> Optional[Tuple[int, int, int]]:
    m = POLA_VERSI.match((tag or '').strip())
    if not m:
        return None
    major, minor, patch = (m.group(1), m.group(2), m.group(3))
    return (int(major), int(minor or 0), int(patch or 0))


def _baca_memori() -> Dict[str, Any]:
    try:
        if VERSI_FILE.exists():
            data = json.loads(VERSI_FILE.read_text() or '{}')
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def _tulis_memori(tag: str, ukuran: int, jumlah: int) -> None:
    data = _baca_memori()
    data['terakhir'] = tag
    data['diperbarui'] = time.strftime('%Y-%m-%dT%H:%M:%S%z')
    riwayat = data.get('riwayat')
    if not isinstance(riwayat, list):
        riwayat = []
    riwayat.append({'tag': tag, 'waktu': data['diperbarui'],
                    'ukuran': ukuran, 'entri': jumlah})
    data['riwayat'] = riwayat[-100:]
    try:
        VERSI_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    except Exception:
        pass


def _naikkan(versi: Tuple[int, int, int]) -> Tuple[int, int, int]:
    """Naikkan komponen sesuai RILIS_BUMP (bawaan: patch)."""
    major, minor, patch = versi
    mode = (os.environ.get('RILIS_BUMP') or 'patch').strip().lower()
    if mode == 'major':
        return (major + 1, 0, 0)
    if mode == 'minor':
        return (major, minor + 1, 0)
    return (major, minor, patch + 1)


def versi_berikut(cwd: Path = PROYEK) -> Tuple[str, bool]:
    """(tag versi berikutnya, apakah tag GitHub berhasil dibaca).

    Versi tertinggi diambil dari tag rilis GitHub DAN memory lokal -- mana yang
    lebih tinggi. Jadi memory boleh hilang atau tag GitHub tidak terbaca, tetap
    tidak ada rilis dobel.
    """
    kandidat: List[Tuple[int, int, int]] = []
    tag = _daftar_tag(cwd)
    if tag is not None:
        for t in tag:
            v = _parse_versi(t)
            if v:
                kandidat.append(v)

    terakhir_memori = _baca_memori().get('terakhir')
    if terakhir_memori:
        v = _parse_versi(str(terakhir_memori))
        if v:
            kandidat.append(v)

    if not kandidat:
        return "v1.0.0", tag is not None
    berikut = _naikkan(max(kandidat))
    return f"v{berikut[0]}.{berikut[1]}.{berikut[2]}", tag is not None


# --------------------------------------------------------------------------- zip
def _buat_zip(folder, zip_path: Path, lapor: Callable[[str], None]) -> int:
    """Zip seluruh isi folder unduhan. Kembalikan ukuran zip (byte)."""
    entri = _entri(folder)
    if not entri:
        raise ImporError("folder unduhan kosong")
    if zip_path.exists():
        zip_path.unlink(missing_ok=True)

    jumlah_berkas = 0
    lapor(f"zip  mengemas {len(entri)} judul")
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in entri:
            if p.is_dir():
                for berkas in p.rglob('*'):
                    if berkas.is_file():
                        z.write(berkas, berkas.relative_to(folder).as_posix())
                        jumlah_berkas += 1
            elif p.is_file():
                z.write(p, p.name)
                jumlah_berkas += 1
    lapor(f"zip  {jumlah_berkas} berkas dikemas")
    return zip_path.stat().st_size


# --------------------------------------------------------------------------- rilis
def _buat_release(tag: str, zip_path: Path, label: str,
                  repo: Optional[str], cwd: Path,
                  catatan: str) -> subprocess.CompletedProcess:
    """gh release create; aset diberi nama tampilan `label` (file#label)."""
    args = ["release", "create", tag, f"{zip_path}#{label}",
            "--title", f"Impor {tag}", "--notes", catatan]
    if repo:
        args += ["--repo", repo]
    return _gh(args, cwd=cwd)


def _bentrok_tag(hasil: subprocess.CompletedProcess) -> bool:
    """Apakah kegagalan ini karena tag-nya sudah dipakai (bukan sebab lain)."""
    teks = f"{hasil.stdout or ''}\n{hasil.stderr or ''}".lower()
    return ('already_exists' in teks or 'already exists' in teks
            or 'tag already' in teks or 'reference already exists' in teks)


def _catatan(jumlah: int, ukuran: int, judul: List[str]) -> str:
    baris = "\n".join(f"- {j}" for j in judul[:100])
    if len(judul) > 100:
        baris += f"\n- ... dan {len(judul) - 100} judul lain"
    return (f"Impor otomatis {time.strftime('%Y-%m-%d %H:%M')}\n\n"
            f"Judul: {jumlah}    Ukuran: {format_ukuran(ukuran)}\n\n{baris}")


# --------------------------------------------------------------------------- utama
def impor_downloads(download_dir, *, lapor: Optional[Callable[[str], None]] = None,
                    konfirmasi: Optional[Callable[[str], bool]] = None,
                    cwd: Path = PROYEK, dry_run: bool = False) -> bool:
    """Zip + rilis folder unduhan, lalu bersihkan HANYA kalau berhasil.

    `lapor(pesan)` dipakai untuk mencetak; `konfirmasi(pesan) -> bool` untuk
    meminta izin sebelum tindakan yang tidak bisa dibatalkan. CLI mengirim
    versinya sendiri supaya tampilannya seragam.
    """
    if lapor is None:
        lapor = print
    if konfirmasi is None:
        def konfirmasi(pesan: str) -> bool:            # noqa: E306 (selalu ada)
            try:
                return input(f"{pesan} [y/N] ").strip().lower() in ('y', 'ya', 'yes')
            except (EOFError, KeyboardInterrupt):
                return False

    folder = Path(download_dir)
    if not ada_isi(folder):
        lapor("tidak ada unduhan untuk diimpor")
        return False

    entri = _entri(folder)
    ukuran = _ukuran_folder(folder)

    if not _gh_ada():
        lapor("perintah gh tidak ditemukan, impor dilewati")
        return False

    tag, gh_terbaca = versi_berikut(cwd)
    if not gh_terbaca:
        lapor("daftar rilis GitHub tidak terbaca, versi diambil dari memory saja")
    repo = _repo(cwd)

    lapor(f"impor  {len(entri)} judul, {format_ukuran(ukuran)}")
    for p in entri[:10]:
        lapor(f"       {p.name}")
    if len(entri) > 10:
        lapor(f"       ... dan {len(entri) - 10} lagi")
    lapor(f"versi  {tag}")

    if dry_run:
        lapor("dry-run  tidak ada file yang dibuat/dihapus")
        return True

    # Tolak lebih awal kalau ukurannya sudah jelas melebihi batas GitHub,
    # sebelum konfirmasi -- biar tidak kayak meng-zip berkas raksasa dulu.
    if ukuran > BATAS_ASET:
        raise ImporError(
            f"unduhan {format_ukuran(ukuran)} melebihi batas aset GitHub "
            f"{format_ukuran(BATAS_ASET)}; rilis per judul dulu, lalu impor lagi")

    if not konfirmasi(f"rilis {tag} ({format_ukuran(ukuran)}) lalu hapus folder unduhan"):
        lapor("impor dibatalkan")
        return False

    ukuran_zip = _buat_zip(folder, ZIP_LOKAL, lapor)
    if ukuran_zip > BATAS_ASET:
        ZIP_LOKAL.unlink(missing_ok=True)
        raise ImporError(
            f"zip {format_ukuran(ukuran_zip)} melebihi batas aset GitHub "
            f"{format_ukuran(BATAS_ASET)}; rilis per judul dulu, lalu impor lagi")

    # Kalau tag ternyata sudah dipakai (ada yang rilis bareng), naikkan versi
    # lalu coba lagi -- tanpa perlu zip ulang, cukup ganti nama aset.
    kandidat = tag
    for percobaan in range(MAKS_COBA_VERSI):
        label = f"komik-{kandidat}.zip"
        hasil = _buat_release(kandidat, ZIP_LOKAL, label, repo, cwd,
                              _catatan(len(entri), ukuran_zip, [p.name for p in entri]))

        if hasil.returncode == 0:
            _tulis_memori(kandidat, ukuran_zip, len(entri))
            _bersihkan(folder, ZIP_LOKAL)
            lapor(f"rilis  {kandidat} berhasil, folder unduhan sudah dikosongkan")
            return True

        if not _bentrok_tag(hasil) or percobaan == MAKS_COBA_VERSI - 1:
            pesan = (hasil.stderr or hasil.stdout or '').strip().splitlines()
            sebab = pesan[-1] if pesan else f'kode {hasil.returncode}'
            ZIP_LOKAL.unlink(missing_ok=True)
            raise ImporError(f"gh release create gagal: {sebab}")

        naik = _naikkan(_parse_versi(kandidat) or (0, 0, 0))
        lapor(f"versi  tag {kandidat} sudah ada, dicoba v{naik[0]}.{naik[1]}.{naik[2]}")
        kandidat = f"v{naik[0]}.{naik[1]}.{naik[2]}"

    # Tidak tercapai (loop selalu return/raise), tapi jaga-jaga.
    ZIP_LOKAL.unlink(missing_ok=True)
    return False


def _bersihkan(folder, zip_path: Path) -> None:
    """Hapus zip dan seluruh isi folder unduhan (foldernya sendiri dibiarkan)."""
    zip_path.unlink(missing_ok=True)
    p = Path(folder)
    if not p.is_dir():
        return
    for x in p.iterdir():
        try:
            if x.is_dir():
                shutil.rmtree(x)
            else:
                x.unlink(missing_ok=True)
        except OSError:
            pass


# --------------------------------------------------------------------------- cli
def main() -> int:
    parser = argparse.ArgumentParser(description='Impor hasil unduhan ke GitHub Release')
    parser.add_argument('-o', '--output', default='downloads',
                        help='folder unduhan (bawaan: downloads)')
    parser.add_argument('--dry-run', action='store_true',
                        help='lihat rencananya saja, tidak ada file dibuat/dihapus')
    parser.add_argument('-y', '--yes', action='store_true',
                        help='jangan tanya konfirmasi')
    args = parser.parse_args()

    try:
        ok = impor_downloads(args.output,
                             konfirmasi=(lambda _p: True) if args.yes else None,
                             dry_run=args.dry_run)
    except ImporError as e:
        print(f"impor gagal: {e}")
        return 1
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())

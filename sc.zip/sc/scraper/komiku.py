"""
Scraper for komiku.org with SMART IMAGE ORDERING
"""
import re
import json
import time
from typing import Optional, List, Dict, Any
from urllib.parse import urlsplit, urlunsplit
from bs4 import BeautifulSoup
from .base import BaseScraper


class KomikuScraper(BaseScraper):
    """Scraper for komiku.org with smart image ordering"""
    
    BASE_URL = "https://komiku.org"
    API_URL = "https://api.komiku.org"
    # Tanpa Cloudflare + jaringan cepat -> 10 chapter worker paralel
    MAX_WORKERS = 10
    
    @staticmethod
    def _org_mirror(url: str):
        """Buat pasangan (versi .org, asli). .org dulu biar nggak nunggu timeout
        kalau .to mati. Kalau URL bukan domain komiku -> cuma (url,)."""
        url = (url or '').strip()
        if not url:
            return (None,)
        if '.komiku.to' not in url:
            return (url,)
        parts = urlsplit(url)
        swap = urlunsplit((parts.scheme,
                           parts.netloc.replace('.komiku.to', '.komiku.org'),
                           parts.path, parts.query, parts.fragment))
        return (swap, url)
    
    def search(self, query: str) -> List[Dict[str, Any]]:
        """Search for manga on komiku.org"""
        url = f"{self.API_URL}/?s={query}&post_type=manga"
        html = self._get_page(url)
        
        if not html:
            return []
        
        soup = BeautifulSoup(html, 'html.parser')
        results = []
        
        for item in soup.find_all('div', class_='bge'):
            try:
                link = item.find('a', href=True)
                if not link:
                    continue
                
                href = link.get('href', '')
                if not href.startswith('/'):
                    href = '/' + href
                
                if 'chapter' in href.lower():
                    continue
                
                h3 = item.find('h3')
                title = h3.get_text(strip=True) if h3 else "Unknown"
                
                type_info = ''
                type_div = item.find('div', class_='tpe1_inf')
                if type_div:
                    type_info = type_div.get_text(strip=True)
                
                cover_url = ''
                img = link.find('img')
                if img:
                    # cover di list pencarian biasanya dipatok ?w=... -> buang biar jernih
                    cover_url = self._strip_size_param(
                        img.get('src', '') or img.get('data-src', ''))
                
                chapter_info = {}
                new_divs = item.find_all('div', class_='new1')
                for new_div in new_divs:
                    a = new_div.find('a')
                    if a:
                        spans = a.find_all('span')
                        if len(spans) >= 2:
                            label = spans[0].get_text(strip=True).rstrip(':')
                            chapter_info[label] = spans[1].get_text(strip=True)
                
                results.append({
                    'title': title,
                    'url': f"{self.BASE_URL}{href}",
                    'slug': href.strip('/manga/'),
                    'type': type_info,
                    'cover_url': cover_url,
                    'chapter_start': chapter_info.get('Awal', ''),
                    'chapter_latest': chapter_info.get('Terbaru', ''),
                })
            except Exception as e:
                continue
        
        # Situs mengurutkan hasil menurut popularitas; judul yang persis diketik
        # user ditarik ke atas dulu (lihat BaseScraper._urut_hasil_pencarian).
        return self._urut_hasil_pencarian(query, results)
    
    def get_manga_detail(self, url: str) -> Optional[Dict[str, Any]]:
        """Get manga details from komiku.org with COMPLETE info"""
        html = self._get_page(url)
        
        if not html:
            return None
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # Extract manga data from JavaScript
        manga_data = {}
        script_text = soup.find('script', string=re.compile(r'var mangaData'))
        if script_text and script_text.string:
            match = re.search(r"var mangaData=\{([^}]+)\}", script_text.string)
            if match:
                data_str = match.group(1)
                for key_match in re.finditer(r"(\w+):['\"]([^'\"]+)['\"]", data_str):
                    manga_data[key_match.group(1)] = key_match.group(2)
        
        # Get title
        title = manga_data.get('judul', '')
        if not title:
            title_tag = soup.find('h1', class_='entry-title')
            if title_tag:
                title = title_tag.get_text(strip=True)
        
        # Get cover image — utamakan file ASLI.
        # mangaData.cover = tanpa parameter ukuran (paling jernih),
        # og:image cuma fallback karena biasanya dipatok ?w=1200.
        cover_candidates = []
        cover_url = manga_data.get('cover', '')
        if cover_url:
            cover_candidates.append(cover_url)
        og_image = soup.find('meta', property='og:image')
        if og_image and og_image.get('content'):
            og = og_image['content']
            cover_candidates.append(self._strip_size_param(og))   # versi tanpa ?w=
            cover_candidates.append(og)
        
        cover_candidates = self._dedupe_urls(cover_candidates)
        # Mirror fallback: komiku.to sering mati (connect timeout), sedangkan
        # komiku.org hidup. Tambahkan versi .org tiap kandidat dan urutkan
        # DULUAN, biar cover ke download langsung tanpa nunggu timeout 30s.
        cover_candidates = [
            cand for pair in (
                self._org_mirror(u) for u in cover_candidates
            ) for cand in pair
        ]
        cover_candidates = self._dedupe_urls(cover_candidates)
        cover_url = cover_candidates[0] if cover_candidates else ''
        
        # Get info table
        info_table = soup.find('table', class_='inftable')
        raw_info = {}
        if info_table:
            for row in info_table.find_all('tr'):
                cells = row.find_all('td')
                if len(cells) >= 2:
                    key = cells[0].get_text(strip=True).rstrip(':')
                    value = cells[1].get_text(strip=True)
                    raw_info[key] = value
        
        # Get genres (from genre list items)
        genres = []
        genre_list = soup.find_all('li', class_='genre')
        for g in genre_list:
            a = g.find('a')
            if a:
                genres.append(a.get_text(strip=True))
        
        # Get synopsis
        synopsis = ''
        desc = soup.find('p', class_='desc')
        if desc:
            synopsis = desc.get_text(strip=True)
        else:
            sinopsis_h2 = soup.find('h2', string=re.compile(r'Sinopsis', re.I))
            if sinopsis_h2:
                next_p = sinopsis_h2.find_next('p')
                if next_p:
                    synopsis = next_p.get_text(strip=True)
        
        # Get chapters
        chapters = []
        chapter_rows = soup.find_all('td', class_='judulseries')
        for row in chapter_rows:
            a = row.find('a')
            if a:
                href = a.get('href', '')
                name = a.get_text(strip=True)
                if href and name:
                    chapters.append({
                        'title': name,
                        'url': f"{self.BASE_URL}{href}" if href.startswith('/') else href,
                    })
        
        # Build complete info
        complete_info = {
            'title': title,
            'cover_url': cover_url,
            'cover_candidates': cover_candidates,
            'genres': genres,
            'synopsis': synopsis,
            'info': {
                'title': title,
                'alternative_title': raw_info.get('Judul Alternatif', ''),
                'type': raw_info.get('Tipe', ''),
                'theme': raw_info.get('Tema', ''),
                'author': raw_info.get('Author', ''),
                'artist': raw_info.get('Author', ''),  # Same as author for this site
                'status': raw_info.get('Status', ''),
                'rating': raw_info.get('Rating', ''),
                'reading_direction': raw_info.get('Cara Baca', ''),
            },
            'total_chapters': len(chapters),
            'source': 'komiku.org',
            'source_url': url,
            'chapters': chapters,
        }
        
        return complete_info
    
    def get_chapter_images_ordered(self, url: str) -> List[Dict[str, Any]]:
        """
        Get all image URLs for a chapter WITH CORRECT ORDER.
        
        komiku.org uses ID attributes (1, 2, 3, ...) for image ordering.
        """
        html = self._get_page(url)
        
        if not html:
            return []
        
        soup = BeautifulSoup(html, 'html.parser')
        ordered_images = []
        
        # Method 1: Kumpulkan SEMUA gambar ber-id angka, urutkan berdasarkan id.
        # (pakai dict supaya robust walau ada id yang bolong/gap di tengah)
        numbered = {}
        for img in soup.find_all('img'):
            img_id = img.get('id', '')
            if not img_id.isdigit():
                continue
            n = int(img_id)
            if n < 1 or n > 500:
                continue
            src = img.get('src', '') or img.get('data-src', '')
            if src and ('komiku.to' in src or 'komiku.org' in src):
                if 'komiku-promosi' not in src:
                    # setdefault: ambil kemunculan pertama kalau id dobel
                    numbered.setdefault(n, src)
        for n in sorted(numbered):
            ordered_images.append({
                'order': n,
                'url': numbered[n],
            })
        
        # Method 2: Fallback
        if not ordered_images:
            all_imgs = soup.find_all('img', class_=re.compile(r'klazy|ww'))
            order = 0
            for img in all_imgs:
                src = img.get('src', '') or img.get('data-src', '')
                if src and ('komiku.to' in src or 'komiku.org' in src):
                    if 'komiku-promosi' not in src:
                        order += 1
                        ordered_images.append({
                            'order': order,
                            'url': src,
                        })
        
        return ordered_images
    
    def get_chapter_images(self, url: str) -> List[str]:
        """Get all image URLs for a chapter (backward compatible)"""
        ordered = self.get_chapter_images_ordered(url)
        return [img['url'] for img in ordered]
    
    def download_manga(self, manga_url: str, max_workers: int = None, progress=None,
                       chapters=None, target_dir=None) -> bool:
        """Download manga using base class with parallel workers"""
        return super().download_manga(manga_url, max_workers=max_workers, progress=progress,
                                      chapters=chapters, target_dir=target_dir)
    

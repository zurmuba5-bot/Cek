#!/usr/bin/env python3
"""
Test penamaan berkas CBZ, laporan halaman gagal, + deteksi chapter kembar
softkomik (semuanya tanpa network).

Yang divalidasi:
  - nama berkas chapter angka biasa TIDAK berubah (chapter-005.cbz,
    chapter-179.5.cbz) -> CBZ yang sudah keunduh tetap dikenali
  - nomor bersuffix dari situs tidak lagi jadi nama bertitik dobel
    ("Chapter 149.side-1" -> chapter-149-side-1.cbz, bukan chapter-149..cbz)
  - nama berkas tetap unik walau judul chapter-nya sama persis
  - halaman yang gagal diunduh tidak ikut ke CBZ dan DILAPORKAN (dulu hilang
    diam-diam selama masih di bawah 20%)
  - chapter varian (149.side-1 vs 149) dianggap kembar HANYA kalau sampel
    halamannya sama; kalau isinya beda (107 vs 107.e) dua-duanya tetap diunduh

Jalankan: python test_unduhan_cbz.py   (atau pytest test_unduhan_cbz.py)
"""
import io
import tempfile
import zipfile
from pathlib import Path

from PIL import Image

from scraper.base import BaseScraper, ProgressTracker
from scraper.softkomik import SoftkomikScraper


class _DummyScraper(BaseScraper):
    """Scraper kosong buat nge-test penamaan tanpa network."""

    def search(self, query):
        return []

    def get_manga_detail(self, url):
        return None

    def get_chapter_images_ordered(self, url):
        return []


def _scraper() -> _DummyScraper:
    return _DummyScraper(tempfile.mkdtemp(prefix="test_nama_"))


def _png(color, size=(300, 400)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, "PNG")
    return buf.getvalue()


def _scraper_kembar(halaman_a, halaman_b) -> SoftkomikScraper:
    """Scraper softkomik palsu: 2 chapter dengan daftar gambar + isi yang ditentukan."""
    sc = SoftkomikScraper(tempfile.mkdtemp(prefix="test_kembar_"))
    daftar = {'a': [], 'b': []}
    peta = {}
    for buku, halaman in (('a', halaman_a), ('b', halaman_b)):
        for i, isi in enumerate(halaman, 1):
            url = f'fake://{buku}/{i}'
            daftar[buku].append({'order': i, 'url': url})
            peta[url] = isi
    sc.get_chapter_images_ordered = lambda url: daftar[url]
    sc._download_image_with_retry = lambda url: peta[url]
    return sc


# --------------------------------------------------------------- penamaan ---
def test_nama_chapter_angka_biasa_tidak_berubah():
    sc = _scraper()
    harap = {
        'Chapter 5': 'chapter-005.cbz',
        'Chapter 10': 'chapter-010.cbz',
        'Chapter 149': 'chapter-149.cbz',
        'Chapter 921': 'chapter-921.cbz',
        'Chapter 1000': 'chapter-1000.cbz',
        'Chapter 179.5': 'chapter-179.5.cbz',      # chapter desimal: tetap
        'Chapter 40.5': 'chapter-40.5.cbz',
        'Chapter 179 End': 'chapter-179.cbz',      # komikindo: kata tambahan diabaikan
    }
    for judul, inginkan in harap.items():
        dapat = sc._nama_cbz(judul)
        assert dapat == inginkan, f"{judul}: {dapat} != {inginkan}"
    print("✓ nama chapter angka biasa tetap sama seperti sebelumnya")


def test_nomor_suffix_dari_situs_tidak_jadi_titik_dobel():
    sc = _scraper()
    harap = {
        'Chapter 149.side-1': 'chapter-149-side-1.cbz',
        'Chapter 107.e': 'chapter-107-e.cbz',
        'Chapter 40.end-s1': 'chapter-040-end-s1.cbz',
        'Chapter 110.end-s3': 'chapter-110-end-s3.cbz',
        'Chapter 70.end-s2': 'chapter-070-end-s2.cbz',
    }
    for judul, inginkan in harap.items():
        dapat = sc._nama_cbz(judul)
        assert dapat == inginkan, f"{judul}: {dapat} != {inginkan}"
        assert '..' not in dapat, f"{judul}: masih bertitik dobel -> {dapat}"
    print("✓ nomor bersuffix: tidak ada lagi nama seperti chapter-149..cbz")


def test_rencana_cbz_unik_dan_dilaporkan():
    sc = _scraper()
    folder = Path(sc.download_dir)
    chapters = [
        {'title': 'Chapter 149', 'url': 'a'},
        {'title': 'Chapter 149.side-1', 'url': 'b'},   # nomor berbeda -> berkas beda
        {'title': 'Chapter 149.side-1', 'url': 'c'},   # judul benar-benar sama
    ]
    rencana, dobel, aneh = sc._rencana_cbz(chapters, folder)

    nama = [p.name for _, p in rencana]
    assert nama == ['chapter-149.cbz', 'chapter-149-side-1.cbz',
                    'chapter-149-side-1_2.cbz'], nama
    assert len(set(nama)) == len(nama), 'ada nama berkas yang bertabrakan'
    assert dobel == ['chapter-149-side-1'], dobel
    assert any('149.side-1' in a for a in aneh), aneh
    print("✓ 3 chapter (nomor sama + suffix sama) -> 3 berkas beda + dilaporkan")


def test_rencana_cbz_tanpa_nomor():
    sc = _scraper()
    folder = Path(sc.download_dir)
    rencana, _dobel, _aneh = sc._rencana_cbz(
        [{'title': 'Prolog', 'url': 'x'}], folder)
    assert rencana[0][1].name == 'chapter-000.cbz'
    print("✓ judul tanpa nomor tetap jadi chapter-000.cbz (seperti sebelumnya)")


def test_nomor_nol_di_depan_dirapikan():
    """Nomor aneh dari situs ('0010', '0001') tidak bikin nama berkas salah urut/dobel."""
    sc = _scraper()
    harap = {
        # nol di depan dirapikan; bentuk normal tetap sama seperti sebelumnya
        'Chapter 0010': 'chapter-010.cbz',
        'Chapter 0001': 'chapter-001.cbz',
        'Chapter 010': 'chapter-010.cbz',
        'Chapter 1': 'chapter-001.cbz',
        'Chapter 00010': 'chapter-010.cbz',
        'Chapter 0179.5': 'chapter-179.5.cbz',   # desimal: cuma bagian depan
        'Chapter 0010.side-1': 'chapter-010-side-1.cbz',
        'Chapter 0001.e': 'chapter-001-e.cbz',
    }
    for judul, inginkan in harap.items():
        dapat = sc._nama_cbz(judul)
        assert dapat == inginkan, f"{judul}: {dapat} != {inginkan}"
    # '0010' harus tersortir setelah '009', bukan sebelum
    assert sc._nama_cbz('Chapter 0010') > sc._nama_cbz('Chapter 009')
    print("✓ nomor nol-di-depan ('0010', '0001') dirapikan & tersortir benar")


def test_tidak_ada_chapter_hilang_karena_nama_aneh():
    """Nama aneh/sama TIDAK membuang chapter: jumlah rencana = jumlah chapter.

    Yang bentrok diberi akhiran _2/_3, jadi tiap chapter tetap punya berkasnya
    sendiri -- cuma chapter yang isinya=identik (softkomik) yang boleh dibuang.
    """
    sc = _scraper()
    folder = Path(sc.download_dir)
    chapters = [
        {'title': 'Chapter 1', 'url': 'a'},
        {'title': 'Chapter 001', 'url': 'b'},     # nomor sama, nama beda -> tetap
        {'title': 'Chapter 0001', 'url': 'c'},    # nomor sama lagi -> tetap
        {'title': 'Chapter 0010', 'url': 'd'},
        {'title': 'Chapter 010', 'url': 'e'},     # bentrok dgn '0010' -> _2
        {'title': 'Chapter 10', 'url': 'f'},      # bentrok lagi -> _3
        {'title': 'Chapter 149.side-1', 'url': 'g'},
        {'title': 'Prolog', 'url': 'h'},
    ]
    rencana, dobel, _aneh = sc._rencana_cbz(chapters, folder)
    nama = [p.name for _, p in rencana]
    assert len(rencana) == len(chapters), (len(rencana), len(chapters))
    assert len(set(nama)) == len(nama), 'ada nama berkas bertabrakan'
    for harus_ada in ('chapter-001.cbz', 'chapter-001_2.cbz', 'chapter-001_3.cbz',
                      'chapter-010.cbz', 'chapter-010_2.cbz', 'chapter-010_3.cbz',
                      'chapter-149-side-1.cbz', 'chapter-000.cbz'):
        assert harus_ada in nama, f"{harus_ada} hilang dari {nama}"
    assert dobel, 'bentrok nama seharusnya dilaporkan'
    print("✓ nama aneh/sama tidak menghilangkan chapter (8 chapter -> 8 berkas)")


# ------------------------------------------------- chapter kembar softkomik ---
def test_varian_chapter_tidak_salah_kenali_chapter_desimal():
    assert SoftkomikScraper._varian_chapter('149.side-1') == ('149', 'side-1')
    assert SoftkomikScraper._varian_chapter('107.e') == ('107', 'e')
    assert SoftkomikScraper._varian_chapter('40.end-s1') == ('40', 'end-s1')
    # nomor biasa & chapter desimal BUKAN varian
    assert SoftkomikScraper._varian_chapter('080') is None
    assert SoftkomikScraper._varian_chapter('179.5') is None
    assert SoftkomikScraper._varian_chapter('') is None
    print("✓ varian chapter: '179.5' tetap dianggap chapter biasa, bukan varian")


def test_chapter_kembar_dilewat_kalau_isinya_sama():
    isi = [_png((200, 30, 30)) for _ in range(12)]
    sc = _scraper_kembar(isi, list(isi))
    chapters = [
        {'title': 'Chapter 149', 'number': '149', 'url': 'a'},
        {'title': 'Chapter 149.side-1', 'number': '149.side-1', 'url': 'b'},
    ]
    sisa = sc._buang_chapter_kembar(chapters)
    assert [c['url'] for c in sisa] == ['a'], sisa
    print("✓ chapter varian yang isinya sama dilewat (tidak dobel)")


def test_varian_tetap_diunduh_kalau_isinya_beda():
    satu = [_png((10, 10, 200)) for _ in range(12)]
    dua = [_png((200, 200, 20)) for _ in range(12)]
    sc = _scraper_kembar(satu, dua)
    chapters = [
        {'title': 'Chapter 107', 'number': '107', 'url': 'a'},
        {'title': 'Chapter 107.e', 'number': '107.e', 'url': 'b'},
    ]
    sisa = sc._buang_chapter_kembar(chapters)
    assert len(sisa) == 2, sisa
    print("✓ varian yang isinya beda (107 vs 107.e) tetap dua-duanya diunduh")


def test_varian_tanpa_induk_tidak_disentuh():
    sc = _scraper_kembar([_png((1, 2, 3))], [_png((1, 2, 3))])
    chapters = [{'title': 'Chapter 40.end-s1', 'number': '40.end-s1', 'url': 'b'}]
    sisa = sc._buang_chapter_kembar(chapters)
    assert len(sisa) == 1, sisa
    print("✓ varian tanpa chapter induk di daftar tetap diunduh")


def test_varian_pendek_tidak_dibuang():
    """Chapter pendek (sampel sedikit) jangan dibuang cuma karena mirip."""
    isi = [_png((90, 20, 20)) for _ in range(2)]
    sc = _scraper_kembar(isi, list(isi))
    chapters = [
        {'title': 'Chapter 9', 'number': '9', 'url': 'a'},
        {'title': 'Chapter 9.e', 'number': '9.e', 'url': 'b'},
    ]
    sisa = sc._buang_chapter_kembar(chapters)
    assert len(sisa) == 2, sisa
    print("✓ chapter pendek: bukti terlalu tipis -> tidak dibuang")


def test_softkomik_dedupe_baris_kembar_saja():
    """Baris API yang benar-benar kembar dibuang; nomor beda (walau mirip) tetap."""
    sc = SoftkomikScraper(tempfile.mkdtemp(prefix='test_dedupe_'))
    rows = [{'chapter': '001'}, {'chapter': '001'}, {'chapter': '0010'},
            {'chapter': '010'}, {'chapter': '002'}]
    sc._api_get = lambda *a, **k: {'chapter': rows}
    chapters = sc._chapter_entries('judul')
    nomor = [c['number'] for c in chapters]
    assert nomor == ['001', '0010', '010', '002'], nomor
    print("✓ baris API kembar dibuang, nomor yang beda tetap diunduh")


def test_banner_situs_tidak_dianggap_bukti_kembar():
    """Banner 00-hello nempel di akhir SEMUA chapter -> jangan bikin false positive."""
    sc = SoftkomikScraper(tempfile.mkdtemp(prefix='test_banner_'))
    daftar = {
        'a': [{'order': 1, 'url': 'fake://a/1'},
              {'order': 2, 'url': 'https://cdn/00-hello/banner.webp'}],
        'b': [{'order': 1, 'url': 'fake://b/1'},
              {'order': 2, 'url': 'https://cdn/00-hello/banner.webp'}],
    }
    peta = {
        'fake://a/1': _png((250, 10, 10)),
        'fake://b/1': _png((10, 250, 10)),      # halaman isi beda
        'https://cdn/00-hello/banner.webp': _png((0, 0, 0)),
    }
    sc.get_chapter_images_ordered = lambda url: daftar[url]
    sc._download_image_with_retry = lambda url: peta[url]

    chapters = [
        {'title': 'Chapter 12', 'number': '12', 'url': 'a'},
        {'title': 'Chapter 12.side-1', 'number': '12.side-1', 'url': 'b'},
    ]
    sisa = sc._buang_chapter_kembar(chapters)
    assert len(sisa) == 2, sisa
    print("✓ banner situs di akhir chapter tidak dianggap bukti chapter kembar")


# -------------------------------------------- halaman gagal diunduh dilaporkan ---
class _CatatProgress:
    """ProgressTracker palsu: catat hasil chapter tanpa menggambar apa pun."""

    def __init__(self):
        self.selesai = []

    def start_chapter(self, *a, **k):
        pass

    def update_chapter(self, *a, **k):
        pass

    def complete_chapter(self, chapter, size_kb, images=0, gagal=None):
        self.selesai.append((chapter, images, list(gagal or [])))

    def fail_chapter(self, chapter, reason):
        raise AssertionError(f"chapter gagal diproses: {reason}")

    def skip_chapter(self, *a, **k):
        pass

    def summary(self):
        pass


def test_halaman_gagal_tidak_ikut_cbz_dan_dilaporkan():
    sc = _scraper()
    ordered = [{'order': i, 'url': f'fake://img/{i}'} for i in range(1, 6)]
    isi = {f'fake://img/{i}': _png((i * 30, 20, 20), (500, 300)) for i in range(1, 6)}
    sc.get_chapter_images_ordered = lambda url: ordered
    # halaman 3 gagal diunduh (seperti kasus nyata di softkomik: jawaban 200 tapi
    # isinya cuma beberapa ratus byte, jadi dianggap gagal)
    sc._download_image_with_retry = lambda url: (None if url == 'fake://img/3' else isi[url])

    progress = _CatatProgress()
    ok = sc._process_chapter({'title': 'Chapter 7', 'url': 'fake://chapter'},
                             Path(sc.download_dir), progress)
    assert ok, 'chapter seharusnya tetap jadi (4/5 halaman berhasil)'

    _chapter, _images, gagal = progress.selesai[0]
    assert gagal == [3], gagal

    with zipfile.ZipFile(Path(sc.download_dir) / 'chapter-007.cbz') as zf:
        assert len(zf.namelist()) == 4, zf.namelist()
    print("✓ halaman yang gagal diunduh dilaporkan dan tidak ikut ke CBZ")


def test_tracker_menyimpan_dan_menuliskan_halaman_gagal():
    baris = []
    p = ProgressTracker(1, batch=True, log_sink=baris.append)
    p.complete_chapter('Chapter 7', 900.0, 4, gagal=[12, 47, 71, 5, 6, 7, 8, 9, 10])

    assert p._halaman_gagal == [('Chapter 7', [5, 6, 7, 8, 9, 10, 12, 47, 71])], p._halaman_gagal
    assert p.results[0]['gagal_halaman'] == [5, 6, 7, 8, 9, 10, 12, 47, 71]
    assert any('halaman gagal' in b for b in baris), baris
    assert ProgressTracker._ringkas_halaman([1]) == '1'
    assert ProgressTracker._ringkas_halaman(list(range(10))).endswith('dan 2 lagi')
    print("✓ tracker menyimpan + menuliskan halaman gagal (dipakai di ringkasan)")


if __name__ == '__main__':
    test_nama_chapter_angka_biasa_tidak_berubah()
    test_nomor_suffix_dari_situs_tidak_jadi_titik_dobel()
    test_rencana_cbz_unik_dan_dilaporkan()
    test_rencana_cbz_tanpa_nomor()
    test_nomor_nol_di_depan_dirapikan()
    test_tidak_ada_chapter_hilang_karena_nama_aneh()
    test_varian_chapter_tidak_salah_kenali_chapter_desimal()
    test_chapter_kembar_dilewat_kalau_isinya_sama()
    test_varian_tetap_diunduh_kalau_isinya_beda()
    test_varian_tanpa_induk_tidak_disentuh()
    test_varian_pendek_tidak_dibuang()
    test_softkomik_dedupe_baris_kembar_saja()
    test_banner_situs_tidak_dianggap_bukti_kembar()
    test_halaman_gagal_tidak_ikut_cbz_dan_dilaporkan()
    test_tracker_menyimpan_dan_menuliskan_halaman_gagal()
    print("\n✅ SEMUA TEST LULUS")

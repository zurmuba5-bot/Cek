#!/usr/bin/env python3
"""
Image Enhancement Script - Sharpen + Denoise for Manga/Manhwa
Makes images sharper while keeping file sizes small
"""
import os
import io
import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import pillow_avif

# Settings
OUTPUT_DIR = "enhanced_images"
TARGET_WIDTH = 500
QUALITY = 40

# Enhancement settings
SHARPNESS_FACTOR = 1.5  # 1.0 = no change, >1.0 = sharper
CONTRAST_FACTOR = 1.2   # 1.0 = no change, >1.0 = more contrast
DENOISE_STRENGTH = 10   # Higher = more denoising

def enhance_image_pil(image):
    """Enhance image using Pillow (fast, good for manga)"""
    # Convert to RGB if needed
    if image.mode != 'RGB':
        image = image.convert('RGB')
    
    # 1. Sharpen
    enhancer = ImageEnhance.Sharpness(image)
    image = enhancer.enhance(SHARPNESS_FACTOR)
    
    # 2. Increase contrast slightly
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(CONTRAST_FACTOR)
    
    # 3. Slight denoise using median filter
    image = image.filter(ImageFilter.MedianFilter(size=3))
    
    # 4. Sharpen again after denoise
    enhancer = ImageEnhance.Sharpness(image)
    image = enhancer.enhance(1.2)
    
    return image

def enhance_image_opencv(image):
    """Enhance image using OpenCV (better denoising)"""
    # Convert PIL to numpy array
    img_array = np.array(image)
    
    # Convert RGB to BGR for OpenCV
    if len(img_array.shape) == 3:
        img_bgr = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
    else:
        img_bgr = img_array
    
    # 1. Denoise using Non-Local Means (simplified parameters)
    denoised = cv2.fastNlMeansDenoisingColored(
        img_bgr, 
        None, 
        DENOISE_STRENGTH,  # h - Filter strength for color
        DENOISE_STRENGTH,  # hForColorComponents - not needed as keyword
        7,  # templateWindowSize
        21  # searchWindowSize
    )
    
    # 2. Sharpen using Unsharp Mask
    gaussian = cv2.GaussianBlur(denoised, (0, 0), 3)
    sharpened = cv2.addWeighted(denoised, 1.5, gaussian, -0.5, 0)
    
    # 3. Increase contrast using CLAHE
    lab = cv2.cvtColor(sharpened, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    l = clahe.apply(l)
    enhanced = cv2.merge([l, a, b])
    enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2BGR)
    
    # Convert back to RGB
    enhanced_rgb = cv2.cvtColor(enhanced, cv2.COLOR_BGR2RGB)
    
    # Convert back to PIL
    return Image.fromarray(enhanced_rgb)

def enhance_images():
    """Download, enhance, and convert images"""
    
    from scraper import KomikindoScraper
    
    # Create output directories
    os.makedirs(f"{OUTPUT_DIR}/original", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/enhanced_pil", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/enhanced_opencv", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/webp", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/avif", exist_ok=True)
    
    scraper = KomikindoScraper()
    
    print("=== IMAGE ENHANCEMENT ===")
    print()
    print("Settings:")
    print(f"  Target width: {TARGET_WIDTH}px")
    print(f"  Quality: {QUALITY}")
    print(f"  Sharpness: {SHARPNESS_FACTOR}x")
    print(f"  Contrast: {CONTRAST_FACTOR}x")
    print(f"  Denoise strength: {DENOISE_STRENGTH}")
    print()
    
    # Get ordered images
    print("Getting images from komikindo.ch...")
    ordered = scraper.get_chapter_images_ordered('https://komikindo.ch/magic-emperor-chapter-906/')
    print(f"Found {len(ordered)} images")
    print()
    
    total_original = 0
    total_enhanced_pil = 0
    total_enhanced_opencv = 0
    total_webp = 0
    total_avif = 0
    
    for img in ordered:
        order = img['order']
        url = img['url']
        
        print(f"Processing image {order}/{len(ordered)}...")
        
        # Download image
        resp = scraper.session.get(url, timeout=30)
        original_data = resp.content
        original_size = len(original_data)
        total_original += original_size
        
        # Save original
        original_path = f"{OUTPUT_DIR}/original/{order:03d}.jpeg"
        with open(original_path, 'wb') as f:
            f.write(original_data)
        
        # Open image
        image = Image.open(io.BytesIO(original_data))
        orig_width, orig_height = image.size
        
        # Resize to target width (maintain aspect ratio)
        if orig_width > TARGET_WIDTH:
            ratio = TARGET_WIDTH / orig_width
            new_height = int(orig_height * ratio)
            image = image.resize((TARGET_WIDTH, new_height), Image.LANCZOS)
        
        # Enhance with Pillow
        enhanced_pil = enhance_image_pil(image)
        enhanced_pil.save(f"{OUTPUT_DIR}/enhanced_pil/{order:03d}.jpeg", quality=95)
        enhanced_pil_size = os.path.getsize(f"{OUTPUT_DIR}/enhanced_pil/{order:03d}.jpeg")
        total_enhanced_pil += enhanced_pil_size
        
        # Enhance with OpenCV
        enhanced_opencv = enhance_image_opencv(image)
        enhanced_opencv.save(f"{OUTPUT_DIR}/enhanced_opencv/{order:03d}.jpeg", quality=95)
        enhanced_opencv_size = os.path.getsize(f"{OUTPUT_DIR}/enhanced_opencv/{order:03d}.jpeg")
        total_enhanced_opencv += enhanced_opencv_size
        
        # Use OpenCV enhanced for final conversion (better quality)
        final_image = enhanced_opencv
        
        # Convert to WebP
        webp_path = f"{OUTPUT_DIR}/webp/{order:03d}.webp"
        final_image.save(webp_path, "WEBP", quality=QUALITY)
        webp_size = os.path.getsize(webp_path)
        total_webp += webp_size
        
        # Convert to AVIF
        avif_path = f"{OUTPUT_DIR}/avif/{order:03d}.avif"
        final_image.save(avif_path, "AVIF", quality=QUALITY)
        avif_size = os.path.getsize(avif_path)
        total_avif += avif_size
        
        print(f"  Original:    {orig_width}x{orig_height} | {original_size/1024:.1f} KB")
        print(f"  Enhanced PIL:     | {enhanced_pil_size/1024:.1f} KB")
        print(f"  Enhanced OpenCV:  | {enhanced_opencv_size/1024:.1f} KB")
        print(f"  WebP:        | {webp_size/1024:.1f} KB ({(1-webp_size/original_size)*100:.1f}% smaller)")
        print(f"  AVIF:        | {avif_size/1024:.1f} KB ({(1-avif_size/original_size)*100:.1f}% smaller)")
        print()
    
    print("=== SUMMARY ===")
    print(f"Original:       {total_original/1024/1024:.2f} MB")
    print(f"Enhanced PIL:   {total_enhanced_pil/1024/1024:.2f} MB")
    print(f"Enhanced OpenCV:{total_enhanced_opencv/1024/1024:.2f} MB")
    print(f"WebP:           {total_webp/1024/1024:.2f} MB ({(1-total_webp/total_original)*100:.1f}% smaller)")
    print(f"AVIF:           {total_avif/1024/1024:.2f} MB ({(1-total_avif/total_original)*100:.1f}% smaller)")
    print()
    print(f"Files saved to: {OUTPUT_DIR}/")

if __name__ == "__main__":
    enhance_images()

# 📋 Rencana Penanganan Urutan Gambar

## 🚨 Masalah Kritis

### komikindo.ch
```
Filename: azpQz8mtPgOklGnKSzDPQa7Z76XSZHjOYN6dyXUU.jpeg
          LKvOV8n1E8XmL7yaHKt5Ac2WtPPyiFKPjpcmYX4J.jpeg
          fOlwW8RVurysi7GiBAdZKn9c6SLQpSGjVbGwqxXN.jpeg
```
- Filename adalah **HASH random**
- **TIDAK bisa diurutkan berdasarkan filename**
- Urutan HARUS diambil dari **posisi di HTML**

### komiku.org
```
Filename: 1.webp, 2.webp, 3.webp, ... (urut)
```
- Filename sudah urut (lebih mudah)
- Tapi tetap harus **validasi dari HTML**

---

## ✅ Solusi: Smart Image Ordering

### Prinsip Dasar
1. **Urutan = Posisi di HTML** (bukan filename)
2. **Rename saat download** → 001.ext, 002.ext, 003.ext
3. **Validasi** = jumlah gambar harus sesuai dengan yang diklaim situs

### Alur Kerja
```
HTML Parsing → Extract URLs (dengan urutan) → Download → Rename → Save
     ↓              ↓                              ↓         ↓       ↓
  posisi 1      URL gambar 1                  download   001.ext  folder/
  posisi 2      URL gambar 2                  download   002.ext  chapter/
  posisi 3      URL gambar 3                  download   003.ext  ...
```

---

## 🔧 Implementasi

### 1. komiku.org
```python
# Urutan dari HTML: gunakan ID gambar (1, 2, 3, ...)
images = []
for i in range(1, max_chapter + 1):
    img = soup.find('img', id=str(i))
    if img:
        images.append({
            'order': i,
            'url': img['src']
        })

# Rename: 1.webp → 001.webp
for img in images:
    new_name = f"{img['order']:03d}.webp"
    # download & save as new_name
```

### 2. komikindo.ch
```python
# Urutan dari HTML: posisi dalam div.img-landmine
landmine = soup.find('div', class_='img-landmine')
images = []
for idx, img in enumerate(landmine.find_all('img'), 1):
    images.append({
        'order': idx,
        'url': img['src']
    })

# Rename: random_hash.jpeg → 001.jpeg
for img in images:
    new_name = f"{img['order']:03d}.jpeg"
    # download & save as new_name
```

---

## 🛡️ Validasi

### Cek 1: Jumlah Gambar
```python
expected_count = chapter_data.get('jumlahgambar', 0)  # dari JS
actual_count = len(images)
assert expected_count == actual_count, "Jumlah gambar tidak cocok!"
```

### Cek 2: URL Unik
```python
urls = [img['url'] for img in images]
assert len(urls) == len(set(urls), "Ada URL duplikat!")
```

### Cek 3: Urutan Konsisten
```python
# Pastikan tidak ada gap dalam urutan
orders = [img['order'] for img in images]
assert orders == list(range(1, len(images) + 1)), "Urutan tidak konsisten!"
```

---

## 📁 Output Structure

```
downloads/
└── Magic_Emperor/
    ├── cover.jpg
    ├── info.json
    └── Chapter_906/
        ├── 001.webp    ← urutan benar
        ├── 002.webp
        ├── 003.webp
        ├── ...
        └── 031.webp
```

---

## ⚠️ Edge Cases

1. **Gambar gagal download** → Skip dan log, jangan break urutan
2. **CDN berbeda untuk setiap gambar** → Sudah ditangani
3. **Gambar duplicate** → Filter berdasarkan URL
4. **Chapter dengan gambar sedikit** (< 5) → Validasi extra

---

## 🎯 Status

- [ ] Implementasi smart ordering di komiku.py
- [ ] Implementasi smart ordering di komikindo.py
- [ ] Test dengan chapter asli
- [ ] Validasi urutan vs browser

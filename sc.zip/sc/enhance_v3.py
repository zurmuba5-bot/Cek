#!/usr/bin/env python3
"""
Image Enhancement V3 - Remove Artifacts, Preserve Colors
Hilangkan artefak noise tanpa ubah warna
"""
import os
import io
import cv2
import numpy as np
from PIL import Image
import pillow_avif

# Settings
OUTPUT_DIR = "enhanced_v3"
TARGET_WIDTH = 500
QUALITY = 40

def remove_artifacts(original):
    """
    Hapus artefak dan noise TANPA ubah warna
    Menggunakan Non-Local Means Denoising
    """
    # Convert to numpy
    img_array = np.array(original)
    
    # Convert RGB to BGR for OpenCV
    img_bgr = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
    
    # Convert to LAB color space (better for denoising)
    lab = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    
    # Denoise L channel only (preserves color)
    # h=3-5: mild denoising, h=7-10: moderate, h=12-15: strong
    l_denoised = cv2.fastNlMeansDenoising(l, None, 5, 7, 21)
    
    # Merge back
    lab_denoised = cv2.merge([l_denoised, a, b])
    img_denoised = cv2.cvtColor(lab_denoised, cv2.COLOR_LAB2BGR)
    
    # Convert back to RGB
    img_rgb = cv2.cvtColor(img_denoised, cv2.COLOR_BGR2RGB)
    
    return Image.fromarray(img_rgb)

def remove_artifacts_sharp(original):
    """
    Hapus artefak + tambah ketajaman ringan
    """
    # Step 1: Remove artifacts
    denoised = remove_artifacts(original)
    
    # Step 2: Light sharpening (high-pass)
    img_array = np.array(denoised).astype(np.float32)
    
    # High-pass filter for detail
    low_pass = cv2.GaussianBlur(img_array, (0, 0), 2)
    high_pass = img_array - low_pass
    
    # Add detail back (conservative)
    sharpened = img_array + 0.5 * high_pass
    
    # Clip
    sharpened = np.clip(sharpened, 0, 255).astype(np.uint8)
    
    return Image.fromarray(sharpened)

def enhance_images():
    """Download, enhance, and convert"""
    
    from scraper import KomikindoScraper
    
    # Create output directories
    os.makedirs(f"{OUTPUT_DIR}/original", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/denoised", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/denoised_sharp", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/webp", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/avif", exist_ok=True)
    
    scraper = KomikindoScraper()
    
    print("=== IMAGE ENHANCEMENT V3 ===")
    print()
    print("Method: Non-Local Means Denoising (Color Preserved)")
    print()
    
    # Get ordered images
    print("Getting images from komikindo.ch...")
    ordered = scraper.get_chapter_images_ordered('https://komikindo.ch/magic-emperor-chapter-906/')
    print(f"Found {len(ordered)} images")
    print()
    
    total_original = 0
    total_denoised = 0
    total_denoised_sharp = 0
    total_webp = 0
    total_avif = 0
    
    for img in ordered:
        order = img['order']
        url = img['url']
        
        print(f"Processing image {order}/{len(ordered)}...")
        
        # Download image
        resp = scraper.session.get(url, timeout=30)
        original_data = resp.content
        original_size = len(original_data)
        total_original += original_size
        
        # Save original
        original_path = f"{OUTPUT_DIR}/original/{order:03d}.jpeg"
        with open(original_path, 'wb') as f:
            f.write(original_data)
        
        # Open image
        image = Image.open(io.BytesIO(original_data))
        orig_width, orig_height = image.size
        
        # Resize to target width
        if orig_width > TARGET_WIDTH:
            ratio = TARGET_WIDTH / orig_width
            new_height = int(orig_height * ratio)
            image = image.resize((TARGET_WIDTH, new_height), Image.LANCZOS)
        
        # Check original color
        orig_arr = np.array(image)
        print(f"  Original: {orig_width}x{orig_height} | Color: R={orig_arr[:,:,0].mean():.0f}, G={orig_arr[:,:,1].mean():.0f}, B={orig_arr[:,:,2].mean():.0f}")
        
        # Denoise only
        denoised = remove_artifacts(image)
        denoised.save(f"{OUTPUT_DIR}/denoised/{order:03d}.jpeg", quality=95)
        denoised_size = os.path.getsize(f"{OUTPUT_DIR}/denoised/{order:03d}.jpeg")
        total_denoised += denoised_size
        
        # Check denoised color
        den_arr = np.array(denoised)
        print(f"  Denoised:  | Color: R={den_arr[:,:,0].mean():.0f}, G={den_arr[:,:,1].mean():.0f}, B={den_arr[:,:,2].mean():.0f} (perubahan: {abs(orig_arr[:,:,0].mean()-den_arr[:,:,0].mean()):.1f})")
        
        # Denoise + Sharpen
        denoised_sharp = remove_artifacts_sharp(image)
        denoised_sharp.save(f"{OUTPUT_DIR}/denoised_sharp/{order:03d}.jpeg", quality=95)
        denoised_sharp_size = os.path.getsize(f"{OUTPUT_DIR}/denoised_sharp/{order:03d}.jpeg")
        total_denoised_sharp += denoised_sharp_size
        
        # Check sharp color
        sharp_arr = np.array(denoised_sharp)
        print(f"  Sharp:     | Color: R={sharp_arr[:,:,0].mean():.0f}, G={sharp_arr[:,:,1].mean():.0f}, B={sharp_arr[:,:,2].mean():.0f} (perubahan: {abs(orig_arr[:,:,0].mean()-sharp_arr[:,:,0].mean()):.1f})")
        
        # Use denoised_sharp for final conversion
        final_image = denoised_sharp
        
        # Convert to WebP
        webp_path = f"{OUTPUT_DIR}/webp/{order:03d}.webp"
        final_image.save(webp_path, "WEBP", quality=QUALITY)
        webp_size = os.path.getsize(webp_path)
        total_webp += webp_size
        
        # Convert to AVIF
        avif_path = f"{OUTPUT_DIR}/avif/{order:03d}.avif"
        final_image.save(avif_path, "AVIF", quality=QUALITY)
        avif_size = os.path.getsize(avif_path)
        total_avif += avif_size
        
        print(f"  Sizes: Original={original_size/1024:.0f}KB, Denoised={denoised_size/1024:.0f}KB, Sharp={denoised_sharp_size/1024:.0f}KB")
        print(f"  WebP={webp_size/1024:.0f}KB ({(1-webp_size/original_size)*100:.0f}% smaller), AVIF={avif_size/1024:.0f}KB ({(1-avif_size/original_size)*100:.0f}% smaller)")
        print()
    
    print("=== SUMMARY ===")
    print(f"Original:       {total_original/1024/1024:.2f} MB")
    print(f"Denoised:       {total_denoised/1024/1024:.2f} MB")
    print(f"Denoised+Sharp: {total_denoised_sharp/1024/1024:.2f} MB")
    print(f"WebP:           {total_webp/1024/1024:.2f} MB ({(1-total_webp/total_original)*100:.1f}% smaller)")
    print(f"AVIF:           {total_avif/1024/1024:.2f} MB ({(1-total_avif/total_original)*100:.1f}% smaller)")
    print()
    print(f"Files saved to: {OUTPUT_DIR}/")

if __name__ == "__main__":
    enhance_images()

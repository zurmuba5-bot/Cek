# 📋 PLAN: CLI Comic Scraper Tool

## 🎯 Overview

High-level CLI tool untuk download manga dari **komiku.org** dan **komikindo.ch** dengan fitur:
- Interactive CLI
- Search & select manga
- Custom chapter range
- Parallel workers (max 10)
- Auto convert AVIF w500 q40
- Output CBZ format
- Skip if already downloaded

---

## 🖥️ User Interface Flow

```
$ ./komik

╔══════════════════════════════════════════════════╗
║           KOMIK SCRAPER v2.0                      ║
║     Download manga from Indonesian sites          ║
╚══════════════════════════════════════════════════╝

Pilih sumber manga:
  [1] komiku.org (tanpa Cloudflare, lebih cepat)
  [2] komikindo.ch (Cloudflare protected)
  [3] softkomik.co (butuh token sesi per chapter)

→ 1

Masukkan judul manga (bisa sebagian/typo):
→ one piece

🔍 Mencari "one piece"...

[1] One Piece
    Type: Manga | Status: Ongoing | Chapters: 1126
    
[2] One Punch Man
    Type: Manga | Status: Ongoing | Chapters: 245
    
[3] One Piece Party
    Type: Manga | Status: Completed | Chapters: 12

Pilih manga (nomor): 1

📊 One Piece - 1126 chapters

Pilih chapter:
  [1] Semua chapter (1-1126)
  [2] Custom range
  [3] Chapter terakhir saja

→ 2

Masukkan range (contoh: 1-10 atau 1,5,10-15):
→ 1100-1126

📥 Download 27 chapters dengan 10 workers...
    Format: AVIF w500 q40 → CBZ

[1/27] Chapter 1100 - Downloading... ✓
[2/27] Chapter 1101 - Downloading... ✓
[3/27] Chapter 1102 - Skip (sudah ada) ○
[4/27] Chapter 1103 - Downloading... ✓
...

✅ Selesai! 26/27 chapters downloaded
📁 Location: downloads/One_Piece/
```

---

## 🏗️ Architecture

### Project Structure
```
comic-scraper/
├── komik                    # CLI entry point (chmod +x)
├── scraper/
│   ├── __init__.py
│   ├── base.py             # Base class + workers
│   ├── komiku.py           # komiku.org scraper
│   ├── komikindo.py        # komikindo.ch scraper
│   ├── softkomik.py        # softkomik.co scraper (butuh token sesi + login
│   │                       #   untuk judul SENSITIVE; cookie di .softkomik-cookies.json)
│   └── cli.py              # CLI interface
├── requirements.txt
└── PLAN.md
```

### Core Components

```
┌─────────────────────────────────────────────┐
│              CLI Interface                   │
│  - Menu selection                            │
│  - Search input                              │
│  - Chapter range input                       │
│  - Progress display                          │
└─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│           Scraper Manager                    │
│  - Select scraper (komiku/komikindo)         │
│  - Search manga                              │
│  - Get detail + chapters                     │
│  - Assign to workers                         │
└─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│          Worker Pool (max 10)                │
│  - Each worker: download → convert → CBZ     │
│  - Progress tracking per worker              │
│  - Skip if already exists                    │
└─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│           Output Structure                   │
│  downloads/                                  │
│  └── Manga_Title/                            │
│      ├── cover.avif                          │
│      ├── info.json                           │
│      ├── chapter-001.cbz                     │
│      ├── chapter-002.cbz                     │
│      └── ...                                 │
└─────────────────────────────────────────────┘
```

---

## 📋 Use Cases (50+)

### A. Search & Selection (10 use cases)

| # | Use Case | Expected Behavior |
|---|----------|-------------------|
| 1 | Exact match | "One Piece" → finds "One Piece" |
| 2 | Partial match | "one pi" → finds "One Piece" |
| 3 | Typo | "one pece" → finds "One Piece" |
| 4 | Case insensitive | "ONE PIECE" → finds "One Piece" |
| 5 | No results | "xyznotfound" → "No manga found" |
| 6 | Multiple results | Show list, user selects |
| 7 | Single result | Auto-select if only 1 |
| 8 | Different language | "ワンピース" → tries to find |
| 9 | Special characters | "One Piece!" → normalizes search |
| 10 | Empty input | "Please enter a search term" |

### B. Chapter Selection (10 use cases)

| # | Use Case | Expected Behavior |
|---|----------|-------------------|
| 1 | All chapters | Downloads all |
| 2 | Single chapter | "5" → downloads chapter 5 |
| 3 | Range | "1-10" → downloads 1-10 |
| 4 | Multiple ranges | "1-5,10-15" → downloads both |
| 5 | From specific | "50-" → downloads 50 to latest |
| 6 | Last N chapters | "-10" → downloads last 10 |
| 7 | Invalid range | "abc" → error message |
| 8 | Out of range | "9999" → "Chapter not found" |
| 9 | Reverse range | "10-1" → "Invalid range" |
| 10 | Decimal chapters | "5.5" → handles special chapters |

### C. Download Process (15 use cases)

| # | Use Case | Expected Behavior |
|---|----------|-------------------|
| 1 | Normal download | Download → convert → CBZ |
| 2 | CBZ exists | Skip chapter |
| 3 | CBZ invalid | Re-download |
| 4 | Image download fail | Retry 3x, then skip image |
| 5 | All images fail | Skip chapter |
| 6 | 80% images fail | Skip chapter |
| 7 | Convert fail | Keep original format |
| 8 | Network timeout | Retry with backoff |
| 9 | Server 429 (rate limit) | Wait and retry |
| 10 | Server 500 | Retry after delay |
| 11 | Server 503 | Retry after longer delay |
| 12 | Connection reset | Retry immediately |
| 13 | DNS failure | Skip with error |
| 14 | SSL error | Skip with error |
| 15 | Interrupted (Ctrl+C) | Save progress, resume later |

### D. Image Handling (10 use cases)

| # | Use Case | Expected Behavior |
|---|----------|-------------------|
| 1 | JPG image | Convert to AVIF |
| 2 | PNG image | Convert to AVIF |
| 3 | WebP image | Convert to AVIF |
| 4 | GIF image | Convert to AVIF (first frame) |
| 5 | AVIF image | Keep as-is or re-convert |
| 6 | Broken image | Skip, log error |
| 7 | Tiny image (<1KB) | Skip (likely placeholder) |
| 8 | Huge image (>10MB) | Resize then convert |
| 9 | Transparent PNG | Flatten to white background |
| 10 | CMYK JPEG | Convert to RGB first |

### E. Output & CBZ (5 use cases)

| # | Use Case | Expected Behavior |
|---|----------|-------------------|
| 1 | Normal CBZ | Pack AVIF images |
| 2 | CBZ validation | Verify all images present |
| 3 | CBZ corruption | Re-create CBZ |
| 4 | Disk full | Stop, report error |
| 5 | Permission denied | Stop, report error |

---

## 🔧 komiku.org Specific

### Image Ordering System

komiku.org uses **HTML ID attributes** for ordering:

```html
<img id="1" src="https://image2.komiku.to/.../1.webp">
<img id="2" src="https://image3.komiku.to/.../2.webp">
<img id="3" src="https://image4.komiku.to/.../3.webp">
```

### Validation Rules

1. **Order Check**: IDs must be sequential (1, 2, 3, ...)
2. **No Gaps**: No missing IDs in sequence
3. **No Duplicates**: Same ID not repeated
4. **Count Match**: Total images must match expected count
5. **URL Check**: All URLs from komiku CDN

### Fallback Ordering

If ID-based ordering fails:
1. Try class-based (`klazy ww`)
2. Try position in HTML
3. Compare with expected count from `chapterData`

---

## 🔧 komikindo.ch Specific

### Image Ordering System

komikindo.ch uses **position in HTML** for ordering:

```html
<div class="img-landmine">
    <img src="https://cdn1.example.com/.../abc123.jpeg">
    <img src="https://cdn2.example.com/.../def456.jpeg">
    <img src="https://cdn3.example.com/.../ghi789.jpeg">
</div>
```

### Validation Rules

1. **Position Check**: Images in correct HTML order
2. **No Ads**: Skip blogger.googleusercontent.com images
3. **No Placeholders**: Skip data: URLs
4. **Count Match**: Total images must match expected

### Cloudflare Handling

1. Use `cloudscraper` library
2. Retry on challenge failure
3. Delay between requests (2s)
4. Rotate user-agent if blocked

---

## 📁 Output Format

### CBZ File Structure
```
chapter-001.cbz
├── 001.avif
├── 002.avif
├── 003.avif
└── ...
```

### info.json
```json
{
    "title": "Manga Title",
    "genres": ["Action", "Adventure"],
    "synopsis": "Cerita tentang...",
    "author": "Author Name",
    "type": "Manga",
    "status": "Ongoing",
    "total_chapters": 100
}
```

### cover.avif
- Format: AVIF
- Width: 500px
- Quality: 40

---

## ⚡ Performance Settings

### komiku.org (Fast)
- Workers: 10
- Delay: 0.5s between requests
- Timeout: 30s
- Retry: 3x

### komikindo.ch (Slow - Cloudflare)
- Workers: 5 (limited by Cloudflare)
- Delay: 2s between requests
- Timeout: 60s
- Retry: 3x

---

## 🛡️ Error Handling

### Recovery Mechanisms

1. **Partial Download**: Track completed chapters, resume on restart
2. **Corrupt CBZ**: Validate before marking complete
3. **Missing Images**: Log and continue
4. **Network Issues**: Exponential backoff retry
5. **Disk Issues**: Check space before download

### Logging

```
[2024-01-15 10:30:15] [INFO] Starting download: One Piece
[2024-01-15 10:30:15] [INFO] Chapters: 1126
[2024-01-15 10:30:15] [WORKER-1] Chapter 1100: Downloading
[2024-01-15 10:30:18] [WORKER-1] Chapter 1100: Converting
[2024-01-15 10:30:20] [WORKER-1] Chapter 1100: Packing CBZ
[2024-01-15 10:30:21] [WORKER-1] Chapter 1100: Done (1.2 MB)
```

---

## 🧪 Testing Checklist

### Unit Tests
- [ ] Search function
- [ ] Image ordering (komiku)
- [ ] Image ordering (komikindo)
- [ ] AVIF conversion
- [ ] CBZ creation
- [ ] CBZ validation

### Integration Tests
- [ ] Full download flow
- [ ] Skip existing chapters
- [ ] Resume interrupted download
- [ ] Error recovery

### Edge Cases
- [ ] Empty chapter list
- [ ] Single chapter manga
- [ ] 1000+ chapter manga
- [ ] Special chapter numbers (5.5, 10.1)
- [ ] Very large images
- [ ] Very small images
- [ ] Corrupted source images

---

## 📅 Implementation Order

1. **Phase 1: CLI Interface**
   - [ ] Menu system
   - [ ] Search input
   - [ ] Chapter selection
   - [ ] Progress display

2. **Phase 2: Core Scraper**
   - [ ] Base class
   - [ ] komiku.org scraper
   - [ ] komikindo.ch scraper
   - [ ] Image ordering

3. **Phase 3: Workers**
   - [ ] Parallel execution
   - [ ] Progress tracking
   - [ ] Skip mechanism
   - [ ] Error handling

4. **Phase 4: Conversion**
   - [ ] AVIF conversion
   - [ ] CBZ packing
   - [ ] Validation

5. **Phase 5: Testing**
   - [ ] Unit tests
   - [ ] Integration tests
   - [ ] Edge cases

---

## 🎯 Success Criteria

- [ ] CLI works with `./komik`
- [ ] Search finds manga with typos
- [ ] Download works for both sites
- [ ] Image order is always correct
- [ ] CBZ files are valid
- [ ] Skip existing chapters works
- [ ] Progress display is clear
- [ ] Error recovery works
- [ ] Handles 1000+ chapters
- [ ] Handles different image formats

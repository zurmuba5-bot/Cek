"""
Scraper for softkomik.co (situs Next.js + API api.softkomik.org)

Catatan riset (biar nggak perlu ngulang dari nol):
- Extension Tachiyomi/Mihon "Softkomik" dari keiyoushi/extensions-source
  (src/id/softkomik, disalin ke research/softkomik-extension/) dipakai sebagai
  gambaran alur: cari -> detail -> daftar chapter -> daftar gambar. Tapi
  endpoint di extension itu SUDAH USANG: api.softkomik.org/komik?... sekarang
  404 dan /api/session/aksjkas (versi extension) juga 404.
- Endpoint yang dipakai di file ini diambil dari bundle JS situsnya sendiri
  (chunk reader pages/[title_slug]/chapter/[chapter].js + chunk session) dan
  sudah diverifikasi langsung ke situsnya.

Alur yang dipakai:
  1. Cari judul      : GET {BASE}/api/content/search?name=<q>
  2. Detail manga    : GET {BASE}/{slug}  -> <script id="__NEXT_DATA__"> (SSR)
  3. Daftar chapter  : GET {API}/komik/{slug}/chapter?limit=... (X-Token/X-Sign
                       dari /api/session/aksjkas)
  4. Isi chapter     : GET {BASE}/{slug}/chapter/{nomor} -> __NEXT_DATA__ (ambil
                       _id dokumen chapter), lalu
                       GET {API}/komik/{slug}/chapter/{nomor}/imgs/{_id}
                       (X-Token/X-Sign dari /api/session/chapter/oaisos)
  5. Gambar          : {CDN}/{path}?id=... -- psy1.komik.im atau
                       image.komik.im/softkomik, wajib pakai Referer situsnya

Judul bertag Ecchi/Mature gambarnya dikunci situsnya (balas 401 LOGIN_REQUIRED).
Kalau itu kejadian, scraper menanyakan email+password softkomik.co SEKALI (atau
ambil dari SOFTKOMIK_EMAIL/SOFTKOMIK_PASSWORD), menyimpan cookie sesinya ke file
sc/.softkomik-cookies.json, lalu minta gambarnya pakai X-Content-Token/X-Content-
Sign. Jalan berikutnya cookie dimuat dari file, jadi tidak ditanya lagi. Password
tidak ikut disimpan.

Soal gambar (ini yang bikin hasil unduhan dulu kecil & isinya sama semua):
CDN situs ini memakai "trap image". Permintaan gambar yang tidak lengkap syaratnya
TIDAK dijawab error, tapi dialihkan ke /baca-image.jpeg -- satu gambar promosi
yang ukurannya juga ratusan KB, jadi dulu lolos pengecekan dan semua halaman di
CBZ isinya gambar itu. Supaya dapat gambar asli, tiap URL gambar wajib punya
`?id=<IMAGE_ID_PARAM>` DAN permintaannya wajib membawa header Referer situsnya.
Hasil unduhan sekarang juga diperiksa: kalau yang datang gambar jebakan, host CDN
satunya dicoba, dan kalau dua-duanya menjebak chapternya dilewat (tidak ditulis
ke CBZ) supaya tidak ada halaman palsu yang kesimpan.
"""
import getpass
import json
import os
import re
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote, urlsplit

from .base import BaseScraper, ProgressTracker


# Data SSR Next.js halaman detail/chapter ada di tag ini (bukan di __next_f,
# situs ini masih pakai Pages Router).
NEXT_DATA_RE = re.compile(
    r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', re.S)

# Indeks halaman ikut tertanam di nama file gambarnya: "softkomik-7.webp"
# (chapter lama) atau "softkomik-7-1722735943699.webp" (upload baru yang nambah
# timestamp). Ini pengganti atribut `id` yang dipakai komiku/komikindo buat
# memastikan urutan gambar sama dengan web-nya.
IMAGE_INDEX_RE = re.compile(r'-(\d+)(?:-\d+)?\.[A-Za-z0-9]+$')


class SoftkomikScraper(BaseScraper):
    """Scraper for softkomik.co"""
    
    BASE_URL = "https://softkomik.co"
    API_URL = "https://api.softkomik.org"
    COVER_URL = "https://cover.softdevices.my.id/softkomik-cover"
    CDN_PRIMARY = "https://psy1.komik.im"
    CDN_SECONDARY = "https://image.komik.im/softkomik"
    SEARCH_LIMIT = 20
    # Beban kerja: MAX_WORKERS x INNER_DOWNLOAD_WORKERS request gambar jalan bareng.
    # Diukur di mesin 2 core (4 chapter pipeline penuh): 5x3 -> 70.5s,
    # 5x10 -> 59.0s, 10x8 -> ~55s, 24x10 -> 58.5s (nggak nambah lagi karena
    # mentok CPU: CONVERT_CONCURRENCY=2). Jadi 10x8 itu titik manisnya, dan
    # sengaja nggak digas mentok biar masih ada headroom ke situsnya.
    # Dua nilai ini menimpa warisan base.py HANYA untuk provider ini.
    MAX_WORKERS = 10
    INNER_DOWNLOAD_WORKERS = 8
    
    # Situs ngasih 2 jenis token sesi: buat daftar chapter dan buat gambar.
    SESSION_LIST = "list"
    SESSION_CHAPTER = "chapter"
    SESSION_ROUTES = {
        SESSION_LIST: "/api/session/aksjkas",
        SESSION_CHAPTER: "/api/session/chapter/oaisos",
    }
    API_RETRIES = 2
    
    # --- token sesi ---
    # Token situs ini berlaku ~2 jam, sedangkan unduhan satu judul panjang bisa
    # lewat dari itu. Jadi token diperbarui DULUAN (sebelum benar-benar mati)
    # saat lagi nggak ada yang butuh -- bukan pas semua worker ngebutuhin
    # barengan, karena hujan permintaan beruntun ke endpoint sesi pernah dibalas
    # 404 oleh situsnya.
    TOKEN_REFRESH_MARGIN_MS = 5 * 60 * 1000
    TOKEN_RETRY_DELAYS = (1, 2, 4)   # jeda antar percobaan saat ambil token gagal
    TOKEN_COOLDOWN = 5.0             # worker lain tunggu dulu setelah ada kegagalan
    # --- pemulihan sesi / koneksi ---
    # Sesi di sini bisa basi karena hal yang di luar kendali kita: cookie situs
    # kedaluwarsa, dan token sesi diikat ke IP + User-Agent -- sedangkan IP
    # publik mesin ini ganti kalau codespace/containernya di-restart atau
    # jaringannya pindah. Jadi tiap permintaan yang gagal (bukan 404) dicoba
    # ulang sekali dengan sesi yang dibangun ulang, bukan langsung menyerah.
    SESSION_RETRY_DELAYS = (1, 3)
    # --- chapter gagal ---
    # Kalau ada chapter gagal, dicoba SEKALI lagi di akhir (bukan diulang terus).
    RETRY_FAILED_DELAY = 10.0
    # Kalau yang gagal hampir semua, berarti situsnya yang bermasalah, bukan
    # chapter-nya -> percobaan ulang dilewat biar nggak makin menghujani.
    RETRY_FAILED_MAX_RATIO = 0.8
    
    # --- login (komik bertag Ecchi/Mature dikunci situsnya) ---
    # Situs nolak ngasih gambar dengan 401 LOGIN_REQUIRED. Kalau sudah login,
    # server ngasih token konten tambahan (X-Content-Token) yang dipakai buat
    # minta gambarnya. Cookie hasil login disimpan di file supaya jalan
    # berikutnya nggak perlu nanya lagi. Password TIDAK ikut disimpan.
    LOGIN_URL = "/api/login"
    LOGIN_REQUIRED_CODE = "LOGIN_REQUIRED"
    COOKIE_FILE = Path(__file__).resolve().parent.parent / ".softkomik-cookies.json"
    LOGIN_EMAIL_ENV = "SOFTKOMIK_EMAIL"
    LOGIN_PASSWORD_ENV = "SOFTKOMIK_PASSWORD"
    
    # --- permintaan gambar ---
    # Situsnya memakai "trap image": permintaan gambar yang tidak memenuhi
    # syaratnya TIDAK dijawab error, tapi dialihkan ke /baca-image.jpeg -- satu
    # gambar promosi berukuran besar juga, jadi gampang lolos kalau tidak dicek
    # dan hasilnya semua halaman jadi gambar yang sama. Supaya tidak kena trap,
    # tiap URL gambar wajib pakai `?id=` dan permintaannya wajib membawa Referer
    # dari situsnya. Dua-duanya hasil perbandingan request: tanpa salah satu,
    # yang datang selalu gambar jebakan itu.
    # Nilai `id` ditanam di bundle JS situs sebagai String("...").trim() dan
    # sesekali diganti situsnya -- kalau gambar tiba-tiba jadi jebakan semua,
    # ini yang perlu dicek ulang.
    IMAGE_ID_PARAM = "T4Kmwztku"
    TRAP_IMAGE_PATH = "/baca-image.jpeg"
    IMAGE_HEADERS = {
        'Referer': BASE_URL + '/',
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
    }
    
    def __init__(self, download_dir: str = "downloads"):
        super().__init__(download_dir)
        # Cache token: isinya terikat IP + User-Agent dan punya `ex` sendiri,
        # jadi nggak perlu minta baru tiap chapter.
        self._tokens: Dict[str, Dict[str, Any]] = {}
        self._token_lock = threading.Lock()
        self._last_token_fail = 0.0
        self._warmed = False
        # Login: cuma satu worker yang boleh nanya, sisanya nunggu.
        self._login_lock = threading.Lock()
        self._sudah_tanya = False
        self._cookies_dimuat = False
        self._login_ok = False
        self._perlu_login: set = set()   # URL chapter yang dikunci (jangan dicoba ulang)
        self._api_locked: set = set()    # path API yang ditolak karena belum login
        self._kunci_dilaporkan = False   # pesan "dikunci" cukup sekali, bukan tiap chapter
        self._jebakan_dilaporkan = False  # pesan "gambar jebakan" cukup sekali
        self._gagal_dilaporkan = False   # pesan "gagal konek" cukup sekali
        self._alasan_terakhir = ''       # kenapa permintaan API terakhir gagal
        self._muat_cookies()             # sesi login sisa jalan sebelumnya
    
    # ---------------------------------------------------------------- session
    def _warm_up(self) -> None:
        """Kunjungi beranda sekali biar cookie Cloudflare-nya kebentuk dulu
        (permintaan token sesi ini yang paling sering ditolak kalau kedinginan)."""
        if self._warmed:
            return
        self._warmed = True
        try:
            self.session.get(self.BASE_URL, timeout=30)
        except Exception:
            pass
    
    def _pulihkan_sesi(self) -> None:
        """Bangun ulang sesi setelah ada permintaan yang gagal.

        Beranda dikunjungi lagi supaya cookie situs (termasuk cookie Cloudflare)
        dibentuk ulang, token dibuang supaya diambil lagi dengan IP dan
        User-Agent yang sekarang dipakai, dan penolakan-penolakan lama
        dilupakan supaya judul yang tadi dilewat masih bisa dicoba.
        """
        self._warmed = False
        self._warm_up()
        with self._token_lock:
            self._tokens.clear()
            self._last_token_fail = 0.0
        # Tanda "dikunci"/"butuh login" bisa jadi cuma efek sesi basi, jadi
        # jangan dipakai buat menolak percobaan setelah sesi dibangun ulang.
        self._api_locked.clear()
        self._perlu_login.clear()
    
    def _lapor_gagal(self, alasan: str) -> None:
        """Sekali saja per proses: jelaskan bahwa yang gagal itu aksesnya.

        Tanpa ini, kegagalan koneksi/sesi tampil sebagai "tidak ditemukan",
        yang gampang dibaca sebagai "judulnya tidak ada di situsnya".
        """
        if self._gagal_dilaporkan:
            return
        self._gagal_dilaporkan = True
        print(f"\n  softkomik tidak bisa diakses  {alasan}")
        print("  sesi sudah dicoba dibangun ulang otomatis; kalau ini "
              "muncul terus, berarti koneksi ke situsnya memang.putus, "
              "bukan masalah judulnya.")
    
    def _ambil(self, url: str, *, params: Optional[Dict[str, Any]] = None,
               headers: Optional[Dict[str, str]] = None, timeout: int = 60,
               jenis: str = 'teks') -> Tuple[Any, Optional[str]]:
        """GET dengan pemulihan sesi otomatis. Kembalikan (isi, alasan).

        `isi` None berarti gagal dan `alasan` menjelaskan penyebabnya dalam
        bahasa manusia. Percobaan pertama yang gagal karena sesi/koneksi basi
        (koneksi putus, 403, 429, 5xx) langsung diulang setelah sesi dibangun
        ulang -- jadi pindah codespace atau IP publik berubah tidak perlu
        ditangani manual.
        """
        host = urlsplit(url).netloc or url
        alasan = f'{host}: tidak ada jawaban'
        for percobaan in range(len(self.SESSION_RETRY_DELAYS) + 1):
            if percobaan:
                time.sleep(self.SESSION_RETRY_DELAYS[percobaan - 1])
                self._pulihkan_sesi()
            try:
                resp = self.session.get(url, params=params, headers=headers,
                                        timeout=timeout)
            except Exception as e:
                alasan = f'{host}: gagal konek ({type(e).__name__}: {e})'
                continue
            
            status = int(getattr(resp, 'status_code', 200) or 0)
            if status != 200:
                alasan = f'{host}: balas HTTP {status}'
                # 403/408/429/5xx biasanya cuma gejala sesi basi atau situsnya
                # lagi menahan permintaan -> masih layak dicoba lagi.
                if status in (403, 408, 429) or status >= 500:
                    continue
                return None, alasan
            
            if jenis == 'json':
                try:
                    return resp.json(), None
                except Exception:
                    alasan = f'{host}: balas bukan JSON'
                    continue
            teks = resp.text or ''
            if not teks:
                alasan = f'{host}: balas halaman kosong'
                continue
            return teks, None
        return None, alasan
    
    def _fetch_token(self, kind: str) -> Optional[Dict[str, Any]]:
        """Ambil token sesi dari situs.
        `sign` dipotong di '|oiq&' -- ekor itu sampah yang bikin permintaan
        ditolak kalau ikut dikirim (sama seperti yang dipakai bundle JS situs).
        """
        route = self.SESSION_ROUTES.get(kind)
        if not route:
            return None
        try:
            resp = self.session.get(self.BASE_URL + route, timeout=30, headers={
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': self.BASE_URL + '/',
            })
            resp.raise_for_status()
            data = resp.json() or {}
        except Exception:
            return None
        
        token = data.get('token')
        sign = (data.get('sign') or '').split('|oiq&')[0]
        if not token or not sign:
            return None
        entry = {'token': token, 'sign': sign,
                 'expires': int(data.get('ex') or 0),   # dalam milidetik
                 'issued': int(time.time() * 1000)}
        # Kalau sesinya milik akun yang sudah login, jawaban yang sama juga
        # membawa `contentAccess` (pasangan token+sign kedua). Itu kunci buka
        # gambar judul kategori SENSITIVE -- dikirim sebagai X-Content-Token/
        # X-Content-Sign, persis seperti bundle JS situsnya.
        access = data.get('contentAccess') or {}
        if isinstance(access, dict) and access.get('token') and access.get('sign'):
            entry['contentAccess'] = {'token': access['token'], 'sign': access['sign']}
        return entry
    
    def _token_masih_pakai(self, entry: Optional[Dict[str, Any]]) -> bool:
        """Apakah token ini masih layak dipakai (bukan cuma belum mati)?
        
        Token yang mendekati kadaluarsa dianggap basi, supaya pembaruannya
        kejadian di saat sepi -- bukan pas di tengah chapter. Ambangnya adaptif:
        seperlima masa berlaku, dibatasi 5 menit dan minimal 30 detik. Jadi kalau
        situsnya suatu saat memperpendek masa token, kita nggak keburu mati.
        """
        if not entry:
            return False
        expires = entry.get('expires', 0)
        sisa = expires - time.time() * 1000
        if sisa <= 0:
            return False
        hidup = expires - entry.get('issued', expires)
        ambang = min(self.TOKEN_REFRESH_MARGIN_MS, max(30_000, hidup // 5))
        return sisa > ambang
    
    def _get_token(self, kind: str, force: bool = False) -> Optional[Dict[str, Any]]:
        """Token yang masih layak dari cache; kalau tidak, ambil baru.
        
        Pengambilan dikunci supaya cuma satu worker yang menembak situsnya, dan
        dicek dua kali (sebelum dan sesudah masuk kunci) supaya worker yang
        ngantre nggak ikut minta token yang barusan diperbarui worker lain.
        """
        if not force:
            with self._token_lock:
                cached = self._tokens.get(kind)
            if self._token_masih_pakai(cached):
                return cached
        
        with self._token_lock:
            # Cek ulang di dalam kunci: siapa tau worker lain barusan sudah
            # memperbaruinya, jadi nggak perlu nembak lagi.
            if not force:
                cached = self._tokens.get(kind)
                if self._token_masih_pakai(cached):
                    return cached
            
            # Rem: kalau barusan ada yang gagal, jangan ikut menembak dulu.
            # Balikin token lama (sering masih diterima server) supaya permintaan
            # chapter tetap jalan, dan situsnya nggak dihujani permintaan token
            # oleh semua worker sekaligus. Kalau di-nunggu lalu diulang, yang
            # kejadian malah kebalikannya: tiap worker ikut mencoba 4 kali.
            if self._last_token_fail and (
                    time.time() - self._last_token_fail) < self.TOKEN_COOLDOWN:
                return self._tokens.get(kind)
            
            entry = None
            for percobaan in range(len(self.TOKEN_RETRY_DELAYS) + 1):
                if percobaan:
                    time.sleep(self.TOKEN_RETRY_DELAYS[percobaan - 1])
                entry = self._fetch_token(kind)
                if entry:
                    break
            
            if entry:
                self._tokens[kind] = entry
                self._last_token_fail = 0.0
                return entry
            
            # Semua percobaan gagal. Daripada langsung balikin None, pakai token
            # lama yang masih tersimpan -- masa berlakunya di sisi kita memang
            # sudah lewat, tapi sering masih diterima server. Ini bikin chapter
            # tetap punya kesempatan jalan, bukan langsung menyerah.
            self._last_token_fail = time.time()
            return self._tokens.get(kind)
    
    def _api_get(self, kind: str, path: str,
                 params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """GET ke api.softkomik.org pakai header X-Token/X-Sign.

        Token basi (atau ditolak server) -> refresh sekali lalu coba lagi, bukan
        langsung nyerah. Kalau jawabannya 401 LOGIN_REQUIRED (gambar judul
        kategori SENSITIVE), sesi login dibangun dulu, baru permintaannya
        diulang sekali dengan X-Content-Token/X-Content-Sign.
        """
        url = f"{self.API_URL}{path}"
        percobaan = 0
        login_dicoba = False
        while percobaan <= self.API_RETRIES:
            percobaan += 1
            token = self._get_token(kind, force=percobaan > 1)
            if not token:
                self._alasan_terakhir = ('token sesi situs tidak bisa diambil '
                                         '(endpoint /api/session diblokir?')
                return None
            try:
                resp = self.session.get(url, params=params, timeout=60,
                                        headers=self._headers_sesi(token))
                if resp.status_code == 200:
                    return resp.json()
                if resp.status_code == 401 and self._login_diminta(resp):
                    if login_dicoba:
                        # Sudah login (dengan X-Content-*) tapi tetap ditolak ->
                        # bukan soal login lagi, percuma diulang terus.
                        self._api_locked.add(path)
                        return None
                    login_dicoba = True
                    # 401 padahal kita merasa sudah login -> cookie yang dipegang
                    # sudah tidak diakui (biasanya kedaluwarsa). Buang dulu.
                    if self._login_ok:
                        self._lupakan_cookies()
                    if not self._coba_login():
                        self._api_locked.add(path)
                        return None
                    # Token ini diambil sebelum login, jadi belum membawa
                    # X-Content-*. Diambil ulang tanpa makan jatah percobaan,
                    # biar permintaannya benar-benar diulang dengan token baru.
                    with self._token_lock:
                        self._tokens.pop(kind, None)
                    continue
            except Exception as e:
                self._alasan_terakhir = (f"gagal konek ke {urlsplit(url).netloc} "
                                         f"({type(e).__name__}: {e})")
                # Koneksi atau sesi berubah: bangun ulang (cookie situs baru +
                # token dibuang) supaya percobaan berikutnya pakai sesi yang
                # sekarang, bukan token lama yang terikat IP sebelumnya.
                self._pulihkan_sesi()
            else:
                self._alasan_terakhir = (f"{urlsplit(url).netloc} balas HTTP "
                                         f"{getattr(resp, 'status_code', '?')}")
            if percobaan <= self.API_RETRIES:
                time.sleep(self.RETRY_DELAY)
        return None
    
    # ------------------------------------------------------------------ login
    def _headers_sesi(self, token: Dict[str, Any]) -> Dict[str, str]:
        """Header buat api.softkomik.org.

        X-Token/X-Sign dipakai semua sesi; X-Content-Token/X-Content-Sign hanya
        ada kalau sesinya milik akun yang login, dan itu yang diminta server
        buat gambar judul kategori SENSITIVE.
        """
        headers = {
            'Accept': 'application/json',
            'X-Token': token.get('token', ''),
            'X-Sign': token.get('sign', ''),
        }
        access = token.get('contentAccess') or {}
        if isinstance(access, dict) and access.get('token') and access.get('sign'):
            headers['X-Content-Token'] = access['token']
            headers['X-Content-Sign'] = access['sign']
        return headers
    
    @classmethod
    def _login_diminta(cls, resp: Any) -> bool:
        """Apakah balasan 401 ini artinya 'login dulu'."""
        if getattr(resp, 'status_code', 0) != 401:
            return False
        try:
            data = resp.json() or {}
        except Exception:
            data = {}
        if str(data.get('code') or '').upper() == cls.LOGIN_REQUIRED_CODE:
            return True
        return 'login' in str(data.get('message') or '').lower()
    
    @staticmethod
    def _interaktif() -> bool:
        """Aman nanya ke terminal user? (bukan cron/pipe/file redirection)."""
        try:
            return sys.stdin.isatty() and sys.stdout.isatty()
        except Exception:
            return False
    
    @classmethod
    def _judul_terkunci(cls, data: Dict[str, Any]) -> bool:
        """Apakah judul ini termasuk yang gambarnya dikunci situs.

        Patokannya sengaja disamakan dengan yang dipakai situsnya sendiri buat
        menampilkan gerbang peringatan: `GenrePeringatan` terisi, atau
        `contentRating` bukan 'normal'. BUKAN dari nama genre -- ada judul
        bergenre "Mature" tapi contentRating-nya 'normal' dan gambarnya tetap
        terbuka tanpa login.
        """
        if data.get('GenrePeringatan'):
            return True
        rating = str(data.get('contentRating') or '').strip().lower()
        return bool(rating) and rating != 'normal'
    
    def _sudah_login(self) -> bool:
        return self._login_ok
    
    def _muat_cookies(self) -> None:
        """Muat cookie login yang tersimpan (kalau ada), cukup sekali."""
        if self._cookies_dimuat:
            return
        self._cookies_dimuat = True
        try:
            if not self.COOKIE_FILE.exists():
                return
            data = json.loads(self.COOKIE_FILE.read_text() or '{}')
        except Exception:
            return
        cookies = data.get('cookies') if isinstance(data, dict) else None
        if not isinstance(cookies, dict) or not cookies:
            return
        for name, value in cookies.items():
            try:
                self.session.cookies.set(str(name), str(value), domain='softkomik.co')
            except Exception:
                pass
        self._login_ok = True
    
    def _simpan_cookies(self) -> None:
        """Simpan cookie sesi login (password tidak ikut)."""
        cookies = {c.name: c.value for c in self.session.cookies}
        if not cookies:
            return
        try:
            self.COOKIE_FILE.parent.mkdir(parents=True, exist_ok=True)
            self.COOKIE_FILE.write_text(json.dumps({
                'domain': 'softkomik.co',
                'saved_at': int(time.time()),
                'cookies': cookies,
            }, indent=2))
            os.chmod(self.COOKIE_FILE, 0o600)
        except Exception as e:
            print(f"  login  cookie gagal disimpan  {e}")
    
    def _lupakan_cookies(self) -> None:
        """Cookie yang dipegang ternyata ditolak server -> buang, biar bisa
        ditanyakan ulang kalau memang sudah kedaluwarsa."""
        self._login_ok = False
        self._sudah_tanya = False
        try:
            self.session.cookies.clear()
        except Exception:
            pass
        try:
            self.COOKIE_FILE.unlink(missing_ok=True)
        except Exception:
            pass
    
    def _baca_kredensial(self) -> Tuple[str, str]:
        """Email+password dari variabel lingkungan, atau tanya ke terminal user."""
        email = (os.environ.get(self.LOGIN_EMAIL_ENV) or '').strip()
        password = os.environ.get(self.LOGIN_PASSWORD_ENV) or ''
        if email and password:
            print(f"  login  pakai akun dari {self.LOGIN_EMAIL_ENV}")
            return email, password
        if not self._interaktif():
            print(f"  login  tidak ada terminal buat bertanya. Set "
                  f"{self.LOGIN_EMAIL_ENV} dan {self.LOGIN_PASSWORD_ENV}, "
                  f"lalu jalankan ulang perintahnya")
            return '', ''
        print("  masukkan akun softkomik.co sekali saja, cookie hasilnya disimpan")
        print("  jadi jalan berikutnya tidak ditanya lagi")
        print("  password hanya dipakai untuk login, tidak disimpan")
        try:
            email = input("  Email    : ").strip()
            password = getpass.getpass("  Password : ")
        except (EOFError, KeyboardInterrupt):
            print()
            return '', ''
        if not email or not password:
            print("  login  dilewat, email atau password kosong")
            return '', ''
        return email, password
    
    def _login(self, email: str, password: str) -> bool:
        """POST {BASE}/api/login, lalu simpan cookie sesinya."""
        self._warm_up()
        try:
            resp = self.session.post(
                f"{self.BASE_URL}{self.LOGIN_URL}",
                json={'email': email, 'password': password},
                headers={'Content-Type': 'application/json',
                         'Accept': 'application/json'},
                timeout=30)
        except Exception as e:
            print(f"  login  gagal konek  {e}")
            return False
        
        if resp.status_code != 200:
            try:
                pesan = (resp.json() or {}).get('message') or resp.text
            except Exception:
                pesan = resp.text
            print(f"  login  ditolak, kode {resp.status_code}  {str(pesan).strip()[:200]}")
            return False
        
        try:
            ok = bool((resp.json() or {}).get('ok'))
        except Exception:
            ok = False
        if not ok:
            print("  login  situs tidak menjawab ok true")
            return False
        if not self.session.cookies:
            print("  login  situs tidak mengirim cookie sesi")
            return False
        
        self._simpan_cookies()
        # Token yang sudah dipegang diambil SEBELUM login, jadi belum membawa
        # X-Content-*; buang supaya diambil ulang sebagai sesi yang sudah login.
        with self._token_lock:
            self._tokens.clear()
        print("  login berhasil, cookie disimpan, jalan berikutnya tidak ditanya lagi")
        return True
    
    def _coba_login(self) -> bool:
        """Pastikan ada sesi login.

        User ditanya sekali per proses -- judul dengan ratusan chapter terkunci
        jangan sampai memunculkan ratusan pertanyaan yang sama.
        """
        with self._login_lock:
            if self._login_ok:
                return True
            if self._sudah_tanya:
                return False
            self._sudah_tanya = True
            email, password = self._baca_kredensial()
            if not email or not password:
                return False
            if self._login(email, password):
                self._login_ok = True
                return True
            return False
    
    def _lapor_kunci(self, url: str, slug: str, chapter: str) -> None:
        """Tandai + jelaskan sekali bahwa chapter ini ditahan situs karena login.

        Tanpa ini, chapter yang dikunci cuma muncul sebagai "No images found"
        dari base.py, yang gampang disalahartikan sebagai chapter kosong.
        """
        self._perlu_login.add(url)
        if self._kunci_dilaporkan:
            return
        self._kunci_dilaporkan = True
        print(f"\n  {slug}  gambar chapter ini ditahan situs karena belum login, "
              f"chapter dilewat bukan karena gambarnya kosong")
    
    # ------------------------------------------------------------------ utils
    @staticmethod
    def _next_data(html: str) -> Dict[str, Any]:
        """Ambil blok __NEXT_DATA__ (JSON SSR) dari HTML."""
        match = NEXT_DATA_RE.search(html or '')
        if not match:
            return {}
        try:
            return json.loads(match.group(1))
        except Exception:
            return {}
    
    def _ambil_props(self, url: str) -> Tuple[Dict[str, Any], Optional[str]]:
        """pageProps sebuah halaman + alasan kalau tidak bisa dibaca."""
        html, alasan = self._ambil(url)
        if html is None:
            return {}, alasan
        data = self._next_data(html)
        props = (data.get('props') or {}).get('pageProps') or {}
        if not props:
            host = urlsplit(url).netloc or url
            return {}, (f'{host}: halaman tidak berisi data '
                        f'(kemungkinan halaman tantangan Cloudflare)')
        return props, None
    
    def _page_props(self, url: str) -> Dict[str, Any]:
        """pageProps dari HTML SSR sebuah halaman."""
        return self._ambil_props(url)[0]
    
    @staticmethod
    def _slug_from_url(url: str) -> str:
        """{BASE}/{slug} -> slug (segmen path pertama)."""
        path = urlsplit(url or '').path
        parts = [p for p in path.split('/') if p]
        return parts[0] if parts else ''
    
    @staticmethod
    def _parse_chapter_url(url: str) -> Tuple[str, str]:
        """{BASE}/{slug}/chapter/{nomor} -> (slug, nomor)."""
        parts = [p for p in urlsplit(url or '').path.split('/') if p]
        if 'chapter' not in parts:
            return '', ''
        idx = parts.index('chapter')
        if idx < 1 or len(parts) <= idx + 1:
            return '', ''
        return parts[idx - 1], parts[idx + 1]
    
    @staticmethod
    def _chapter_label(num: str) -> str:
        """'001' -> '1' buat tampilan; nomor desimal ('1.5') tetap utuh."""
        head, _, tail = (num or '').partition('.')
        if head.isdigit():
            head = str(int(head))
        return f"{head}.{tail}" if tail else head
    
    def _cover_url(self, gambar: str) -> str:
        """Cover asli ada di host cover terpisah, path-nya = field `gambar`."""
        gambar = (gambar or '').lstrip('/')
        return f"{self.COVER_URL}/{gambar}" if gambar else ''
    
    @staticmethod
    def _check_image_order(images: List[str]) -> Tuple[List[str], str]:
        """Cek urutan gambar lewat nomor halaman yang tertanam di nama file.

        Ini pengganti atribut `id` di komiku/komikindo. Hasil pengamatan
        (12 chapter, 3 judul, semuanya cocok 100%) polanya:
          - halaman isi bernomor 0, 1, 2, ... tanpa bolong dan tanpa dobel
          - boleh ditutup satu gambar tambahan (banner promosi) yang nomornya
            keluar dari urutan itu, dan posisinya selalu paling akhir

        Kembalikan (daftar_gambar, status). Urutan array dari server tetap
        dianggap yang paling benar -- itu urutan yang dirender web-nya -- jadi
        daftar cuma diurut ulang kalau nomornya lengkap tapi jelas ketuker
        (bukan menebak), dan TIDAK diubah kalau polanya aneh tapi nggak jelas
        (cuma ditandai biar kelihatan).
        """
        if not images:
            return images, 'KOSONG'

        numbers = []
        for url in images:
            match = IMAGE_INDEX_RE.search(url or '')
            numbers.append(int(match.group(1)) if match else None)

        # Format nama file berubah (nggak ada nomornya) -> jangan diapa-apakan.
        if any(n is None for n in numbers):
            return images, 'TANPA NOMOR'

        head, tail = numbers[:-1], numbers[-1]
        expected = list(range(len(head)))

        # Kasus normal: 0..N-2 berurutan (gambar penutup boleh ada, boleh tidak).
        # Nomor halaman di softkomik bisa 0-based ATAU 1-based tergantung
        # judulnya, jadi dua basis itu sama-sama dianggap normal. Cuma cek "OK"
        # ini yang dilebar -- cabang urut-ulang di bawah sengaja nggak diubah,
        # jadi chapter yang nomornya 1-based tetap pakai urutan server apa adanya.
        if head == expected or head == list(range(1, len(head) + 1)):
            return images, 'OK'

        # Nomornya lengkap tapi posisinya ketuker -> urut ulang; gambar penutup
        # tetap diletakkan di akhir supaya nggak nyempil di tengah.
        if sorted(head) == expected and tail not in expected:
            urut = sorted(range(len(head)), key=lambda i: numbers[i])
            return [images[i] for i in urut] + [images[-1]], 'DIURUTKAN'

        # Ada bolong/dobel yang nggak bisa dijelaskan -> tetap pakai urutan
        # web-nya apa adanya, tapi tandai biar ketahuan pas download.
        return images, f'PERLU DICEK (nomor: {numbers[:10]}...)'

    @staticmethod
    def _cdn_base(doc: Dict[str, Any]) -> str:
        """Host CDN gambar, aturannya sama seperti bundle JS situs:
        backBS3 -> psy1, storageInter2 -> image.komik.im, selain itu psy1.
        Dua host itu menyajikan file yang sama, jadi aman dipilih salah satu.
        """
        if doc.get('storageInter2') and not doc.get('backBS3'):
            return SoftkomikScraper.CDN_SECONDARY
        return SoftkomikScraper.CDN_PRIMARY
    
    # ------------------------------------------------------------------ API
    def search(self, query: str) -> List[Dict[str, Any]]:
        """Cari judul lewat API internal situs.
        Hasilnya cuma title + slug + contentRating (nggak ada cover/tipe),
        jadi field lain dikosongkan -- CLI nampilinnya sebagai tabel biasa."""
        q = (query or '').strip()
        if not q:
            return []
        
        self._warm_up()
        data, alasan = self._ambil(f"{self.BASE_URL}/api/content/search",
                                   params={'name': q},
                                   headers={'Accept': 'application/json'},
                                   timeout=30,
                                   jenis='json')
        if data is None:
            self._lapor_gagal(alasan or 'permintaan pencarian gagal')
            return []
        rows = (data or {}).get('data') or []
        
        results = []
        # Semua baris dibaca dulu (bukan dipotong SEARCH_LIMIT di awal) supaya
        # judul yang persis diketik user tidak keburu terbuang sebelum diurutkan.
        for row in rows:
            slug = (row.get('title_slug') or '').strip()
            if not slug:
                continue
            results.append({
                'title': row.get('title') or slug,
                'url': f"{self.BASE_URL}/{slug}",
                'slug': slug,
                'type': '',
                'cover_url': '',
                'content_rating': row.get('contentRating') or '',
            })
        
        # Urut ulang: judul yang paling cocok dengan query di atas, baru dipotong
        # ke SEARCH_LIMIT (lihat BaseScraper._urut_hasil_pencarian).
        results = self._urut_hasil_pencarian(query, results)
        return results[:self.SEARCH_LIMIT]
    
    def _chapter_entries(self, slug: str) -> List[Dict[str, Any]]:
        """Daftar chapter dari API (urut terbaru -> terlama).
        Nomor chapter sudah dalam bentuk siap-URL ('001', '626'), jadi dipakai
        apa adanya supaya cocok dengan path halaman chapter-nya.

        Nomor yang sama bisa dikirim situsnya LEBIH DARI SATU KALI: judul
        from-the-grave-and-back-bahasa-indonesia misalnya mengirim 006, 007,
        008, 018, 021, dan 022 masing-masing 2-19 baris dengan nomor dan URL
        yang identik. Kalau baris begitu diteruskan apa adanya, chapter yang
        sama masuk antrean beberapa kali dan diunduh berulang untuk CBZ yang
        sama (itu sebabnya terlihat "chapter double"). Jadi di sini didedupe
        per nomor; kemunculan pertama dari server yang dipakai, urutannya tetap
        urutan situs (terbaru -> terlama).
        """
        data = self._api_get(self.SESSION_LIST,
                             f"/komik/{quote(slug)}/chapter",
                             params={'limit': 9999999})
        rows = (data or {}).get('chapter') or []
        
        chapters = []
        dilihat = set()
        for row in rows:
            num = str(row.get('chapter') or '').strip()
            if not num or num in dilihat:
                continue
            dilihat.add(num)
            chapters.append({
                'title': f"Chapter {self._chapter_label(num)}",
                'url': f"{self.BASE_URL}/{slug}/chapter/{num}",
                'number': num,
            })
        return chapters
    
    def get_manga_detail(self, url: str) -> Optional[Dict[str, Any]]:
        """Detail manga dari data SSR halaman {BASE}/{slug} + daftar chapter."""
        slug = self._slug_from_url(url)
        if not slug:
            return None
        
        props, alasan = self._ambil_props(f"{self.BASE_URL}/{slug}")
        data = props.get('data') or {}
        if not data:
            self._lapor_gagal(alasan or f'halaman {slug} tidak berisi data judul')
            return None
        
        title = data.get('title') or slug
        cover_url = self._cover_url(data.get('gambar'))
        
        # Judul kategori SENSITIVE gambarnya cuma diberikan ke sesi yang login.
        # Diketahui dari halaman detail (sebelum ngunduh), jadi bisa ditanya
        # sekali di awal -- bukan gagal satu-satu di tengah unduhan.
        if self._judul_terkunci(data) and not self._sudah_login():
            print(f"\n  {title}  kategori sensitif, gambarnya butuh login")
            if not self._coba_login():
                print("  tanpa login, gambar judul ini ditolak situsnya "
                      "dan semua chapter dilewat")
        
        chapters = self._chapter_entries(slug)
        if not chapters:
            self._lapor_gagal(self._alasan_terakhir or
                              f'daftar chapter {slug} tidak terbaca')
        rating = data.get('rating') or {}
        
        info = {
            'title': title,
            'alternative_title': data.get('title_alt') or '',
            'author': data.get('author') or '',
            'artist': data.get('author') or '',
            'type': data.get('type') or '',
            'status': data.get('status') or '',
            'year': data.get('tahun') or '',
            'rating': rating.get('value') if isinstance(rating, dict) else '',
            'total_chapters': len(chapters),
        }
        
        return {
            'title': title,
            'cover_url': cover_url,
            'cover_candidates': [cover_url] if cover_url else [],
            'genres': data.get('Genre') or [],
            'synopsis': (data.get('sinopsis') or '').strip(),
            'info': info,
            'total_chapters': len(chapters),
            'source': 'softkomik.co',
            'source_url': f"{self.BASE_URL}/{slug}",
            'chapters': chapters,
        }
    
    def get_chapter_images_ordered(self, url: str) -> List[Dict[str, Any]]:
        """Daftar gambar 1 chapter, urut halaman.
        
        Urutannya datang langsung dari API (`imageSrc` sudah urut 0..N), jadi
        nggak perlu nebak dari atribut HTML seperti di situs lain. Yang perlu
        dulu diambil adalah `_id` dokumen chapter dari halaman chapter-nya.
        """
        slug, chapter = self._parse_chapter_url(url)
        if not slug or not chapter:
            return []
        
        props, alasan = self._ambil_props(
            f"{self.BASE_URL}/{slug}/chapter/{chapter}")
        chapter_page = props.get('data') or {}
        doc = chapter_page.get('data') or {}
        doc_id = doc.get('_id')
        if not doc_id:
            self._lapor_gagal(alasan or
                              f'halaman chapter {slug}/{chapter} tidak terbaca')
            return []
        
        # Nomor chapter versi halaman ini ('001'/'100') yang dipakai ke API gambar
        chapter_num = str(chapter_page.get('chapter') or chapter)
        img_path = (f"/komik/{quote(slug)}/chapter/{quote(chapter_num)}"
                    f"/imgs/{quote(str(doc_id))}")
        payload = self._api_get(self.SESSION_CHAPTER, img_path)
        
        images = (payload or {}).get('imageSrc') or []
        if not images:
            # Ditahan karena belum login, bukan karena chapter-nya kosong.
            if img_path in self._api_locked:
                self._lapor_kunci(url, slug, chapter_num)
            elif payload is None:
                self._lapor_gagal(self._alasan_terakhir or
                                  f'daftar gambar {slug}/{chapter} tidak terbaca')
            return []

        # Validasi urutan (gaya komiku/komikindo). `order` tetap 1..N sesuai
        # urutan baca -- jadi penamaan di dalam CBZ (001.avif, 002.avif, ...)
        # yang dikerjakan base.py nggak berubah sama sekali.
        images, status = self._check_image_order(images)
        if status.startswith('PERLU DICEK'):
            print(f"\n  {slug} chapter {chapter_num}  urutan gambar di luar pola, "
                  f"dipakai apa adanya, {status}")
        elif status == 'DIURUTKAN':
            print(f"\n  {slug} chapter {chapter_num}  nomor gambar ketuker di daftar "
                  f"server, sudah diurut ulang pakai nomornya")

        # `?id=` ditambahkan DI SINI (setelah pengecekan urutan di atas) -- kalau
        # ikut masuk ke situ, akhiran URL-nya jadi bukan lagi nama file `.webp`
        # dan pengecekan nomor halaman nggak bisa jalan.
        base = self._cdn_base(doc)
        return [
            {'order': i,
             'url': f"{base}/{src.lstrip('/')}?id={self.IMAGE_ID_PARAM}"}
            for i, src in enumerate(images, 1)
        ]
    
    def get_chapter_images(self, url: str) -> List[str]:
        """Get all image URLs for a chapter (backward compatible)"""
        ordered = self.get_chapter_images_ordered(url)
        return [img['url'] for img in ordered]
    
    def _kandidat_gambar(self, url: str) -> List[str]:
        """URL gambar yang dicoba, host CDN satunya lagi sebagai cadangan.
        Dua host itu menyajikan file yang sama, jadi kalau yang satu menolak
        (atau balas gambar jebakan), yang lain masih bisa dipakai."""
        for utama in (self.CDN_PRIMARY, self.CDN_SECONDARY):
            if url.startswith(utama + '/'):
                lain = (self.CDN_SECONDARY if utama == self.CDN_PRIMARY
                        else self.CDN_PRIMARY)
                return [url, lain + url[len(utama):]]
        return [url]
    
    @classmethod
    def _gambar_jebakan(cls, resp: Any) -> bool:
        """Apakah balasan ini sebenarnya dialihkan ke gambar jebakan situs."""
        return cls.TRAP_IMAGE_PATH in (getattr(resp, 'url', '') or '')
    
    def _lapor_jebakan(self) -> None:
        """Beri tahu sekali kalau CDN menolak lewat gambar jebakan."""
        if self._jebakan_dilaporkan:
            return
        self._jebakan_dilaporkan = True
        print("\n  cdn softkomik membalas gambar jebakan, permintaan gambarnya "
              "ditolak. chapter yang gambarnya kena jebakan sengaja dilewat "
              "dan tidak ditulis ke cbz, jadi tidak ada halaman palsu yang "
              "tersimpan. coba lagi nanti, kalau terus begitu kunci id gambar "
              "situsnya kemungkinan sudah diganti")
    
    def _download_image_with_retry(self, url: str) -> Optional[bytes]:
        """Unduh 1 gambar halaman (menimpa punya base.py, khusus provider ini).
        
        Tambahan pentingnya: permintaan gambar situs ini wajib pakai Referer
        dari situsnya. Tanpa itu CDN-nya bukan menolak dengan error, tapi
        mengalihkan ke gambar jebakan yang ukurannya juga besar -- kalau tidak
        dicek, gambar jebakan itu masuk ke CBZ dan semua halaman jadi gambar
        promosi yang sama. Jadi hasilnya diperiksa dulu: gambar jebakan -> coba
        host CDN satunya lagi; masih jebakan -> dianggap gagal.
        """
        for kandidat in self._kandidat_gambar(url):
            for attempt in range(self.MAX_RETRIES):
                try:
                    resp = self.session.get(kandidat, timeout=30,
                                            headers=self.IMAGE_HEADERS)
                    resp.raise_for_status()
                    if self._gambar_jebakan(resp):
                        self._lapor_jebakan()
                        break          # host ini menolak; jangan diulang di sini
                    data = resp.content
                    # Validate image data
                    if len(data) < 1000:  # Too small, likely error
                        raise Exception("Image data too small")
                    return data
                except Exception:
                    if attempt < self.MAX_RETRIES - 1:
                        time.sleep(self.RETRY_DELAY)
        return None
    
    def download_manga(self, manga_url: str, max_workers: int = None, progress=None,
                       chapters=None, target_dir=None) -> bool:
        """Unduh pakai mesin base.py, lalu (khusus provider ini) coba sekali lagi
        chapter yang gagal.
        
        Kenapa pengulangan ini penting di sini: penyebab gagal yang khas
        softkomik adalah token sesi yang sedang ditolak situs -- sifatnya
        sebentar, jadi nunggu lalu coba lagi biasanya berhasil. Yang sudah jadi
        tetap di-skip oleh base, jadi yang diulang cuma yang belum beres.
        """
        tracker = progress or ProgressTracker(len(chapters) if chapters else 0)
        # target_dir diteruskan apa adanya supaya percobaan ulang tetap menulis
        # ke folder milik judul ini (bukan dihitung ulang dari judul).
        hasil = super().download_manga(manga_url, max_workers=max_workers,
                                       progress=tracker, chapters=chapters,
                                       target_dir=target_dir)
        
        # Cuma bisa nentuin chapter mana yang gagal kalau daftar chapter-nya
        # kita pegang. Kalau pemanggil nggak ngasih, ya dilaporkan saja.
        if chapters:
            self._retry_failed_chapters(manga_url, chapters, tracker, max_workers,
                                        target_dir=target_dir)
        return hasil
    
    def _retry_failed_chapters(self, manga_url: str, chapters: List[Dict[str, Any]],
                               tracker: ProgressTracker, max_workers: int = None,
                               target_dir=None) -> None:
        """Sekali percobaan ulang untuk chapter yang gagal (tanpa loop)."""
        judul_gagal = {r.get('chapter') for r in tracker.results
                       if r.get('status') == 'failed'}
        if not judul_gagal:
            return
        
        peta = {c['title']: c for c in chapters}
        # Chapter yang ditahan karena login jangan dicoba ulang: hasilnya bakal
        # sama saja, cuma nambah hujan permintaan ke situsnya.
        ulang = [peta[j] for j in judul_gagal
                 if j in peta and peta[j].get('url') not in self._perlu_login]
        dilewat = len([j for j in judul_gagal if j in peta]) - len(ulang)
        if dilewat:
            print(f"\n  coba ulang  {dilewat} chapter dilewat karena gambarnya "
                  f"ditahan login, mengulangnya tidak menolong")
        if not ulang:
            return
        
        print()
        # Gagal hampir semua = situsnya yang sedang menolak, bukan chapter-nya.
        # Ngulang sekarang cuma nambah hujan permintaan; lebih baik berhenti.
        batas = max(3, int(len(chapters) * self.RETRY_FAILED_MAX_RATIO))
        if len(ulang) >= batas:
            print(f"  coba ulang  dilewati, {len(ulang)} dari {len(chapters)} chapter gagal, "
                  f"sepertinya situsnya yang sedang menolak")
            print("  coba ulang  jalankan perintah yang sama nanti, yang sudah jadi dilewati saja")
            return
        
        print(f"  coba ulang  {len(ulang)} chapter dicoba lagi "
              f"setelah jeda {self.RETRY_FAILED_DELAY:.0f} detik")
        time.sleep(self.RETRY_FAILED_DELAY)
        
        # Tracker percobaan ulang ini mengikuti mode tracker utamanya: di mode
        # paralel tracker utama batch=True, jadi percobaan ulang pun tidak boleh
        # menggambar apa pun (papannya digambar koordinator paralel).
        ulang_tracker = ProgressTracker(len(ulang), batch=tracker.batch,
                                        log_sink=tracker.log_sink)
        super().download_manga(manga_url, max_workers=max_workers,
                               progress=ulang_tracker, chapters=ulang,
                               target_dir=target_dir)
        
        sisa = [r.get('chapter') for r in ulang_tracker.results
                if r.get('status') == 'failed']
        if sisa:
            daftar = ', '.join(str(s) for s in sisa[:5])
            print(f"  coba ulang  masih gagal {len(sisa)} chapter  {daftar}"
                  f"{' dan lain-lain' if len(sisa) > 5 else ''}")
        else:
            print("  coba ulang  beres, semua chapter yang gagal sudah jadi")
    
    # --------------------------------------------------------------- diagnosa
    def diagnosa(self) -> None:
        """Cek cepat koneksi + sesi + login + token, tanpa mengunduh apa pun.

        Dipakai kalau situsnya kelihatan "tidak bisa dicari / tidak bisa dibuka":
        outputnya memisahkan mana yang salah koneksi, mana yang salah sesi, dan
        mana yang memang judulnya tidak ada.
        """
        print()
        print("  diagnosa softkomik")
        print(f"  waktu      {time.strftime('%Y-%m-%d %H:%M:%S %Z')}")
        
        info_cookie = 'file tidak ada'
        if self.COOKIE_FILE.exists():
            try:
                data = json.loads(self.COOKIE_FILE.read_text() or '{}')
                umur = time.time() - float(data.get('saved_at') or 0)
                info_cookie = (f"{len(data.get('cookies') or {})} cookie, "
                               f"disimpan {umur / 3600:.1f} jam lalu")
            except Exception as e:
                info_cookie = f'file tidak bisa dibaca ({e})'
        print(f"  cookie     {info_cookie}")
        print(f"  login      {'ya, cookie dimuat' if self._sudah_login() else 'belum'}")
        
        html, alasan = self._ambil(self.BASE_URL)
        print(f"  beranda    {'ok' if html else 'gagal'}"
              + ('' if html else ', ' + str(alasan)))
        
        hasil = self.search('solo leveling')
        print(f"  pencarian  {'ok' if hasil else 'gagal atau kosong'}, {len(hasil)} hasil")
        
        for kind in (self.SESSION_LIST, self.SESSION_CHAPTER):
            token = self._get_token(kind, force=True)
            if token:
                ekstra = (' + contentAccess' if token.get('contentAccess') else '')
                sisa = (token.get('expires', 0) - time.time() * 1000) / 60000
                print(f"  token      {kind}{ekstra}, sisa {sisa:.1f} menit")
            else:
                print(f"  token    : {kind} GAGAL diambil")
        
        print(f"  catatan  : {self._alasan_terakhir or '-'}")
        print()


if __name__ == '__main__':
    # Dipanggil lewat paketnya, dari folder sc/:
    #   python3 -m scraper.softkomik
    SoftkomikScraper().diagnosa()

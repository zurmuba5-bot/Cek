#!/usr/bin/env python3
"""
Comic Scraper - Download manga from komiku.org and komikindo.ch
"""
import sys
import argparse
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt, IntPrompt, Confirm
from rich.panel import Panel
from rich import print as rprint

from scraper import KomikuScraper, KomikindoScraper, SoftkomikScraper


console = Console()


def show_banner():
    """Show the application banner"""
    banner = """
╔══════════════════════════════════════════════════╗
║           📚 COMIC SCRAPER v1.0                  ║
║     Download manga from Indonesian sites         ║
║     komiku.org & komikindo.ch                     ║
╚══════════════════════════════════════════════════╝
    """
    console.print(Panel(banner.strip(), style="bold cyan"))


def select_source():
    """Let user select the manga source"""
    console.print("\n[bold]Pilih sumber manga:[/bold]")
    console.print("  [1] komiku.org")
    console.print("  [2] komikindo.ch")
    console.print("  [3] softkomik.co")
    
    choice = IntPrompt.ask("Pilih", default=1)
    
    if choice == 1:
        return 'komiku', KomikuScraper()
    elif choice == 3:
        return 'softkomik', SoftkomikScraper()
    else:
        return 'komikindo', KomikindoScraper()


def search_manga(scraper):
    """Search for manga"""
    query = Prompt.ask("\n[bold cyan]Masukkan judul manga[/bold cyan]")
    
    console.print(f"\n[INFO] Mencari '{query}'...")
    results = scraper.search(query)
    
    if not results:
        console.print("[ERROR] Tidak ditemukan hasil!")
        return []
    
    # Show results table
    table = Table(title="Hasil Pencarian")
    table.add_column("No", style="dim", width=4)
    table.add_column("Judul", style="cyan")
    table.add_column("Info", style="green")
    
    for i, result in enumerate(results[:10], 1):
        info = ""
        if result.get('chapter_latest'):
            info = f"Latest: {result['chapter_latest']}"
        elif result.get('type'):
            info = result['type']
        table.add_row(str(i), result['title'], info)
    
    console.print(table)
    return results[:10]


def show_manga_detail(detail):
    """Show manga details"""
    if not detail:
        return
    
    console.print(f"\n[bold cyan]📚 {detail['title']}[/bold cyan]")
    
    if detail.get('genres'):
        console.print(f"[green]Genre:[/green] {', '.join(detail['genres'])}")
    
    if detail.get('info'):
        for key, value in detail['info'].items():
            console.print(f"[yellow]{key}:[/yellow] {value}")
    
    if detail.get('synopsis'):
        console.print(f"\n[bold]Sinopsis:[/bold]")
        console.print(f"  {detail['synopsis'][:300]}...")
    
    if detail.get('chapters'):
        console.print(f"\n[bold green]Total Chapter: {len(detail['chapters'])}[/bold green]")
        
        # Show first and last few chapters
        chapters = detail['chapters']
        if len(chapters) > 10:
            console.print("  [dim]...[/dim]")
            for ch in chapters[:3]:
                console.print(f"  - {ch['title']}")
            console.print(f"  [dim]... ({len(chapters) - 6} more) ...[/dim]")
            for ch in chapters[-3:]:
                console.print(f"  - {ch['title']}")
        else:
            for ch in chapters:
                console.print(f"  - {ch['title']}")


def select_chapters(chapters):
    """Let user select which chapters to download"""
    console.print("\n[bold]Pilih chapter yang ingin didownload:[/bold]")
    console.print("  [dim]Format: 1,2,3 atau 1-10 atau 'all' untuk semua[/dim]")
    
    choice = Prompt.ask("Chapter", default="all")
    
    if choice.lower() == 'all':
        return chapters
    
    selected = []
    for part in choice.split(','):
        part = part.strip()
        if '-' in part:
            # Range
            try:
                start, end = part.split('-')
                start = int(start.strip())
                end = int(end.strip())
                for ch in chapters:
                    ch_num = ''.join(filter(str.isdigit, ch['title'].split('Chapter')[-1]))
                    if ch_num and start <= int(ch_num) <= end:
                        selected.append(ch)
            except ValueError:
                pass
        else:
            # Single chapter
            try:
                ch_num = int(part)
                for ch in chapters:
                    if str(ch_num) in ch['title']:
                        selected.append(ch)
            except ValueError:
                pass
    
    return selected


def main():
    """Main function"""
    show_banner()
    
    # Parse arguments
    parser = argparse.ArgumentParser(description='Comic Scraper')
    parser.add_argument('-s', '--source', choices=['komiku', 'komikindo', 'softkomik'],
                       help='Manga source')
    parser.add_argument('-q', '--query', help='Search query')
    parser.add_argument('-d', '--download', help='Chapter to download (e.g., 1,2,3 or 1-10 or all)')
    parser.add_argument('-o', '--output', default='downloads', help='Output directory')
    
    args = parser.parse_args()
    
    # Select source
    if args.source:
        if args.source == 'komiku':
            source_name, scraper = 'komiku', KomikuScraper(args.output)
        elif args.source == 'softkomik':
            source_name, scraper = 'softkomik', SoftkomikScraper(args.output)
        else:
            source_name, scraper = 'komikindo', KomikindoScraper(args.output)
    else:
        source_name, scraper = select_source()
    
    # Search query
    if args.query:
        query = args.query
    else:
        query = Prompt.ask("\n[bold cyan]Masukkan judul manga[/bold cyan]")
    
    console.print(f"\n[INFO] Mencari '{query}'...")
    results = scraper.search(query)
    
    if not results:
        console.print("[ERROR] Tidak ditemukan hasil!")
        return
    
    # Show results table
    table = Table(title="Hasil Pencarian")
    table.add_column("No", style="dim", width=4)
    table.add_column("Judul", style="cyan")
    table.add_column("Info", style="green")
    
    for i, result in enumerate(results[:10], 1):
        info = ""
        if result.get('chapter_latest'):
            info = f"Latest: {result['chapter_latest']}"
        elif result.get('type'):
            info = result['type']
        table.add_row(str(i), result['title'], info)
    
    console.print(table)
    
    # Select manga
    if len(results) == 1:
        selected = results[0]
    else:
        choice = IntPrompt.ask("Pilih manga (nomor)", default=1)
        if choice < 1 or choice > len(results):
            console.print("[ERROR] Pilihan tidak valid!")
            return
        selected = results[choice - 1]
    
    # Get manga details
    console.print(f"\n[INFO] Mendapatkan detail: {selected['title']}...")
    detail = scraper.get_manga_detail(selected['url'])
    
    if not detail:
        console.print("[ERROR] Gagal mendapatkan detail manga!")
        return
    
    show_manga_detail(detail)
    
    # Select chapters
    if args.download:
        if args.download.lower() == 'all':
            chapters_to_download = detail['chapters']
        else:
            chapters_to_download = select_chapters(detail['chapters'])
    else:
        if not Confirm.ask("\nMau download manga ini?"):
            return
        chapters_to_download = select_chapters(detail['chapters'])
    
    if not chapters_to_download:
        console.print("[WARN] Tidak ada chapter dipilih!")
        return
    
    # Confirm download
    console.print(f"\n[bold]Akan didownload {len(chapters_to_download)} chapter[/bold]")
    if not Confirm.ask("Lanjutkan?"):
        return
    
    # Download
    console.print("\n[bold green]Mulai download...[/bold green]")
    scraper.download_manga(detail['url'],
                          chapters=chapters_to_download)
    
    console.print("\n[bold green]✅ Download selesai![/bold green]")


if __name__ == '__main__':
    main()
